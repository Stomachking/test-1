/*!
 * The List - books and experiences, for embedding in AEM.
 * One classic script: include it once, after (or before) the .the-list markup.
 * Content comes from data-content-url (a JSON file, e.g. in the DAM) or from a
 * <script type="application/json" class="the-list-content"> inside .the-list.
 * Media paths in that JSON are resolved against data-asset-base.
 */
(function () {
  "use strict";

  function boot() {
    var TL_ROOT = document.querySelector(".the-list:not(.the-list--portal)");
    if (!TL_ROOT || TL_ROOT.dataset.tlBooted) return;
    TL_ROOT.dataset.tlBooted = "1";
    window.TL_ROOT = TL_ROOT;

    /* ---------------------------- content + assets ---------------------------- */
    var dataNode = TL_ROOT.querySelector("script.the-list-content");
    if (dataNode) {
      start(JSON.parse(dataNode.textContent));
    } else if (TL_ROOT.dataset.contentUrl) {
      fetch(TL_ROOT.dataset.contentUrl, { credentials: "same-origin" })
        .then(function (response) { if (!response.ok) throw new Error("HTTP " + response.status); return response.json(); })
        .then(start)
        .catch(function (error) { console.error("[The List] Could not load content from " + TL_ROOT.dataset.contentUrl, error); });
    } else {
      console.error("[The List] No content: add data-content-url or a <script type=\"application/json\" class=\"the-list-content\">.");
    }
  }

  function start(content) {
    var TL_ROOT = window.TL_ROOT;
    var base = TL_ROOT.dataset.assetBase || "";
    if (base && !/\/$/.test(base)) base += "/";
    var resolve = function (value) {
      return typeof value === "string"
        && !/^(?:[a-z]+:|\/\/|\/|#)/i.test(value)
        && /\.(?:jpe?g|png|webp|gif|svg|mp4|webm|mov)(?:[?#].*)?$/i.test(value)
        ? base + value
        : value;
    };
    var walk = function (node) {
      if (Array.isArray(node)) return node.map(walk);
      if (node && typeof node === "object") {
        Object.keys(node).forEach(function (key) { node[key] = walk(node[key]); });
        return node;
      }
      return resolve(node);
    };
    walk(content);
    window.THE_LIST_CONTENT = content;
    window.COVER_DATA = content.covers || {};
    window.__THE_LIST = Object.assign(window.__THE_LIST || {}, {
      books: content.books,
      covers: content.books.map(function (book) { return book.cover; }),
      groups: content.groups
    });

    TL_ROOT.querySelectorAll("[data-tl-src]").forEach(function (el) { el.setAttribute("src", resolve(el.getAttribute("data-tl-src"))); });
    TL_ROOT.querySelectorAll("[data-tl-poster]").forEach(function (el) { el.setAttribute("poster", resolve(el.getAttribute("data-tl-poster"))); });
    TL_ROOT.querySelectorAll("video").forEach(function (video) { if (video.querySelector("source[src]")) video.load(); });
    TL_ROOT.querySelectorAll("img[data-cover]").forEach(function (img) { img.src = window.COVER_DATA[img.dataset.cover]; });

    /* Stop the host page scrolling behind an open book or the My List panel. */
    var locks = new Set();
    var savedOverflow = "";
    window.TL_lockPage = function (key, on) {
      var had = locks.size > 0;
      if (on) locks.add(key); else locks.delete(key);
      if (!had && locks.size) {
        savedOverflow = document.documentElement.style.overflow;
        document.documentElement.style.overflow = "hidden";
      } else if (had && !locks.size) {
        document.documentElement.style.overflow = savedOverflow;
      }
    };

    /* -------------------------------- My List -------------------------------- */
        // My List: tick off the books you've read and the places you've been,
        // then share a designed card of your list. Saved in this browser only.
        (() => {
          const KEY = "the-list:v1";
          const listeners = new Set();
          let state = { books: [], places: [], name: "" };
          try {
            const saved = JSON.parse(localStorage.getItem(KEY) || "null");
            if (saved && typeof saved === "object") {
              state = {
                books: Array.isArray(saved.books) ? saved.books : [],
                places: Array.isArray(saved.places) ? saved.places : [],
                name: typeof saved.name === "string" ? saved.name : ""
              };
            }
          } catch (error) { /* storage unavailable: keep an in-memory list */ }

          function save() {
            try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (error) { /* ignore */ }
            listeners.forEach((fn) => fn(state));
            syncAll();
          }

          const has = (kind, id) => state[kind].includes(id);
          function toggle(kind, id, on) {
            const next = on ?? !has(kind, id);
            state[kind] = state[kind].filter((item) => item !== id);
            if (next) state[kind].push(id);
            save();
          }

          function initials(name) {
            const words = String(name || "").trim().split(/\s+/).filter((word) => word && !/^\d+$/.test(word));
            if (!words.length) return "";
            const first = words[0][0] || "";
            const last = words.length > 1 ? words[words.length - 1][0] : "";
            return (first + last).toUpperCase();
          }

          function renderPicked(root, picked) {
            if (!root) return;
            root.hidden = !picked;
            if (!picked) return;
            root.querySelector(".picked-by__mark").textContent = initials(picked.name);
            root.querySelector(".picked-by__name").textContent = picked.name || "";
            const role = root.querySelector(".picked-by__role");
            role.textContent = picked.role || "";
            role.hidden = !picked.role;
            const note = root.querySelector(".picked-by__note");
            note.textContent = picked.note ? `“${picked.note}”` : "";
            note.hidden = !picked.note;
          }

          function syncToggle(button) {
            const on = has(button.dataset.listKind, button.dataset.listId);
            button.setAttribute("aria-pressed", String(on));
            button.classList.toggle("is-on", on);
          }

          function syncAll() {
            document.querySelectorAll(".mark-toggle[data-list-id]").forEach(syncToggle);
            document.querySelectorAll(".xp-thumb__done[data-list-id]").forEach((badge) => {
              badge.classList.toggle("is-on", has(badge.dataset.listKind, badge.dataset.listId));
            });
            const total = state.books.length + state.places.length;
            document.querySelectorAll("[data-mylist-count]").forEach((count) => {
              count.textContent = String(total);
              count.hidden = total === 0;
            });
            if (panel && !panel.hidden) renderPanel();
          }

          document.addEventListener("click", (event) => {
            const button = event.target.closest?.(".mark-toggle[data-list-id]");
            if (button) {
              event.preventDefault();
              event.stopPropagation();
              toggle(button.dataset.listKind, button.dataset.listId);
              return;
            }
            if (event.target.closest?.("[data-mylist-open]")) {
              event.preventDefault();
              openPanel(event.target.closest("[data-mylist-open]"));
            }
          }, true);

          /* ------------------------------ data ------------------------------ */
          // Book data normally comes from the 3D shelf; if the shelf couldn't
          // load (no WebGL), read the same list straight from the page.
          function fallbackBooks() {
            try {
              const code = document.querySelector('script[type="module"]')?.textContent || "";
              const json = code.split("const BOOKS = ")[1]?.split(";\n")[0];
              const books = json ? JSON.parse(json) : [];
              const ids = ["epic-disruptions", "i-can-fit-that-in", "letters-from-the-edge", "drive-different", "you-already-know", "leo", "bobbi", "1929", "goat", "jordan", "ceo"];
              const covers = ids.map((id) => window.COVER_DATA?.[id]);
              window.__THE_LIST = Object.assign(window.__THE_LIST || {}, { books, covers });
            } catch (error) { /* no books */ }
          }
          function data() {
            if (!window.__THE_LIST?.books?.length) fallbackBooks();
            const source = window.__THE_LIST || {};
            const books = (source.books || []).map((book, index) => ({
              id: book.id, title: book.title, sub: book.author, cover: source.covers?.[index]
            }));
            const groups = (source.groups || []).map((group) => ({
              id: group.id,
              label: group.label,
              items: group.items.map((item) => ({ id: item.title, title: item.title, sub: item.place }))
            }));
            return { books, groups };
          }

          /* ------------------------------ panel ------------------------------ */
          let panel = null;
          let lastFocus = null;
          function buildPanel() {
            panel = document.createElement("div");
            panel.className = "mylist";
            panel.id = "mylist";
            panel.hidden = true;
            panel.innerHTML = `
              <div class="mylist__scrim" data-mylist-close></div>
              <section class="mylist__sheet" role="dialog" aria-modal="true" aria-labelledby="mylist-title">
                <header class="mylist__head">
                  <div>
                    <p class="mylist__kicker">The List</p>
                    <h2 id="mylist-title">My List</h2>
                    <p class="mylist__lede">Tick off what you've read and where you've been, then share your card.</p>
                  </div>
                  <button class="mylist__close" type="button" data-mylist-close aria-label="Close My List">
                    <svg viewBox="0 0 16 16" aria-hidden="true"><path d="m4 4 8 8M12 4l-8 8"></path></svg>
                  </button>
                </header>
                <div class="mylist__body">
                  <div class="mylist__lists">
                    <section><h3>Books <span id="mylist-books-count"></span></h3><ul id="mylist-books"></ul></section>
                    <section id="mylist-places"></section>
                  </div>
                  <aside class="mylist__share">
                    <div class="mylist__preview"><canvas id="mylist-canvas" width="1080" height="1350" aria-label="Preview of your shareable list card" role="img"></canvas></div>
                    <label class="mylist__name">Name on your card
                      <input id="mylist-name" type="text" maxlength="24" autocomplete="given-name" placeholder="Your first name">
                    </label>
                    <div class="mylist__actions">
                      <button class="mylist__primary" type="button" id="mylist-share">Share my list</button>
                      <button class="mylist__secondary" type="button" id="mylist-download">Save image</button>
                    </div>
                    <p class="mylist__note" id="mylist-status">Saved in this browser only.</p>
                  </aside>
                </div>
              </section>`;
            const portal = document.createElement("div");
            portal.className = "the-list the-list--portal";
            portal.append(panel);
            document.body.append(portal);
            panel.addEventListener("click", (event) => {
              if (event.target.closest("[data-mylist-close]")) closePanel();
              const item = event.target.closest(".mylist-item");
              if (item) toggle(item.dataset.kind, item.dataset.id);
            });
            panel.addEventListener("keydown", (event) => {
              if (event.key === "Escape") closePanel();
              if (event.key === "Tab") trapFocus(event);
            });
            const nameInput = panel.querySelector("#mylist-name");
            nameInput.value = state.name;
            nameInput.addEventListener("input", () => {
              state.name = nameInput.value.slice(0, 24);
              try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (error) { /* ignore */ }
              drawCard();
            });
            panel.querySelector("#mylist-share").addEventListener("click", share);
            panel.querySelector("#mylist-download").addEventListener("click", () => download());
          }

          function trapFocus(event) {
            const focusable = [...panel.querySelectorAll("button, input")].filter((el) => !el.disabled && el.offsetParent);
            if (!focusable.length) return;
            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
            else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
          }

          function itemButton(kind, item) {
            const on = has(kind, item.id);
            const li = document.createElement("li");
            const button = document.createElement("button");
            button.type = "button";
            button.className = "mylist-item" + (on ? " is-on" : "");
            button.dataset.kind = kind;
            button.dataset.id = item.id;
            button.setAttribute("aria-pressed", String(on));
            button.innerHTML = '<span class="mylist-item__box" aria-hidden="true"></span><span class="mylist-item__text"><strong></strong><span></span></span>';
            button.querySelector("strong").textContent = item.title;
            button.querySelector(".mylist-item__text span").textContent = item.sub || "";
            li.append(button);
            return li;
          }

          function renderPanel() {
            const { books, groups } = data();
            const focusedId = document.activeElement?.closest?.(".mylist-item")?.dataset.id;
            const bookList = panel.querySelector("#mylist-books");
            bookList.replaceChildren(...books.map((book) => itemButton("books", book)));
            panel.querySelector("#mylist-books-count").textContent =
              `${books.filter((book) => has("books", book.id)).length} of ${books.length} read`;
            const places = panel.querySelector("#mylist-places");
            places.replaceChildren();
            groups.forEach((group) => {
              const heading = document.createElement("h3");
              const done = group.items.filter((item) => has("places", item.id)).length;
              heading.innerHTML = `${group.label} <span>${done} of ${group.items.length} visited</span>`;
              const list = document.createElement("ul");
              list.append(...group.items.map((item) => itemButton("places", item)));
              places.append(heading, list);
            });
            if (focusedId) panel.querySelector(`.mylist-item[data-id="${CSS.escape(focusedId)}"]`)?.focus();
            drawCard();
          }

          function openPanel(opener) {
            if (!panel) buildPanel();
            lastFocus = opener || document.activeElement;
            panel.hidden = false;
            TL_ROOT.classList.add("is-mylist");
            window.TL_lockPage("mylist", true);
            renderPanel();
            requestAnimationFrame(() => panel.classList.add("is-open"));
            panel.querySelector(".mylist__close").focus({ preventScroll: true });
          }
          function closePanel() {
            if (!panel || panel.hidden) return;
            panel.classList.remove("is-open");
            TL_ROOT.classList.remove("is-mylist");
            window.TL_lockPage("mylist", false);
            setTimeout(() => { panel.hidden = true; }, 220);
            lastFocus?.focus?.({ preventScroll: true });
          }

          /* --------------------------- share card --------------------------- */
          const coverCache = new Map();
          function coverImage(src) {
            if (!src) return null;
            if (!coverCache.has(src)) {
              const img = new Image();
              if (TL_ROOT.dataset.crossOrigin) img.crossOrigin = TL_ROOT.dataset.crossOrigin;
              img.onload = () => drawCard();
              img.src = src;
              coverCache.set(src, img);
            }
            const img = coverCache.get(src);
            return img.complete && img.naturalWidth ? img : null;
          }

          const SERIF = '"Iowan Old Style", "Baskerville", "Times New Roman", serif';
          const SANS = '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif';
          const INK = "#f4eee6";
          const SOFT = "#a9a39b";
          const ACCENT = "#c87046";

          function fit(ctx, text, width) {
            if (ctx.measureText(text).width <= width) return text;
            let cut = text;
            while (cut.length > 1 && ctx.measureText(cut + "…").width > width) cut = cut.slice(0, -1);
            return cut.trimEnd() + "…";
          }
          function tracked(ctx, text, x, y, spacing, align = "left") {
            const chars = [...text];
            const width = chars.reduce((sum, ch) => sum + ctx.measureText(ch).width + spacing, -spacing);
            let cursor = align === "right" ? x - width : x;
            chars.forEach((ch) => { ctx.fillText(ch, cursor, y); cursor += ctx.measureText(ch).width + spacing; });
          }
          // The public address, shown on every card wherever the page is opened.
          const pageUrl = () => "stomachking.github.io/test-1";

          function drawCard(target) {
            const canvas = target || panel?.querySelector("#mylist-canvas");
            if (!canvas) return null;
            const ctx = canvas.getContext("2d");
            const W = 1080;
            const H = 1350;
            const M = 84;
            const { books, groups } = data();
            const readBooks = books.filter((book) => has("books", book.id));
            const allPlaces = groups.flatMap((group) => group.items);
            const visited = allPlaces.filter((item) => has("places", item.id));

            // Background
            const bg = ctx.createLinearGradient(0, 0, 0, H);
            bg.addColorStop(0, "#1b1e2a");
            bg.addColorStop(1, "#0e1016");
            ctx.fillStyle = bg;
            ctx.fillRect(0, 0, W, H);
            const glow = ctx.createRadialGradient(W * 0.86, 120, 20, W * 0.86, 120, 620);
            glow.addColorStop(0, "rgba(200, 112, 70, 0.28)");
            glow.addColorStop(1, "rgba(200, 112, 70, 0)");
            ctx.fillStyle = glow;
            ctx.fillRect(0, 0, W, H);

            // Masthead
            ctx.textBaseline = "alphabetic";
            ctx.fillStyle = INK;
            ctx.font = `600 24px ${SANS}`;
            tracked(ctx, "THE LIST", M, 104, 7);
            ctx.fillStyle = SOFT;
            ctx.font = `500 20px ${SANS}`;
            tracked(ctx, "EDITION 02 · 2026", W - M, 104, 4, "right");

            // Headline
            const name = state.name.trim();
            ctx.fillStyle = INK;
            ctx.font = `400 104px ${SERIF}`;
            ctx.fillText(fit(ctx, name ? `${name}’s List` : "My List", W - M * 2), M - 4, 236);
            ctx.fillStyle = SOFT;
            ctx.font = `italic 400 32px ${SERIF}`;
            ctx.fillText("Books read and places been, from The List.", M, 292);

            // Stats
            const stat = (value, total, label, x) => {
              ctx.fillStyle = ACCENT;
              ctx.font = `400 116px ${SERIF}`;
              ctx.fillText(String(value), x, 430);
              const w = ctx.measureText(String(value)).width;
              ctx.fillStyle = SOFT;
              ctx.font = `400 44px ${SERIF}`;
              ctx.fillText(`/ ${total}`, x + w + 14, 430);
              ctx.fillStyle = INK;
              ctx.font = `600 19px ${SANS}`;
              tracked(ctx, label, x + 4, 470, 4);
            };
            stat(readBooks.length, books.length || 11, "BOOKS READ", M);
            stat(visited.length, allPlaces.length || 10, "PLACES VISITED", 560);

            // Covers of the books read (ghost frames until some are ticked)
            const coverY = 516;
            const coverH = 150;
            const coverW = 100;
            const gap = 16;
            const slots = Math.min(8, Math.max(readBooks.length, 0));
            if (slots === 0) {
              ctx.strokeStyle = "rgba(244, 238, 230, 0.16)";
              ctx.setLineDash([6, 8]);
              ctx.lineWidth = 2;
              for (let i = 0; i < 6; i += 1) ctx.strokeRect(M + i * (coverW + gap), coverY, coverW, coverH);
              ctx.setLineDash([]);
            } else {
              readBooks.slice(0, 8).forEach((book, i) => {
                const x = M + i * (coverW + gap);
                ctx.save();
                ctx.shadowColor = "rgba(0, 0, 0, 0.45)";
                ctx.shadowBlur = 18;
                ctx.shadowOffsetY = 8;
                const img = coverImage(book.cover);
                if (img) {
                  const scale = Math.max(coverW / img.naturalWidth, coverH / img.naturalHeight);
                  const sw = coverW / scale;
                  const sh = coverH / scale;
                  ctx.drawImage(img, (img.naturalWidth - sw) / 2, (img.naturalHeight - sh) / 2, sw, sh, x, coverY, coverW, coverH);
                } else {
                  ctx.fillStyle = "#2a2d38";
                  ctx.fillRect(x, coverY, coverW, coverH);
                }
                ctx.restore();
              });
              if (readBooks.length > 8) {
                ctx.fillStyle = SOFT;
                ctx.font = `500 22px ${SANS}`;
                ctx.fillText(`+${readBooks.length - 8}`, M + 8 * (coverW + gap) - 4, coverY + coverH / 2 + 8);
              }
            }

            // Two columns of ticks
            const colW = (W - M * 2 - 60) / 2;
            const rowH = 38;
            const row = (item, done, x, y) => {
              ctx.beginPath();
              ctx.arc(x + 11, y - 8, 11, 0, Math.PI * 2);
              if (done) {
                ctx.fillStyle = ACCENT;
                ctx.fill();
                ctx.strokeStyle = "#14161d";
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.moveTo(x + 6, y - 8);
                ctx.lineTo(x + 10, y - 3.5);
                ctx.lineTo(x + 17, y - 13);
                ctx.stroke();
              } else {
                ctx.strokeStyle = "rgba(244, 238, 230, 0.32)";
                ctx.lineWidth = 2;
                ctx.stroke();
              }
              ctx.fillStyle = done ? INK : "rgba(244, 238, 230, 0.42)";
              ctx.font = `400 25px ${SERIF}`;
              ctx.fillText(fit(ctx, item.title, colW - 40), x + 36, y);
            };
            const heading = (text, x, y) => {
              ctx.fillStyle = ACCENT;
              ctx.font = `600 18px ${SANS}`;
              tracked(ctx, text, x, y, 4);
            };
            const listTop = 740;
            ctx.strokeStyle = "rgba(244, 238, 230, 0.16)";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(M, listTop - 46);
            ctx.lineTo(W - M, listTop - 46);
            ctx.stroke();
            heading("BOOKS", M, listTop);
            books.forEach((book, i) => row(book, has("books", book.id), M, listTop + 46 + i * rowH));
            let y = listTop;
            const x2 = M + colW + 60;
            groups.forEach((group, g) => {
              if (g > 0) y += 26;
              heading(group.label.toUpperCase(), x2, y);
              y += 46;
              group.items.forEach((item) => { row(item, has("places", item.id), x2, y); y += rowH; });
            });

            // Footer
            ctx.strokeStyle = "rgba(244, 238, 230, 0.16)";
            ctx.beginPath();
            ctx.moveTo(M, H - 112);
            ctx.lineTo(W - M, H - 112);
            ctx.stroke();
            ctx.fillStyle = SOFT;
            ctx.font = `500 21px ${SANS}`;
            ctx.fillText(pageUrl(), M, H - 66);
            ctx.fillStyle = INK;
            ctx.textAlign = "right";
            ctx.fillText("Make your own list →", W - M, H - 66);
            ctx.textAlign = "left";
            return canvas;
          }

          function cardBlob() {
            const canvas = document.createElement("canvas");
            canvas.width = 1080;
            canvas.height = 1350;
            drawCard(canvas);
            return new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
          }
          function setStatus(text) {
            const status = panel?.querySelector("#mylist-status");
            if (status) status.textContent = text;
          }
          async function download(blob) {
            const file = blob || await cardBlob();
            if (!file) return setStatus("Sorry, the image couldn't be made in this browser.");
            const url = URL.createObjectURL(file);
            const link = document.createElement("a");
            link.href = url;
            link.download = "my-list.png";
            document.body.append(link);
            link.click();
            link.remove();
            setTimeout(() => URL.revokeObjectURL(url), 4000);
            setStatus("Image saved. Post it anywhere you like.");
          }
          async function share() {
            const blob = await cardBlob();
            if (!blob) return setStatus("Sorry, the image couldn't be made in this browser.");
            const { books, groups } = data();
            const places = groups.reduce((sum, group) => sum + group.items.length, 0);
            const text = `I've read ${state.books.length} of ${books.length} books and been to ${state.places.length} of ${places} places on The List.`;
            const file = new File([blob], "my-list.png", { type: "image/png" });
            try {
              if (navigator.canShare?.({ files: [file] })) {
                await navigator.share({ files: [file], title: "My List", text: `${text} https://${pageUrl()}` });
                setStatus("Shared.");
                return;
              }
            } catch (error) {
              if (error?.name === "AbortError") return;
            }
            await download(blob);
            setStatus("Sharing isn't available here, so the image was saved instead.");
          }

          window.TheList = { has, toggle, renderPicked, syncToggle, open: openPanel, drawCard };
          window.addEventListener("thelist:data", syncAll);
          setTimeout(syncAll, 0);
        })();
  

    /* ------------------------------ Experiences ------------------------------ */
        (() => {
          /* =====================================================================
             EXPERIENCES — edit this list to add or change places.
             Order here is the order on the page. To add a film, give the entry a
             `film` with webm/mp4 paths and a poster frame; entries without a film
             show a coloured "film to come" card until one is added.
             ===================================================================== */
          const GROUPS = window.THE_LIST_CONTENT.groups;
          window.__THE_LIST = Object.assign(window.__THE_LIST || {}, { groups: GROUPS });
          let activeGroup = GROUPS[0];
          let EXPERIENCES = activeGroup.items;

          /* ---------------------------- utilities ---------------------------- */
          const reducedQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
          let reduced = reducedQuery.matches;
          const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
          const lerp = (a, b, t) => a + (b - a) * t;
          const range = (value, start, end) => clamp((value - start) / (end - start), 0, 1);
          const easeInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
          const easeIn = (t) => t * t;
          const smooth = (t) => t * t * (3 - 2 * t);
          const pad = (value) => String(value).padStart(2, "0");
          const el = (tag, className, text) => {
            const node = document.createElement(tag);
            if (className) node.className = className;
            if (text != null) node.textContent = text;
            return node;
          };
          function seeded(seed) {
            let value = seed >>> 0;
            return () => {
              value = (value * 1664525 + 1013904223) >>> 0;
              return value / 4294967296;
            };
          }

          // Load a film robustly: MP4 (plays everywhere) first; if the browser or
          // a sandboxed preview refuses the file, fetch it and play it from memory;
          // WebM is the last resort.
          function attachFilm(video, film) {
            const plan = [];
            if (film.mp4) plan.push({ url: film.mp4, type: "video/mp4" });
            if (film.mp4) plan.push({ url: film.mp4, type: "video/mp4", blob: true });
            if (film.webm) plan.push({ url: film.webm, type: "video/webm" });
            if (film.webm) plan.push({ url: film.webm, type: "video/webm", blob: true });
            let step = 0;
            const next = () => {
              const option = plan[step++];
              if (!option) return;
              if (!option.blob) {
                video.src = option.url;
                video.load();
                return;
              }
              fetch(option.url)
                .then((response) => {
                  if (!response.ok) throw new Error(String(response.status));
                  return response.blob();
                })
                .then((blob) => {
                  video.src = URL.createObjectURL(new Blob([blob], { type: option.type }));
                  video.load();
                  if (video.autoplay || video.dataset.wantPlay === "1") video.play().catch(() => {});
                })
                .catch(next);
            };
            video.addEventListener("error", next);
            next();
          }

          const track = document.querySelector("#xp-track");
          const stage = document.querySelector("#xp-stage");
          const world = document.querySelector("#xp-world");
          const captions = document.querySelector("#xp-captions");
          const rail = document.querySelector("#xp-rail");
          const hint = document.querySelector("#xp-hint");
          const count = document.querySelector("#xp-count");
          const countTitle = document.querySelector("#xp-count-title");
          const indexToggle = document.querySelector("#xp-index-toggle");
          const indexPanel = document.querySelector("#xp-index");
          const indexList = document.querySelector("#xp-index-list");
          const contents = document.querySelector("#xp-contents");
          if (!track || !stage) return;

          let total = EXPERIENCES.length;
          const PLAY_ICON = '<path d="M3 1.5v9l7.5-4.5z"/>';
          const PAUSE_ICON = '<rect x="2" y="1.5" width="2.6" height="9"/><rect x="7.4" y="1.5" width="2.6" height="9"/>';

          /* ------------------------- build the chapters ------------------------- */
          let chapters = [];
          function buildChapters() {
            chapters.forEach((chapter) => chapter.video?.pause());
            world.replaceChildren();
            captions.replaceChildren();
            chapters = EXPERIENCES.map((data, index) => {
            const number = pad(index + 1);
            const palette = data.palette;
            const node = el("div", "xp-chapter");
            node.style.setProperty("--c-ink", palette.ink);
            node.style.setProperty("--c-accent", palette.accent);

            const numberLayer = el("span", "xp-layer xp-number", number);
            numberLayer.dataset.z = "-1.9";
            const placeLayer = el("p", "xp-layer xp-place xp-kicker", data.place);
            placeLayer.dataset.z = "-0.9";
            const titleLayer = el("div", "xp-layer xp-title");
            titleLayer.dataset.z = "-0.12";
            titleLayer.append(el("p", "xp-kicker", `${number} · ${data.kind}`), el("h3", null, data.title));
            [numberLayer, placeLayer, titleLayer].forEach((layer) => layer.setAttribute("aria-hidden", "true"));
            node.append(numberLayer, placeLayer, titleLayer);

            // Decorative frames, kept off-centre so they never sit on the film.
            const random = seeded(29 + index * 131);
            for (let i = 0; i < 6; i += 1) {
              const ghost = el("span", "xp-layer xp-ghost");
              ghost.setAttribute("aria-hidden", "true");
              const width = 12 + random() * 18;
              ghost.style.width = `${width}vw`;
              ghost.style.height = `${width * (0.45 + random() * 0.35)}vw`;
              const side = i % 2 === 0 ? -1 : 1;
              ghost.style.left = `${50 + side * (22 + random() * 24) - width / 2}%`;
              ghost.style.top = `${8 + random() * 72}%`;
              ghost.dataset.z = String(-2.6 + i * 0.42 + random() * 0.2);
              ghost.dataset.max = "0.7";
              node.append(ghost);
            }

            const plane = el("div", "xp-plane");
            // While a film loads, its still shows behind it instead of nothing.
            const still = data.film?.thumb || data.image?.thumb;
            if (still) {
              plane.style.backgroundImage = `url("${still}")`;
              plane.style.backgroundSize = "cover";
              plane.style.backgroundPosition = "center";
            }
            let media;
            let video = null;
            if (data.film) {
              video = document.createElement("video");
              video.muted = true;
              video.loop = true;
              video.playsInline = true;
              video.setAttribute("muted", "");
              video.setAttribute("playsinline", "");
              video.preload = index === 0 ? "auto" : "none";
              video.poster = data.film.poster || "";
              video.setAttribute("aria-label", data.film.label || data.title);
              attachFilm(video, data.film);
              media = video;
            } else if (data.image) {
              media = el("img", "xp-still");
              media.src = data.image.src;
              media.alt = data.image.alt || data.title;
              media.decoding = "async";
            } else {
              media = el("div", "xp-placeholder");
              media.setAttribute("aria-hidden", "true");
              const inner = el("div");
              inner.append(el("strong", null, number), el("span", "xp-kicker", "Film to come"));
              media.append(inner);
            }
            const shade = el("div", "xp-shade");
            const frame = el("div", "xp-frame");
            frame.setAttribute("aria-hidden", "true");
            plane.append(media, shade, frame);
            node.append(plane);
            world.append(node);

            // Caption (real, accessible text) shown once the film is full-bleed.
            const caption = el("div", "xp-caption");
            caption.style.setProperty("--c-accent", palette.accent);
            const head = el("div");
            head.append(el("p", "xp-kicker", `${number} · ${data.place}`), el("h3", null, data.title));
            if (data.pickedBy && window.TheList) {
              const picked = el("div", "picked-by picked-by--xp");
              picked.innerHTML = '<span class="picked-by__mark" aria-hidden="true"></span><span class="picked-by__who"><span class="picked-by__kicker">Picked by</span><strong class="picked-by__name"></strong><span class="picked-by__role"></span></span><span class="picked-by__note"></span>';
              window.TheList.renderPicked(picked, data.pickedBy);
              head.append(picked);
            }
            const side = el("div", "xp-caption__side");
            side.append(el("p", "xp-caption__text", data.description));
            const list = el("dl");
            data.details.forEach(([term, value]) => {
              const pair = el("div");
              pair.append(el("dt", null, term), el("dd", null, value));
              list.append(pair);
            });
            side.append(list);
            if (data.funFact) {
              const fact = el("div", "xp-fact");
              fact.append(el("span", "xp-fact__label", "Did you know?"), el("span", "xp-fact__text", data.funFact));
              side.append(fact);
            }
            if (data.credit && (data.film || data.image)) {
              side.append(el("p", "xp-credit", data.credit));
            }
            let toggle = null;
            const actions = el("div", "xp-actions");
            if (video) {
              toggle = el("button", "xp-play");
              toggle.type = "button";
              toggle.innerHTML = `<svg viewBox="0 0 12 12" aria-hidden="true">${PAUSE_ICON}</svg><span>Pause film</span>`;
              actions.append(toggle);
            }
            if (window.TheList) {
              const been = el("button", "mark-toggle mark-toggle--xp");
              been.type = "button";
              been.dataset.listKind = "places";
              been.dataset.listId = data.title;
              been.innerHTML = '<span class="mark-toggle__box" aria-hidden="true"></span><span class="mark-toggle__label">I\'ve been here</span>';
              window.TheList.syncToggle(been);
              actions.append(been);
            }
            side.append(actions);
            caption.append(head, side);
            captions.append(caption);

            const chapter = {
              index,
              data,
              node,
              plane,
              media,
              video,
              shade,
              frame,
              caption,
              toggle,
              layers: [...node.querySelectorAll(".xp-layer")].map((layer) => ({
                node: layer,
                z: parseFloat(layer.dataset.z || "0"),
                max: parseFloat(layer.dataset.max || "1")
              })),
              live: false,
              userPaused: false,
              insetX: 0,
              insetY: 0,
              fitScale: 1,
              coverWidth: 0,
              coverHeight: 0,
              z0: -1000
            };
            if (toggle) {
              toggle.addEventListener("click", () => {
                chapter.userPaused = !chapter.userPaused;
                syncPlayback(chapter, true);
              });
            }
            return chapter;
            });
          }

          /* ----------------------- contents + index lists ----------------------- */
          let indexButtons = [];
          function buildLists() {
          contents.replaceChildren();
          indexList.replaceChildren();
          contents.style.setProperty("--cards", String(EXPERIENCES.length));
          EXPERIENCES.forEach((data, index) => {
            const item = el("li");
            const link = el("a");
            link.href = "#experiences";
            link.className = "xp-card";
            const thumb = el("span", "xp-thumb");
            thumb.style.setProperty("--thumb-accent", data.palette.accent);
            const thumbSource = data.film?.thumb || data.image?.thumb || data.image?.src || data.film?.poster;
            const placeholder = el("span", "xp-thumb__placeholder");
            placeholder.setAttribute("aria-hidden", "true");
            placeholder.append(
              el("span", "xp-thumb__num", pad(index + 1)),
              el("span", "xp-thumb__soon", "Film to come")
            );
            thumb.append(placeholder);
            if (thumbSource) {
              const img = el("img");
              img.src = thumbSource;
              img.alt = "";
              img.loading = "lazy";
              img.decoding = "async";
              // If a still is missing, the designed placeholder shows instead.
              img.addEventListener("error", () => img.remove());
              thumb.append(img);
              thumb.classList.add("has-media");
            }
            if (data.film) {
              thumb.append(el("span", "xp-thumb__badge", "Film"));
              // Hovering a card plays a short silent preview of its film.
              let preview = null;
              const start = data.film.scenes?.[1]?.[0] ?? 0;
              link.addEventListener("pointerenter", (event) => {
                if (event.pointerType !== "mouse" || reduced) return;
                if (!preview) {
                  preview = document.createElement("video");
                  preview.className = "xp-thumb__film";
                  preview.muted = true;
                  preview.loop = true;
                  preview.playsInline = true;
                  preview.setAttribute("muted", "");
                  preview.setAttribute("playsinline", "");
                  preview.preload = "auto";
                  [["mp4", "video/mp4"], ["webm", "video/webm"]].forEach(([key, type]) => {
                    if (!data.film[key]) return;
                    const source = document.createElement("source");
                    source.src = data.film[key];
                    source.type = type;
                    preview.append(source);
                  });
                  preview.addEventListener("loadedmetadata", () => { preview.currentTime = start; }, { once: true });
                  preview.addEventListener("playing", () => thumb.classList.add("is-previewing"));
                  thumb.append(preview);
                }
                preview.play().catch(() => {});
              });
              link.addEventListener("pointerleave", () => {
                if (!preview) return;
                preview.pause();
                thumb.classList.remove("is-previewing");
              });
            }
            const text = el("span", "xp-card__text");
            text.append(
              el("span", "xp-kicker", `${pad(index + 1)} · ${data.kind}`),
              el("strong", null, data.title),
              el("span", "xp-card__place", data.place)
            );
            if (data.pickedBy) text.append(el("span", "xp-card__picked", `Picked by ${data.pickedBy.name}`));
            const done = el("span", "xp-thumb__done");
            done.setAttribute("aria-hidden", "true");
            done.dataset.listKind = "places";
            done.dataset.listId = data.title;
            thumb.append(done);
            link.append(thumb, text);
            link.addEventListener("click", (event) => {
              event.preventDefault();
              goToExperience(index);
            });
            item.append(link);
            contents.append(item);

            const indexItem = el("li");
            const button = el("button");
            button.type = "button";
            button.append(el("span", null, pad(index + 1)), el("strong", null, data.title));
            button.addEventListener("click", () => {
              setIndexOpen(false);
              goToExperience(index);
            });
            indexItem.append(button);
            indexList.append(indexItem);
          });
          indexButtons = [...indexList.querySelectorAll("button")];
          }

          /* ------------------------------ layout ------------------------------ */
          let viewWidth = window.innerWidth;
          let viewHeight = window.innerHeight;
          let perspective = 1100;
          let narrow = viewWidth <= 880;

          // Each place has a stop per scene: the floating card, the full-bleed
          // film with its caption, then any extra push-in scenes. One scroll
          // moves one stop.
          const HOLD_POINT = 0.62;
          const BEAT = 0.5;
          const stops = [];
          let totalSpan = 1;
          function planChapters() {
            let start = 0;
            chapters.forEach((chapter) => {
              const scenes = chapter.data.film?.scenes;
              const extra = scenes && scenes.length > 2 ? scenes.length - 2 : 0;
              chapter.scenes = scenes && scenes.length ? scenes : null;
              chapter.extra = extra * BEAT;
              chapter.span = 1 + chapter.extra;
              chapter.beats = [0, HOLD_POINT];
              for (let i = 1; i <= extra; i += 1) chapter.beats.push(HOLD_POINT + i * BEAT);
              chapter.start = start;
              start += chapter.span;
            });
            totalSpan = Math.max(1, start);
          }
          function setTrackHeight() {
            planChapters();
            const segment = narrow ? 95 : 135;
            const unit = CSS.supports("height", "1svh") ? "svh" : "vh";
            track.style.height = `calc(100vh + ${totalSpan * segment}vh)`;
            if (unit === "svh") track.style.height = `calc(100dvh + ${totalSpan * segment}svh)`;
            stops.splice(0).forEach((stop) => stop.remove());
            chapters.forEach((chapter) => {
              chapter.stopEls = [];
              chapter.beats.forEach((beat) => {
                const stop = el("span", "snap-stop");
                chapter.stopEls.push(stop);
                stop.setAttribute("aria-hidden", "true");
                stop.style.top = `${((chapter.start + beat) * segment).toFixed(3)}${unit}`;
                track.append(stop);
                stops.push(stop);
              });
            });
          }

          function chapterAt(position) {
            let found = chapters[0];
            chapters.forEach((chapter) => {
              if (chapter.start <= position) found = chapter;
            });
            return found;
          }

          function layout() {
            viewWidth = window.innerWidth;
            viewHeight = stage.clientHeight || window.innerHeight;
            const wasNarrow = narrow;
            narrow = viewWidth <= 880;
            perspective = narrow ? 760 : 1100;
            stage.style.perspective = `${perspective}px`;
            if (wasNarrow !== narrow || !track.style.height) setTrackHeight();

            chapters.forEach((chapter) => {
              // Largest 16:9 window inside the viewport-sized plane.
              const windowWidth = Math.min(viewWidth, (viewHeight * 16) / 9);
              const windowHeight = (windowWidth * 9) / 16;
              chapter.insetX = (viewWidth - windowWidth) / 2;
              chapter.insetY = (viewHeight - windowHeight) / 2;
              // Inside the card the whole frame shows; it opens to a cover crop.
              const coverWidth = Math.max(viewWidth, (viewHeight * 16) / 9);
              const coverHeight = (coverWidth * 9) / 16;
              chapter.fitScale = windowWidth / coverWidth;
              // Size the film to its full-bleed crop so scaling it down shows the
              // whole frame inside the card, not a shrunken sliver.
              chapter.coverWidth = coverWidth;
              chapter.coverHeight = coverHeight;
              Object.assign(chapter.media.style, {
                position: "absolute",
                width: `${coverWidth}px`,
                height: `${coverHeight}px`
              });
              const targetWidth = narrow
                ? viewWidth * 0.7
                : Math.min(viewWidth * 0.5, 920, viewHeight * 0.6 * (16 / 9));
              const startScale = clamp(targetWidth / windowWidth, 0.2, 0.95);
              // Perspective projection: scale = P / (P - z)  →  z = P (1 - 1 / scale).
              chapter.z0 = perspective * (1 - 1 / startScale);
            });
            lastRendered = NaN;
          }

          /* ------------------------------ render ------------------------------ */
          function hideChapter(chapter) {
            if (!chapter.live) return;
            chapter.live = false;
            chapter.node.style.visibility = "hidden";
            // Layers set their own visibility, so hide them explicitly too.
            chapter.layers.forEach((layer) => { layer.node.style.visibility = "hidden"; });
            chapter.caption.style.visibility = "hidden";
            chapter.caption.style.opacity = "0";
            syncPlayback(chapter);
          }

          function renderChapter(chapter, local) {
            const isLast = chapter.index === total - 1;
            // Extra scenes hold the film full-bleed and push in a step at a time;
            // the usual card → film → exit timeline runs around them.
            let p = local;
            let push = 0;
            if (chapter.extra > 0 && local > HOLD_POINT) {
              if (local >= HOLD_POINT + chapter.extra) {
                p = local - chapter.extra;
                push = chapter.extra / BEAT;
              } else {
                p = HOLD_POINT;
                const k = (local - HOLD_POINT) / BEAT;
                push = Math.floor(k) + easeInOut(k - Math.floor(k));
              }
            }
            const pushScale = reduced ? 1 : 1 + push * 0.14;
            let pre;
            let zoom;
            let open;
            let exit;
            let captionIn;
            if (reduced) {
              pre = zoom = open = captionIn = 1;
              exit = 0;
            } else {
              pre = smooth(range(p, -0.3, 0));
              zoom = easeInOut(range(p, 0, 0.42));
              open = easeInOut(range(p, 0.16, 0.46));
              exit = isLast ? 0 : easeIn(range(p, 0.8, 1));
              captionIn = smooth(range(p, 0.46, 0.56))
                * (isLast ? 1 : 1 - smooth(range(p, 0.76, 0.84)));
            }
            const intro = range(p, -0.3, 0.1);
            const P = perspective;

            if (!chapter.live) {
              chapter.live = true;
              chapter.node.style.visibility = "visible";
              if (chapter.video && chapter.video.preload !== "auto") chapter.video.preload = "auto";
            }

            const z = lerp(chapter.z0, 0, zoom) - (1 - pre) * 0.9 * P + exit * 0.55 * P;
            const rotateX = lerp(lerp(12, 8, intro), 0, zoom);
            const rotateY = lerp(lerp(-23, -15, intro), 0, zoom);
            const rotateZ = lerp(-1.2, 0, zoom);
            const insetX = chapter.insetX * (1 - open);
            const insetY = chapter.insetY * (1 - open);
            const radius = 16 * (1 - open);
            const planeOpacity = pre * (1 - exit);

            chapter.plane.style.transform =
              `translate3d(0, 0, ${z.toFixed(2)}px) rotateX(${rotateX.toFixed(3)}deg) ` +
              `rotateY(${rotateY.toFixed(3)}deg) rotateZ(${rotateZ.toFixed(3)}deg)`;
            // Shape the card by resizing the plane (clip-path on a 3D-tilted
            // element fails to paint on some phones). The film stays centred.
            chapter.plane.style.inset = `${insetY.toFixed(2)}px ${insetX.toFixed(2)}px`;
            chapter.plane.style.borderRadius = `${radius.toFixed(2)}px`;
            chapter.media.style.left = `${((viewWidth - chapter.coverWidth) / 2 - insetX).toFixed(2)}px`;
            chapter.media.style.top = `${((viewHeight - chapter.coverHeight) / 2 - insetY).toFixed(2)}px`;
            chapter.plane.style.opacity = planeOpacity.toFixed(3);
            chapter.media.style.transform = `scale(${(lerp(chapter.fitScale, 1, open) * pushScale).toFixed(4)})`;

            chapter.frame.style.inset = "14px";
            chapter.frame.style.opacity = ((1 - open) * 0.9).toFixed(3);
            chapter.shade.style.opacity = (open * 0.95).toFixed(3);

            // The camera dollies forward; titles and frames drift past it.
            const dolly = zoom * P * 1.35 - (1 - pre) * 0.9 * P;
            chapter.layers.forEach((layer) => {
              const depth = layer.z * P + dolly;
              const fade = 1 - smooth(range(depth, P * 0.22, P * 0.6));
              const opacity = clamp(fade * pre * layer.max, 0, 1);
              if (reduced || opacity < 0.01 || depth > P * 0.85) {
                layer.node.style.visibility = "hidden";
                return;
              }
              layer.node.style.visibility = "visible";
              layer.node.style.opacity = opacity.toFixed(3);
              layer.node.style.transform = `translate3d(0, 0, ${depth.toFixed(2)}px)`;
            });

            chapter.caption.style.opacity = captionIn.toFixed(3);
            chapter.caption.style.visibility = captionIn > 0.01 ? "visible" : "hidden";
            chapter.caption.style.transform = `translateY(${((1 - captionIn) * 26).toFixed(2)}px)`;
          }

          /* ----------------------------- playback ----------------------------- */
          let stageVisible = false;
          function syncPlayback(chapter, fromUser = false) {
            if (!chapter.video) return;
            const p = eased - chapter.start;
            const isLast = chapter.index === total - 1;
            const inWindow = reduced
              ? chapter.live
              : p > -0.15 && (isLast || p < chapter.span - 0.03);
            const shouldPlay = stageVisible && chapter.live && inWindow
              && !chapter.userPaused && !document.hidden
              && (!reduced || fromUser || chapter.userStarted);
            const { video, toggle } = chapter;
            if (reduced && fromUser) {
              // With reduced motion, films only play when someone asks.
              chapter.userStarted = !chapter.userStarted;
              chapter.userPaused = !chapter.userStarted;
              return syncPlayback(chapter);
            }
            video.dataset.wantPlay = shouldPlay ? "1" : "0";
            if (shouldPlay && video.paused) {
              video.play().catch(() => {});
            } else if (!shouldPlay && !video.paused) {
              video.pause();
            }
            const showPlay = chapter.userPaused || (reduced && !chapter.userStarted);
            // Only touch the button when its state changes (this runs every frame).
            if (chapter.showPlay !== showPlay) {
              chapter.showPlay = showPlay;
              toggle.querySelector("span").textContent = showPlay ? "Play film" : "Pause film";
              toggle.querySelector("svg").innerHTML = showPlay ? PLAY_ICON : PAUSE_ICON;
              toggle.setAttribute("aria-pressed", String(!showPlay));
            }
          }

          /* ------------------------------- HUD ------------------------------- */
          let currentIndex = -1;
          function setCurrent(index) {
            if (index === currentIndex) return;
            currentIndex = index;
            const data = EXPERIENCES[index];
            const palette = data.palette;
            stage.style.setProperty("--xp-paper", palette.paper);
            stage.style.setProperty("--xp-ink", palette.ink);
            stage.style.setProperty("--xp-ink-soft", palette.inkSoft);
            stage.style.setProperty("--xp-accent", palette.accent);
            count.textContent = `${pad(index + 1)} / ${pad(total)}`;
            countTitle.textContent = data.title;
            indexButtons.forEach((button, buttonIndex) => {
              button.setAttribute("aria-current", String(buttonIndex === index));
            });
            if (stageVisible) {
              document.querySelector('meta[name="theme-color"]')?.setAttribute("content", palette.paper);
            }
          }

          function trackMetrics() {
            const rect = track.getBoundingClientRect();
            const travel = Math.max(1, rect.height - viewHeight);
            return { rect, travel };
          }

          // Jump straight to the chosen place's floating card, then glide in to
          // its full-bleed film. (A long native smooth scroll past every other
          // place was unreliable: some browsers stopped it at the first snap.)
          let jumpVisuals = false;
          function goToExperience(index) {
            const chapter = chapters[index];
            if (!chapter) return;
            const stopTop = (stop) => Math.round(stop.getBoundingClientRect().top + window.scrollY);
            const cardY = stopTop(chapter.stopEls[0]);
            const filmY = stopTop(chapter.stopEls[1] || chapter.stopEls[0]);
            const root = document.documentElement;
            // Touch screens use CSS snapping; pause it for the jump and glide.
            const touchFirst = !window.matchMedia("(hover: hover) and (pointer: fine)").matches;
            // Stop any smoothed scroll still in flight first, or it would carry
            // on after the jump and drag the page somewhere in between.
            window.__stopSmooth?.();
            if (chapter.video && chapter.video.preload !== "auto") chapter.video.preload = "auto";
            window.__xpJumpAt = performance.now();
            window.scrollTo(0, reduced ? filmY : cardY);
            jumpVisuals = true;
            lastRendered = NaN;
            // A short fade-in on arrival: the stage is redrawn from scratch after
            // the jump, so it never flashes empty.
            stage.classList.remove("is-arriving");
            void stage.offsetWidth;
            stage.classList.add("is-arriving");
            requestAnimationFrame(() => requestAnimationFrame(() => {
              if (reduced || typeof window.__glideTo !== "function") {
                window.scrollTo(0, filmY);
              } else {
                window.__glideTo(filmY);
              }
            }));
          }

          function setIndexOpen(open) {
            indexPanel.classList.toggle("is-open", open);
            indexToggle.setAttribute("aria-expanded", String(open));
            indexToggle.textContent = open ? "Close" : "Index";
            if (open) {
              indexButtons[Math.max(0, currentIndex)]?.focus({ preventScroll: true });
            }
          }

          indexToggle.addEventListener("click", () => {
            const opening = !indexPanel.classList.contains("is-open");
            setIndexOpen(opening);
            if (!opening) indexToggle.focus({ preventScroll: true });
          });
          document.addEventListener("keydown", (event) => {
            if (event.key === "Escape" && indexPanel.classList.contains("is-open")) {
              setIndexOpen(false);
              indexToggle.focus({ preventScroll: true });
            }
          });

          document.querySelectorAll('.xp a[href="#books"]').forEach((link) => {
            link.addEventListener("click", (event) => {
              const books = document.querySelector("#books");
              if (!books) return;
              event.preventDefault();
              window.scrollTo({
                top: books.getBoundingClientRect().top + window.scrollY,
                behavior: reduced ? "auto" : "smooth"
              });
            });
          });

          /* ------------------------------ scenes ------------------------------ */
          // Each scroll stop plays its own window of the film: jump to the
          // scene's start when the scroll reaches it, keep playing, and loop
          // back within the window.
          function syncScene(chapter) {
            const { video, scenes } = chapter;
            if (!video || !scenes) return;
            const p = eased - chapter.start;
            let scene = 0;
            chapter.beats.forEach((beat, index) => {
              const previous = chapter.beats[index - 1] ?? beat;
              if (index > 0 && p >= (previous + beat) / 2) scene = index;
            });
            scene = Math.min(scene, scenes.length - 1);
            const [from, to] = scenes[scene];
            if (video.readyState < 1) {
              chapter.scene = -1;
              return;
            }
            if (scene !== chapter.scene) {
              chapter.scene = scene;
              video.currentTime = from;
              return;
            }
            const end = Math.min(to, (video.duration || to) - 0.05);
            if (!video.seeking && (video.currentTime >= end || video.currentTime < from - 0.3)) {
              video.currentTime = from;
            }
          }

          /* ------------------------------- loop ------------------------------- */
          let eased = 0;
          let lastRendered = NaN;
          let lastTime = performance.now();

          function frame(time) {
            const delta = Math.min((time - lastTime) / 1000, 0.05);
            lastTime = time;
            viewHeight = stage.clientHeight || viewHeight;
            const { rect, travel } = trackMetrics();
            const progress = clamp(-rect.top / travel, 0, 1);
            const raw = progress * totalSpan;
            const visible = rect.top < viewHeight && rect.bottom > 0;

            if (visible !== stageVisible) {
              stageVisible = visible;
              if (visible) {
                eased = raw;
                lastRendered = NaN;
              }
              chapters.forEach((chapter) => syncPlayback(chapter));
            }

            if (!visible) {
              eased = raw;
              requestAnimationFrame(frame);
              return;
            }

            // Native scrolling is untouched; only the visual progress is smoothed.
            // A slower follow on phones lets each swipe play out as one zoom.
            // Desktop scrolling already glides, so the 3D follows it closely;
            // phones keep a little extra easing on top of the native snap.
            const follow = narrow ? 10 : 30;
            eased = reduced || jumpVisuals ? raw : lerp(eased, raw, 1 - Math.exp(-delta * follow));
            jumpVisuals = false;
            if (Math.abs(eased - raw) < 0.0002) eased = raw;

            if (eased !== lastRendered) {
              lastRendered = eased;
              const current = chapterAt(eased + 0.1).index;
              chapters.forEach((chapter) => {
                const p = eased - chapter.start;
                const isLast = chapter.index === total - 1;
                const live = reduced
                  ? chapter.index === current
                  : p > -0.3 && (isLast || p < chapter.span);
                if (!live) {
                  hideChapter(chapter);
                  return;
                }
                const wasLive = chapter.live;
                renderChapter(chapter, p);
                if (!wasLive) syncPlayback(chapter);
              });
              chapters.forEach((chapter) => {
                if (chapter.live) syncPlayback(chapter);
              });
              setCurrent(current);
              const active = chapters[current];
              const local = eased - active.start;
              stage.classList.toggle("is-film", !reduced
                && local > 0.3 && (current === total - 1 || local < active.span - 0.12));
              rail.style.transform = `scaleX(${progress.toFixed(4)})`;
              hint.style.opacity = reduced ? "0" : String(1 - smooth(range(eased, 0.02, 0.1)));
            }
            chapters.forEach((chapter) => { if (chapter.live) syncScene(chapter); });
            requestAnimationFrame(frame);
          }

          let resizeFrame = 0;
          window.addEventListener("resize", () => {
            cancelAnimationFrame(resizeFrame);
            resizeFrame = requestAnimationFrame(layout);
          });
          document.addEventListener("visibilitychange", () => {
            lastTime = performance.now();
            chapters.forEach((chapter) => syncPlayback(chapter));
          });
          reducedQuery.addEventListener("change", (event) => {
            reduced = event.matches;
            chapters.forEach((chapter) => {
              chapter.userStarted = false;
              hideChapter(chapter);
            });
            lastRendered = NaN;
          });

          /* ------------------------------ groups ------------------------------ */
          const tabButtons = [...document.querySelectorAll("[data-xp-group]")];
          const introTitle = document.querySelector("#xp-intro-title");
          const introLede = document.querySelector("#xp-intro-lede");
          const outroSwitch = document.querySelector("#xp-outro-switch");

          function setGroup(id, { scrollTo: scrollTarget = null } = {}) {
            const group = GROUPS.find((candidate) => candidate.id === id) || GROUPS[0];
            const changed = group !== activeGroup || !chapters.length;
            activeGroup = group;
            EXPERIENCES = group.items;
            total = EXPERIENCES.length;
            if (changed) {
              buildChapters();
              buildLists();
              setTrackHeight();
              layout();
              currentIndex = -1;
              setCurrent(0);
              lastRendered = NaN;
            }
            tabButtons.forEach((button) => {
              const selected = button.dataset.xpGroup === group.id;
              button.setAttribute("aria-selected", String(selected));
              button.tabIndex = selected ? 0 : -1;
            });
            introTitle.textContent = group.label;
            introLede.textContent = group.tagline;
            indexPanel.setAttribute("aria-label", `All ${group.label.toLowerCase()}`);
            const other = GROUPS.find((candidate) => candidate !== group);
            outroSwitch.textContent = `See the ${other.label.toLowerCase()} →`;
            outroSwitch.dataset.target = other.id;
            if (scrollTarget) {
              const top = scrollTarget.getBoundingClientRect().top + window.scrollY;
              window.scrollTo({ top, behavior: reduced ? "auto" : "smooth" });
            }
          }

          tabButtons.forEach((button) => {
            button.addEventListener("click", () => {
              // A tab inside the 3D stage restarts that group at its first card.
              const inStage = Boolean(button.closest("#xp-stage"));
              setGroup(button.dataset.xpGroup, {
                scrollTo: inStage ? track : null
              });
            });
            button.addEventListener("keydown", (event) => {
              if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
              event.preventDefault();
              const siblings = [...button.parentElement.querySelectorAll("[data-xp-group]")];
              const next = siblings[(siblings.indexOf(button) + (event.key === "ArrowRight" ? 1 : -1) + siblings.length) % siblings.length];
              next.focus();
              next.click();
            });
          });
          outroSwitch.addEventListener("click", () => {
            setGroup(outroSwitch.dataset.target, { scrollTo: document.querySelector("#experiences") });
          });

          const startGroup = location.hash === "#wineries" ? "wineries" : "experiences";
          setGroup(startGroup);
          if (location.hash === "#wineries") {
            requestAnimationFrame(() => document.querySelector("#experiences")?.scrollIntoView());
          }
          requestAnimationFrame(frame);
        })();
  

    /* ---------------------------- Smoothed scrolling ---------------------------- */
        // Smoothed scrolling. Every wheel and trackpad movement is applied at
        // once and in proportion (nothing is locked or ignored), but the page
        // glides towards it instead of jumping, so speed feels the same on a
        // mouse and a trackpad. Touch, keyboard and scrollbar stay native.
        (() => {
          const root = document.documentElement;
          const TLR = window.TL_ROOT;
          const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
          const finePointer = window.matchMedia("(hover: hover) and (pointer: fine)");
          const SPEED = 0.85;      // share of each wheel movement applied
          const MAX_STEP = 140;    // cap on a single wheel event (big flicks)
          const SMOOTHING = 9;     // higher = tighter follow

          let target = window.scrollY;
          let current = window.scrollY;
          let running = false;
          let ownScroll = false;
          let lastTime = 0;
          let lastWheelAt = 0;
          let lastWheelSize = 0;

          const maxScroll = () => root.scrollHeight - window.innerHeight;
          const clampY = (y) => Math.max(0, Math.min(maxScroll(), y));

          function scrollable(el, deltaY) {
            // An element under the pointer that can still scroll that way keeps
            // the wheel (a long description, the book panel, the index).
            for (let node = el; node && node !== document.body && node !== root; node = node.parentElement) {
              if (node.closest?.(".detail-panel, .xp-index, .mylist")) return true;
              const style = getComputedStyle(node);
              if (!/(auto|scroll)/.test(style.overflowY) || node.scrollHeight <= node.clientHeight + 1) continue;
              if (deltaY > 0 && node.scrollTop + node.clientHeight < node.scrollHeight - 1) return true;
              if (deltaY < 0 && node.scrollTop > 0) return true;
            }
            return false;
          }

          window.addEventListener("wheel", (event) => {
            if (!finePointer.matches || reduced.matches) return;
            // Embedded: only smooth wheel input over The List, never the host page.
            if (!TLR || !TLR.contains(event.target)) return;
            if (event.ctrlKey || event.defaultPrevented) return;
            if (TLR.classList.contains("is-reading") || TLR.classList.contains("is-viewing") || TLR.classList.contains("is-mylist")) return;
            if (Math.abs(event.deltaX) > Math.abs(event.deltaY)) return;
            if (scrollable(event.target, event.deltaY)) return;
            event.preventDefault();
            // During a page-made glide, a trackpad's fading momentum is ignored;
            // only a fresh scroll takes over.
            const size = Math.abs(event.deltaY);
            const now = performance.now();
            const fading = now - lastWheelAt < 150 && size <= lastWheelSize * 1.05;
            lastWheelAt = now;
            lastWheelSize = size;
            const justJumped = now - (window.__xpJumpAt || 0) < 1200;
            if ((tween || justJumped) && (fading || (justJumped && size < 12))) return;
            const unit = event.deltaMode === 1 ? 40 : event.deltaMode === 2 ? window.innerHeight : 1;
            let delta = event.deltaY * unit;
            delta = Math.max(-MAX_STEP, Math.min(MAX_STEP, delta)) * SPEED;
            if (!running) target = current = window.scrollY;
            cancelTween();
            target = clampY(target + delta);
            start();
          }, { passive: false });

          function start() {
            if (running) return;
            running = true;
            lastTime = performance.now();
            requestAnimationFrame(step);
          }
          function step(time) {
            if (!running) return;
            const dt = Math.min(0.05, (time - lastTime) / 1000);
            lastTime = time;
            current += (target - current) * (1 - Math.exp(-SMOOTHING * dt));
            if (Math.abs(target - current) < 0.4) current = target;
            ownScroll = true;
            window.scrollTo(0, current);
            if (current === target) {
              running = false;
              scheduleRest();
              return;
            }
            requestAnimationFrame(step);
          }

          // Keyboard, scrollbar or anything else moving the page: follow it.
          window.addEventListener("scroll", () => {
            if (ownScroll) { ownScroll = false; return; }
            if (!running && !tween) { target = current = window.scrollY; scheduleRest(); }
          }, { passive: true });

          // Tweens for jumps the page makes itself (clicking a place card).
          let tween = 0;
          function cancelTween() {
            if (!tween) return;
            cancelAnimationFrame(tween);
            tween = 0;
          }
          window.__stopSmooth = () => {
            running = false;
            cancelTween();
            target = current = window.scrollY;
          };
          window.__glideTo = (to, { duration } = {}) => {
            running = false;
            cancelTween();
            const from = window.scrollY;
            const distance = to - from;
            if (reduced.matches || Math.abs(distance) < 2) {
              window.scrollTo(0, to);
              target = current = window.scrollY;
              return;
            }
            const length = duration || Math.min(900, Math.max(450, 300 + Math.abs(distance) * 0.5));
            const began = performance.now();
            const ease = (t) => 1 - Math.pow(1 - t, 3);
            const tick = (time) => {
              const t = Math.min(1, (time - began) / length);
              ownScroll = true;
              window.scrollTo(0, from + distance * ease(t));
              if (t < 1) {
                tween = requestAnimationFrame(tick);
              } else {
                tween = 0;
                target = current = window.scrollY;
              }
            };
            tween = requestAnimationFrame(tick);
          };
          // A new touch or key press takes over. Clicks don't (a second click on
          // a card used to cut the glide short and leave an empty screen).
          ["touchstart", "keydown"].forEach((type) => {
            window.addEventListener(type, () => {
              if (type === "touchstart" && performance.now() - (window.__xpJumpAt || 0) < 500) return;
              cancelTween();
              if (running) { running = false; target = current = window.scrollY; }
            }, { passive: true });
          });

          // When the page comes to rest very close to a scene, ease the last
          // few pixels onto it. Never a jump: only within a short distance.
          let restTimer = 0;
          function scheduleRest() {
            if (!finePointer.matches) return;
            clearTimeout(restTimer);
            restTimer = setTimeout(() => {
              if (running || tween) return;
              if (TLR.classList.contains("is-reading") || TLR.classList.contains("is-viewing")) return;
              const y = window.scrollY;
              const list = [...TLR.querySelectorAll(".xp .snap-stop")]
                .map((el) => Math.round(el.getBoundingClientRect().top + y));
              const nearest = list.reduce((best, stop) => (Math.abs(stop - y) < Math.abs(best - y) ? stop : best), Infinity);
              const gap = Math.abs(nearest - y);
              if (gap > 2 && gap < window.innerHeight * 0.14) window.__glideTo(nearest, { duration: 520 });
            }, 260);
          }

          // Fade the bottom of a description while there is more to read.
          function markMore(text) {
            const more = text.scrollHeight > text.clientHeight + 1
              && text.scrollTop + text.clientHeight < text.scrollHeight - 2;
            text.classList.toggle("has-more", more);
          }
          document.addEventListener("scroll", (event) => {
            if (event.target.classList?.contains("xp-caption__text")) markMore(event.target);
          }, true);
          setInterval(() => document.querySelectorAll(".xp-caption__text").forEach(markMore), 600);
        })();
  

    /* ------------------------------ 3D book shelf ------------------------------ */
    var cfg = TL_ROOT.dataset;
    var CDN = "https://cdn.jsdelivr.net/npm/three@0.165.0";
    var threeUrl = cfg.threeModule || CDN + "/+esm";
    var addonsBase = (cfg.threeAddons || CDN + "/examples/jsm").replace(/\/$/, "");
    var addonSuffix = cfg.threeAddons ? "" : "/+esm";
    var TL_addon = function (path) { return import(addonsBase + "/" + path + addonSuffix); };

    (async function () {
      const THREE = await import(threeUrl);
              const { OrbitControls } = await TL_addon("controls/OrbitControls.js");
          const { RoomEnvironment } = await TL_addon("environments/RoomEnvironment.js");
          const { RoundedBoxGeometry } = await TL_addon("geometries/RoundedBoxGeometry.js");
          const { RectAreaLightUniformsLib } = await TL_addon("lights/RectAreaLightUniformsLib.js");

          const BOOKS = window.THE_LIST_CONTENT.books;

          const UPLOADED_COVER_DATA_IDS = ["epic-disruptions", "i-can-fit-that-in", "letters-from-the-edge", "drive-different", "you-already-know", "leo", "bobbi", "1929", "goat", "jordan", "ceo"];
          const UPLOADED_COVER_DATA = UPLOADED_COVER_DATA_IDS.map((id) => window.COVER_DATA[id]);
          window.__THE_LIST = Object.assign(window.__THE_LIST || {}, { books: BOOKS, covers: UPLOADED_COVER_DATA });
          window.dispatchEvent(new Event("thelist:data"));
          // The walnut map and the new GPT Image cover atlas are embedded so the browser
          // never calls a generation service or depends on an asset host.
          const WOOD_TEXTURE_DATA = "data:image/webp;base64,UklGRrhqAQBXRUJQVlA4IKxqAQCQQwWdASoAAgAEPnk2lUckoyIhLHQ8EJAPCWcAw28XWceQv1fvl4T3rv/3/q4yu++7n05er3/4+sx/4vT/5+OhL3QL14P4L0/Xr/4Y9En8+/fP+L4D/pXvw/0X7//+r5N/0j//7k/sf+F5i/1n+Df/f+R/zPg5/3////3+Lf89/3f///4+wj/Kf+H///+/3c//uyZ9v/+egv+r/6vLf/D///7w+x36v/tP/90H/8zxa/qX/I/d34Jf65/uv3A96//8/fr18/zn/6/fv4SP8V/9v3t7a4ITxGtlYxk9cOWAomEwB9amy8C/iQiu5a81pGi4CmyUKcfdq0NKDSap/H/hCtha69y0mt4XN5zShs7mMu8zpGU+MnFxrb06Ak4nZZDcu0uU+XZ8mBFpEM7q1dUxToGr3+lgfIsKHj3BsLOuF7uJ+1SNyHbyIDvy0SWNFIDQ1ROefjHfUOn+vwkBLc2qTaAp/9A9qxuyDtNmcmwdx91sQaFTpSf6aM/3I2YO/kq0V8NR4MEKM5T+DHVTqEWeRBEvodPBd7BxDR38J1cXlkDRvm/alHXqtTYsK7V3g63WyiMXXUuNVSNCR9ivIeIcn40o1CwXNo4DFehmYTy6iJCs6TOypx0rzIjMoHTD0n3VKfJp8k5NsiqFThNl2FNdNqUmnBGa3B2+QV4Xb/vzpHGGu13CJ1D1DKgpWA4XK7ANFrxAAgsW1vpzRDPhxMtGzfCVnmeS2cG+LxYDjUuPLL7nqzin+jU01BEmklr4cMvEJ0TqhyjTijRMXo8KRqeJF2xc6s35pJ2yjRv4psH5oUXOMYMLi4QtovTp72PTaceCOg3RXIGdTjfpCiG57UcBhZMRY3KavTZrwYQFD6YAssM/eoSgfZss2Moxmor7Zu5m1KLoBbJcxjW1n4gMd50XE6IXGDDXEga8Cq2eTiM0UbGlxYQu3zVAMyIhw0gU1xMlB3eDQ9jnLu8+L8MRRVMgPfhH6EnT6bwSCheNsTQcWkivx2ztFgpkKi4hK60zKRKf2HuhytnFk8xV473N/rC3DUGYypoG70S5h0nPGk989Vo33BJIPMMOK7trt5EIky3wnmAf14yBQI6q5o2uct2toG9tEOTsScUTLAx7Nnoeut8UfNAL5b73pMD78uehAkRLSqOXCrlZoI2WutlVbiZfeYTIZ81TU/pBv4aq10FJwJ76tOk2s8JAObpimB3BK+abhXLCjvT0nYASxZ8/y3g6d9hbH304YTDD00hHIMqPHV6b0QtNpMPWGseEaxph2E5D/91jZgSG9749YZRPQwzGb7XOUsUf+bjoWpCnQN0DC1MddLElJUOP7ewwSYliMuxaQZdw9g7lYUd6cDkG8WvvH16z1eHwf14jchjYVhe+KB/dLuZn4JyIBnKw9IswE9orr9ChgMN7rvGPh8x75MIlVoCesYiDRuoFouFzGPDrPyx8FDcjNUHE0j5/QB01ivRwTOhCqXEo7zRFl73+AEt+mFomzf162WcL4ztQRUMVChkp3f6VZlFiyc/6PVw0siP05YW+0RL4XNCicIbhRp2sncwHZNIXP8Q6VSrvAQYXNLaD6ul+nTVXzXNsFYGtJ8IwkWrX4mRS3L7diStOfGwvyU6BjEAJnm4XqEqJZeF+/i0FqYnWhOlnASYA/UXZ1OQJALRtLt8wNfYRrR2iBSj+Z2JJoeIIp0EwevLyYctHlD2LYb9iNNlnQ6OyKO8x25xWYWEiyrkPZnDjgMScGe2IRYiBKRwK/ZuP47BaxVEaRy4hxNwxnicqDszUdUbX5uSyziBKWkd5lCtj+lA81CTQsiwK2xxbJ4kSs/0F1UbnzAiyPoeFYjX4qfnJerwNB6NIVI/626BJDgQCQyUhvbeFvW84rCU7YCtn7O5UZYrEy1WrODD5zToIYd5m5V0uDJSLCxZGuA1nHyTR8gc8lrkljlL3tQMJMfRNjNA+0CifRunR96UeF4f9GKL61Ra/2QXOWX0kD2ov2LNfuSL8N1s61DuMlCjMMDw4KxMVZeoYxg9gUIEHFInRGwmDuLZ41fZMvhCU2DIF/XOYGpZaPYhEM67ZioMG9vmJ1NUTrfko9NJ21pKjWysBweerScjvmIo4kPx6IoHqzWAGI4w+72NTnGeGQo9Jrtj9yZKqtntvTjDlKYcFeH73dqsCYu/e6yYEgea/RCGUi/SUC+YXPLr2+IQIRmYD6gOhaGnzBRfioJykQNJA0mRmiaMt0q0KShBq1E4Gz+HC7mWxIgK8B+ax1bQtK7aXu+SO0KN77K0SgsbRMCY82S+rJrK+gLwsVx7bNUTxHVYTfQ/g+PuxEEFnzLtaXH7aok1q3Enmf5sDm3chPJ25XRmJWaNt5veYSxAUm9VptosoeYPrWFnrSGdE0sZdVp/dRo0NBy5t7hpHFrAfio9C3odkpdKvpL9y/DjSMHD1HJ2/aFQ5VKdUStBSzEmo3UcFfEVhHytpF9OirydSEUU+PIUkQFlK28o4skXamAHBZzUP/fdy+ok5CElctQ9SrfP9nYxowMgwSrUoe+aniPbHZWBLSCpNYJwwVhCkx2wk/rpc/ntxoJhSGLUBudiXMQ7auGqIjq1cm9idnYm5js1Of54/W9xhigJnOZY++MuMBmey9CMDrszzWhO2MG3uQltK5IOi74MAKeceux757J+O/I2b3YWfvisM0qkinvDsLSXv673zG3h9Mqqkj1B8eZDDdp9ZNAgoTofN+1ipaWnwWyrSdugb5lSj9OYv14xD4VSC763ad/3DVRcvieboDwr1dkwjnsJXs/FFQ0piknBOBk7hZXME50fN7ExeaBCKsCrO8YORlWKL9Zso3P59d5PjeVAkwnh6t91NNzHnu1aCObYhNCNMUcLBICBaxksTGlkTYtpxY04D0dib+AsKcXVi2qr23zkr9thgE8c28xSXAzZKNbGzICpvV7s1wIL0IWXLPtYFRdTC48TgHFCqFtq/e4nwpgIGhBXPGfJSF98KDpW6yY12UIK+ijx5izbrELC2oYy+BYXXafGr4calJok3xJiEi/GZnyV2SDmF1hPVel+8o9758pKekfTgjqEhjTlrhGfbdjvI5xPHJy05uFUL9HEfxlDRN9MUXiyZPermq3L/e0KsCWaRy9G/gnGZlRtYlb1Ojkzet8W/n87tmmARIafdWumoOmAXxLA++GhxTq8VyU+Q3KqiYvRIxAHqHoVCKIgYXhO7BpNHM+vrpS231SsdmZTKyMiDgAC2l8tSEmiaswCZyMKR5WnsLPPlPAFJutkPyQ/unqkerRlI59VSNKp6w2/XpGR4TBkH6C13ec6wGocK0zVU8DPihekpraHBWKMc8/Gx2dHW/vVocuqGC8AG7iNcXWCWaJrJVdJJghvyBkqVaSHEzPpNfKjwBSDfhQPWy3+CSaAklkFeBdXpvbbkBokkJPMZm2qqB6HEp7nH/xTs52/ldaUI1GFhUCJonAq3qbwAo49Cfo/JDIpy4b+ykjFZ9evsrHDChwsAS5VPTP+eDMjSGCuGXldm2awwjazuxpq2TDlCe/SaAFig0zgiPajaHM7Gfvm474lbjg9oi0HY6S+hUTP/hC1cHHKFrxreMea/7vU5xbxuN3knFNOGpVNu3K5CDdTuN3l0B0GZOStune0MREv2iNmArKOdk0qx+vr1NA+W750FPWvjsA0k6J2GfmpU/5gQsy/3WmI0O7SL8Ew6ITkHKTA/oTRsKCi9tWMWe9NOe1xgqqC+NvZn5vkntGAWHuR0cZxzkLz3QFQIbUqQOSEEGr1mMMmfCBKvMciNxxA/KV3wIk4iqaUKB4TV3jv2zr2oGjwpL/eBLU+zg4reaixoxV7IcyxLhoUY7uHcPQghk5FL5J+it0j+IW5KXG7vcJ+yVvJMXVkVp+eFVJUmEq9CcVTvnzHllAWOfbb2WF0ypsy62djVP0sC011HQ7Td3t95Zhq6pCBCMiBI28stCCVNGFRs+iOje8R3MESg45JvqPqB8q6m1SlXz9GA28REksrOlDRNu6X4+kt3lfmsDXGuR480jJik6G8gIaTH0+dkXDcjxosKqdMBHCe5vQwZidO9wTv+XbNy7eiN8AwwoAnE6Vx+KVMQOy4tXbERsnYKfBEocnhu+JUgaWoIs0R6MnIJ8XfzY6pG4hGEvydMk9FNA/4qm4ZEcKxdGk7oMxlnvp69pVk3ykH+mWCsJV2sSQa7BrgZu3l8NdFsKM4oX7WJjfBCtSZXqAvOxsTkPyPhhqKUruRUMqsOXhiH2l3qtxX12Q90EXFhHYoG3K4BR7i1PG4Q0KfrbpExQsCxt6c4eOYVpnVZOEnBAGyaLI3qNW09T0c5FOgzeMT/TnDS2DRxyZkUNOeLcFWQlCHqAjSDwW65iJ0vFaM0E9+EE7qlAN8uJFQ0AHoKq/jNf48GPjp2CDpfJFPhPtN+TfRtBdvMmyLtAiEThAIFqW+vxors8gUldAfGGuuYUqy6/smiycAZr25DKjGoKvme3oKbTGaCl9XTIOSAmTKAxAw6jDxBpr7EurodPX9sH5Sxh6cW5r8U4+/Btti7SwK/1lrQL1tIXiwEcR0doLxfKev1Yxo9i0CCkZio3zdeMO9X9/ZZzN7gl3tvDCVVhyouG5Q2m6XrwX3+80hlyCVQHtXl27KCq7pyccDtOJExqW/YnVW/E3yh9rFukhnGmfLfrvK37IWrQoNvY0lxL3FI5sooVw/xuKj8GEkJrxZ4oCdZd8l9rNFcLcCEahDKRS3WxjTuvI2abEHxNJvEpJhU6mUWQlNRW/i8ZOfyuojKGtTOF1fQJSyyIntnhZqk0qyeW/dYzrAL286qlmEuxfO2XncJtMBypffaroRMlUCnsLaRDmCf6IPFp5XdsWv2AN2EM0aHJMWYMk1fBaNcuCg/66sW3XFb2bxT1g/5ou93fn8pR7jSdAcaQssyHvaw0nVsRW1/t0TNUaeDpDmoLEcuMxhrpBEEtoxs01VjtR8h/MohvTG+HfJw/MB0FB9Ra9QzrDlYwMVtCGlv5GSCQ6rXUHPMH3nn0YJrOy63malf+by0gZ6VzsGisK2dAUeyEVJ8nUcWKBQHxCQTQgW/easY+v54L1XncVW3FcpoWZz5aT5L2hOXwE/a+g76Yi2GWVpxP5z5JNj5l1T4ufoB4csf9BHiycOeJ3D7AFfdkN5SsupKoXcKbheP9gbyl3MPCrnZ3Km0Ul6vCvLoGndR0Ojbcr/GDGyzRUINJo5EoSn5b7Iobb4Hqr8WfNzUKGkhdufRKOIWqeCpdjFCQio+C2r9vmdOEuqqGz4A9PIXQYPgRT24AwKTGlFDguO9csuixV4fUvJ+C53UujcP4zG9fFIWcANigKJ3cXOqBj7rhWVqWr7TTmf5shCXvE1srBKuGL7KLsSz6cPz/TRL4XN11ujdyKXNjrBZE2k49HmfFre7WuLeWKKzz9BgHwiW++evTXkeSkvU61zRMuU4Kf7A6FE+43/GfQ8oyAb25OOk/4cL5s6oggKFjXV5LUY8/7JlhY2ZMwTvXQGMxT3hTSjh2TFHnLqaouHOuU/ciK6yZVx1bnmbjW6jq2pJNbtBU9qss2y9I1NQZ9fmZ0qQfCwbPSy0i/1BaCFTUBXFuhbyizmfTDHP9mV0Vqg/TGEfVBeXBlA0IxcgpZ9vLSdF6GiJ2chqfWbHSHSykDm/co2MXbg2QLqTQ3PLh2ii1u2a8pxJqHMRn1AWsZdPj1uwIOgqAuq17FNN/6Wj8lFZNhiXUZ0kcvoWj/M90GwZ34jEc4yJoVeev4L6VMmQ2ifJtVONnhWkNVOIcrISKiaIlQFG7hd+6Q7sHrow8Vudgvj3M2z8yY0W7a+YyrJr0YWxCUW0vxaqduu3Igrjo9MFfA3oYd15m0rvIjVjuTAbH05C9fK5bgWMqWhgvzBrtrJB6DtjkLZZE4ROkMLDnp/8lOWskiDrY7vzghSkgBUNnOPlk6WMJUJf4CSqko4SEW/pNtmwT1RrN5k/sHSTx7vghnd5NOxar66CzMs9awbmVvy4iqOO61o2X/g+O/1WO6Ec1Fj7AP4CnMcqSC3LaXACt3qhLhpuX9PbvAKII8pOw7IiPUQm9UsByhgkOyJcpPpnItHs+VSMTa+4u4Ei/jgoGRmKNReIm6g2ciFq0Ksf1PD6FZWu7PSL67BAJ2hu2BPNj2ShST2giFUAL4ZkA0saE67rjgA6fM/kngp5et7JjjGDBUgsI69WgUouqfvY7UG8WjgvwkRMQW6aoGxglKl4ZVIP6SrR1C1J5lOEMe3hBAvdkLda7dJ6zdsnNjv2NaBLxtn3/KLmXFIzDLQI8+efryibp69YX4wYrvwGofTHMI+osnG8O6rkdpvjmlE2PlHLmO+T6QBQ3p04JDnCGnk9tpkjIbKWPV0pBPKUgCO+K9E7gyM4I0gUa6JFxUGF0ZkzzIxGvXK0I/aDEySPm4dUXvDsIP9zmylKHnYpTDPbY/oJ96xS7Rvjq5n0nuyia/1ArOt2/wuNaE3bYDCfCB72koF3/TU+uTGS7KktwvFiZNz4jI2SZO+ahLsaE5sHGJXxx2cOuT5BAv2Lzj2Ad9qI5E6nNojr9uCXjHQ0fjaAB3bM4r5umF+ujmAXmrckwYpnbmipI+mlITOwV6SjuvmobsceIheAiQTn1x15MqxphWVCeG5dDljayOmhAOUWhM45OyqA6bVPI+sCEgyNdTeIrmpMfkGwh6P1ogED9GLAjsdqY+valiT0p1V86T/eyJpGYHXmJieAnciyeUBTHxjUjn9rJqps+dEi5yLOsQN6nETcVYLopyY3frKU5Rrpl2SqQHCIyQurChdKwFUWjFFH9g1Lv14kf/h8icdCCBXzNkT3HKwe5VH0Ph6+7u7jTLfSj8SxXpJHLgtHBKzqEP6sFkBlONoGI71cyqDqwu2X/05RIzlFCFFyenff8J8Y5LT318FeuJi4WBSrzVcS02UDAVe2Vl+G3BUgxFYiVdpNakvf5aG1YHRIgG2GLxB3OXqIi7eFkRu1zpDwMhGVLgv8xEdztMkZrGXxqewF+C07LxhzqgE5Db1le/o2KqVy2HdQjBuhP3crFHcpPIwOzur98jVMo0UsljT+MxPZErebQ9Xg/8MgKNNO5CYMyBO5JMeOl0Xo8SoJthvlkYB1koj0pLjHtaHNohMp2TEejselsEfpYkW1+l0kZgS8NZOq9b8ZAJ3OX+cNK/LvW8SxpHLHKTfjdksAtjfBuw8UG8y3nsiRJPJLjCH425LvW5/8B7rwwc4flHFxomGRC7V6ivmMOPUKZRM2J8hjoa3vb5LCzVqok5+GZ+6iGpV3TWaOt8U9m0eUdUzhObXlI5D7+X4B+OImwtf9Hv6q61Hi+bB7ZjWGn5EeeiAmHsv6mpghrMGUlCGBv2/ZT5h6ZfygilQB4RM2LkFV9cYLlUgIUfF6u9iO/WrPHY025WwmleFnZkcdqSzQipDYT2qcOK98DviwyQ8PNFhPV/N1H23S1kJJpAgvQeROFgoo/VFzaDybkzxejPKlFkiOiYId1zo6nqAho2NhJsdgMCHSkdsJk7BIl+6UEHnstMUhm1VdcK5q/6bK1p9LBarYT/nDNlpC8IHEMcfjAIIP0qqUqAEGagvEPdQJU5b8qUbItEUQta4QOdVrZFbsV1EJUglyKhQ8gr4eFR1cvpdU4tvwjRcfJiVkmpOBObfn2u470arChl5zP9eNAurvra9w4c9HsQQg72r3wDypzfNKXEiRhf3asUTcC+VCv4o02xh/xtRW2TYBVpXqPOj2M49pg7M4OlfjLFmj17fnv2C9MH1l7gQ+AlWHxWbHaEls29IX5dXY3CDhSg++YUxkjaBEAes1U/lnPgE/yFnUHnMOjmQxa3/aWXYVqiefZEk/qpJA/zWc0+hppKtNde3bPzDJdAP+P+SBAkhg3hxvEgShcMWUygkXf/pBeIGQUws6xT60enfjhBDU5bLF0hHlVlcjx80qwoFW0T9k4/KcFIJnFwOc5xTK5NvmGeIA/M9q/jz6gd9kxi6BiN2AM2l/BZK/bvxt+KmowMOn+VXSLIpHfu5NnQlWuwZnjn98lh/ILg3gRyZZw/rploZM+aes065o/62b1G1Cx6ipBsGFhFEgNjODjDj/G3KUr9hHLw95raig8p82Xk/KCiTPC0Za6cCkqxLf5Py9/ZOfQryZf5QOeq9/KHBn6V2y73DUMtdm7JivuhkPC9jIf1ZrEMIPqdJljEY+y0o0J6Zr577pHSIX+wG1oPIzb/4gfMkBI416sRNHAzEs6qvR48udT1vlAdip5Afb4FnuxNoikl+b4oponFc5OpWAceBihOUAISChEHEM3A1ojX+EMWO5UzHMw7K3NjCLypbiyOtI9W36Q7hRTZjf+0bzVWOn7zTSbvwQPdGlcddKHUpHT/LnhBVNfN6qUevnUiBaAmIkqptuq9Sqm8HIMUH99AOX+alO7s5BuGuZWqBobhdooMUulN0r8r8roOPCiXw14R5xpDjZezIpDETVX2e0iuogKF8239P0ta12iM3UnIqeSP1/y8xH3kW3oN4N8zeIgcA5+54Xtanl97G8Jjb/FyU82klO6XSFcXGRsqLbIzLokzlinSel9k2oV0UmwbNFv7oyxxcdk7NLJHwadFNx2ZKmulElFNxTao9DIkQ3Er0BIxmhvzNzz9BJabjyL5mlCZnE0SEfEhPOxRvZuMW0GTyxSsSk9hKfRcMu72fO6bqiIIcCdTKR0YtS4tMikmkE1sTukbxNRExuOOw30CicpHw/7+Hc5lLIezhWFIlKdZjsaTDjY91TPRdk8I3r4WSvRec6rrhViezwrUUNvG7fJoAOQHWBBVGzkPuBVGnDMfDiBe1Tgp9ySr+wwK98xyLYsQ6A6mMQW2J/ODjlSAnXBW0fZH4J4rOktPYq8hPKkDD0iYTUYMm7LNttqWRA2P0aG7P+ytP+9A96IrUbfS+JtmNlxRHHRpqcM53DFKwnX8CDf3rFO8/O3eeFGfpi2O8lNYsLHngFe/VuvCVYOsYO50N+HXScy4C9gU74E6isszRz8Ry5jwKlgKTqPKeRqrt9ii7nXHZJ3YmNvBOmR9HV78fTBfrIFiIrvYOcr6hwBaIaV5mZWg/X+3wHCN0nLna9377niPtrqIKw1tumddP/TmaQbhQwnma7hADwdVIdUQexqioW1ap96NO70dgvad/7NRzCvokB6zxP2qhm73mpMydq7swhTXAkyPLvoTK1oZXKKZzYCcf+dxUim/w5mH+uDYC0VDsQfHuAnYR0yWGvTUlgPMoW2XUeCvcwkRWA/d8ZcKMBI49VmZ/sOTcWQyRbNOqL3kqvhJoGTVPJ2gjZQqr4v3anGek+sCNBfOanmARG87pXO2AeGsJmVMD5+5ylwHkLa5kBifMvc975aIb0ldEW3PkmapHbYTzGQA3C+ogNcgouw7kVKzVcHKFfkkji3eHdWthYDLeL145XOKO6xTU9I0GJevoW+MQttM0Okg1uj90SyH0O/S129Q8ptnnSTHyMTwAyivBVj3k88R7wXcH8iudarbeypP73Q67LHF9ukDg1VVeu/Jq5GGxa+eV2R0qAh9To4DQrdKZNbRFkR8rzR2KThH1QwsBPrN3XmAmZ3x6gIkyOSnoe+JoTgI/YgFII6dJGVQ0VXssDxp8D3OvMh6HRHvy7g+PnHWq2T9kTdObLpt9IIMe9ppA93oXDTe4+2HuX3rde1Yo4H7OuQTW88B6nTAKsqBE3NlL8M79BEbpu7Xq8RSqdMDx+XKTQrR+BfTS3QVcwMHNs87RKRLm6QYFTYZ3VENG/N4sPuxcorbl+fK8M+/brO+Dgahe9dN7YUgqGAE2hkVr7l8coD4FTLolJVr2iys0zMFvscBl0ENvACJqmkeOqX853vhjCfEA1DrFipr8Bp+uiSu/6pVDs3qKHWlspLjSUNAvSKSZ7EtZI5vLrZL1P5X3+AsieeYqxLjE6kOPFpz3FxJdZmoBz6Qzz8LwuvdSb163RH0NSM340rUAprBhHiDt7ZLoB/3qGIKaDlFlUXw8WMxvn+zCilFYBNGstSWuz1GwSMkBWL0o1aUpHw7nHc2JrMFvun+88u92A+x6D2DeAMngrGy7SQD2934nGJ+G9Z09qzVQ+d4JYyuRPl1SXtFhIRqkWzrEKrGX19lW2bCd+YjW+aNWnXkR1FZyuuFwJdgLfnG5r4tZ1fnZQ/1zqZO4oD+2DXjIId3JVEWwCN10gTsjb84B/+eboUDGqwZtCcYlunfhdqxp0XproUyXLkGfzDAseRb5WkvkCV0vzFpGVPrCLV3ry/MfA1ntjcI1todZ/TnS/2AVfmyDuze1bHdMXvClpbw3gB8lAaP/t9zCtNumrEwFtLgLdx6cEYXHt9OuqIsfW90pUFb2lm/yI3ZaMy6ouUVIjiwY/yPa0eU4QOI0O4b+DY2r+ayaYkmlF9Rp/Cj8/my9qah2P4EmObGLLlh8QwXvpSHyvzIbLlFAdAHg8uliSER2kG4aSogXq5Usch+HUahM4+bJ6lOouTLm1eXx3GMmPEJDLiG9/RYUtalgwP6aqo4r9HJd1LqTJTc/IoqLkwX+TevdGSdfguvLyVQW+o/Ncx/WR/LdBG327pTSOU1nUCoJwr6nt0IWyvYlHY7bAzn1OBd5DCUHzkY3AghsooVHen4WpDeavHq6RJpM1p/WxYV+TLVYHAPm40Yom+zE3Yzm87UiePgsSKxb2QFEk2u59d6kzReMrhS2Ha5QZ1bMchaZlSHf9GJZ6RD4lM1gKwofMgNRRiNFhMMUjaPVFbxzn9nC/fQurdIcN2PZVTEp614RdHhV7BYGBm/yQ45py0+ke4HRWu5IZXEkU/Qmb5dSUMT6R1L681oXRgf4RemrrZKR8q3YZDSqrsfPjXSUWshRc7nS9R9kGiVDI0drKRF0+GgV3N6RCtwwQBRqXGpCTuXp29BIOjOUipLx/3aZdwWYAOTODUKaMphzvYD6GaCYWlLO0Unx0NEsrAhfPeRsnT4XWzKcZUnliddD3PqgNc8bKnTaUdZ4C0yWNlF1pmgjCMHkPTAZzeo64gUdm6ln8zDrJXCJwQFBd4Xy/iPNCWumwOKRSO3j7S1U4hK/1G12PKHFK0Quo4HOw0323nWG3vR28jrZTQ3sIT5pyRmJ8YlerHmxachqqIAC4vJMJIWRvOzrdtwaRDhMRNfiPad3QDEau2A8VOjW/2n4U6DpvTNiK9LefcQ1U4i7UkXsznKzwPV5VDr6X0qdIoVyv+dp/Amj4h8R/c2teHsJ0vvvWt0ot1tLoN3nKktxJhUoDJMS5BSW23X+rI0Ym7tGLD7J8+yM+4VC4lTpT2FPdzAdZjV0xrmBnPjBGjDwoko6MAZuA62ZB/8U5C5Ak7D/Qb2BYCmXvClUj+ibjdOt9GPMW5IS2yVtomi/Th6hinc7Z7j8BAOSS8BzglvxoQv/L3ONoHFSmHrkC3FyZBvBJlC55djK0obQp0s2PPxf3wV2s85V0CA6ef1HEmpuG7Sph6Y8IEY7XNi/zZqB+4j90RFSudBSA0qtzaVqqdHtWhkw62aofEbWfqEHp7cyzdY9aRqEnZdUBPfSsZp32JichDo9RbNGbmdzPbiSBmeVCRcEnmcJoGLwtFr6BgqgxW5PitSxP3ogaz75iTqdAU+y1yquEZL2i7ixAXvndSD0vKe4lWqLFyQMm8yOHn+j4GC+NkBCfJ9iZ2qiOIR4J5xtPupig4G3YRYH9ccJl9Aq1So0wWIrPtbj4EZmOpMprkmKfh35Es4nMIfHLpha4JZVe3B042KfkTe4jzAEq2YQ2oH7edhu/RA111zG6ezNq+9YM2P1Ejy3aI0L7LxUg7aC88jwKwQjKHkKcw/oLcj7fptTN0I6qJwGOdyxbg4PAEMZKi1Pt1NsHqqarVJjbA3ynXCsr2jXy9OVm7y6EwOaMr3xHYXO5km8sXQkL9lkhcFh+8W3hqsDcrBFmhAf+AIJ9y17H8hU6U797rFBo9M6y8aeSQiv8xaGPc2jkQY9NPi5MDvB11vziTtGcgvq1QY4FizkfFV1BvTusS4PpK7+s5yy70/OSqcf1sSTO731c3SkU7JOzZIQhxX2p/10rf5PbK9Ea+TrX+lX3oTzPq5pEja1zGvaBQ4jmxcyEpXPQsa0T5KhXB7cr1Aif83K8TLDv5KSlecrRbCn8Tb/1VzSVyyKC9cEBdmhfiYg0yj+NvWE68h4OumXkLWqwDk37yLw3/7UoffMjlZe4xOAdC2VvNChcRp/9xGFcECoE/5P5uOB+dWLoYxsISBr6PeqZZWz5AXSDEvkR3EjFqea4w2abbUgCa9IbrWfl/7aGhycLn6y+y1k925GT0ud/9G0bknTnbPpheuJD7kyqlfS+syCG4okNdYoKSIDS3mCm5jTsrRBczGaU8SKgU6Cpy00l/IKLWpLc1Bl/saVn/6tFM0exeeHZOAXgzaF62Nh1yJFfAOk/FU804kz3Dq4MzzB40dVIdPIsxs94+YH54rj7cmmbjGPXoafvUJGmQH+/tCO3ZVG1J0foo3QLzGRg2gV8Qb06bvOw0KDTI3xxN5XLmbrWTk+CsP9dZNzUhLgGFbqgQN5Z0sJyLmeb+a11Mov+9sa/+nbWuDIdg2LLOUm4QoUUVH8zJNnQGhV2GS8arWEWXF1eZgh4BdTzusYZPlDOd1n6IvlTnLNdOttbsxGb71To6hUH6S0mUb/PICv8uKzQwcLz9grp09PleA+sJ+gqUQh8K4d08mW4VI8XCD8b+qp/prtjrpYdCTk1PLMTbZsu2kePeOkFr1QcXeTcvmUFLLEjFvPhRvrJWh2uBrqlmaFQdwwXAVFuxqkUSHaNU9zWRO60Lrkb0PxmceORs619B4bhEwtf0MpuJNIXkdVry44BSqWZYYQX+lCttw0pIxP9d4CVP2kVEjZ9lrrrtZE9ex+/7oP57jah0ZHoAWCaz2y5w2phoCLyucDB0ysofgTwItXmAGFFB7d5rT4RClOZxmQDih7SXljQbRVLfhPCFfRnzH/qjN5xP3NqZvdPedh3X3JxFuQPiYFagGy/3ijcFFgCPRumkLrLf9+L4UPDXo6GYlyGpW2U3k0TIG+NL0w1GlwzRD2kizEglEyCwlNfFuIkK7Qer1YMI33Bo0t8nM7lM+fHcICAMeMR7Ob3qnScQyojzHVwXloZ7L3du0d/YdeghVtJfI5eBKVJevLqfskEa+lDXGPTbmPz6llktXVAxZ7wrtZ+KNB98o1Qv61XpciszHES3BITI4hg9hygUiZFVuH46WytQRZqb0DEy9mpmJo4hUB/l24icJeuSxxbM5efHiehk0rMPt/CHRdNpXozLjWDgAyqkeDdgihg9HTUkBISPHGfbpFCfruvm4GLND1ZHcrcKebOEP98f0DcXUvF4rriWhY6Z9vohKrshhTHT+miORZX/rA0vEjXP0Fdbr1TwBduv3IbKk7wVVdDO3ajzNDkDdWytZKADVL12w8zWwUgYmYdj/fvh7iijdN5mzkAivyL+f2qWoofseMdcaZxFzWD1Djn4wFQJ0o0iFUyqznQcqFb6xxtBwXf0qvN4n8WoRnQg+TuqvnBo/syFOBSXJ9g101Pl3+79tOKyJPA2Vf8dsBWYtyx0puSy3KC7zSkSgcqS7rYAkASGCo0Ro9hWBfp61+6Fyu6aY4aRbzFIKJnAyYMv+loTbBhdUSEh7fHpkdOyFwKmpTWIMfjs6atHyHKWQheMi+xH0OPOt3YXDe8tn+81a2BWiO0fJKlhskQGVz0KOv2sEA5UUaszY/5LnFxU5/rSW972qWmBvh3WjRe1Pmd+aoev3dZKonfNzx+si4VITsmPBl0eud63LLo0AxJb9n09bVrUuLEAQnnNsLFud9q+R3BJEYq0NBqckw3n9x/N/JpR5dKxfMtql9+MGr9b9FHedTgXcDp80FX+zje8ctIFIz6nDCrhTHjcWJFduoW/nGL95N0AetaIV8bmmFhFGk6KLk7nNf9wsJq3SR30MK+YZAkaCPf0bsDsT75vIpNDq/wIi/3jcVjdmIAKVIalpxP5D+Hg4xZ78rCdxhE7hxsm+VYhJ8TRKHBcHKw8wpiFUNmVkClGRJTNNDnPqVxQs5Cv3uMwQaQVJej+6Oyl2JI5KTO/DYbnOq/BigJxWCjaozhb7H82jb31RNNcBvKpe57UYo/JL5SOCpbbWY/ZW4TriCfxQviD+IYSOUrfQm9oHQnmyPr9XGzb6sKA4Rzk4ANyvSIIizxNIN0PR8UrkwUbk9SN934wXbKXcc6miJD2TvA+5r76vCmhgpu9jmeBNkIWj9wZUBCWbJ8FXGHKBTtNkQ3wxUHDT+Ko2FYJQb84oiqBtFkORlsWqrmqsbTJ2I6wn4AAPyv/GBM0d0+L1nzk8W0pfNUoX1gO0BfKbPcWZ74Xe2EZpCeQH3qoSX/xv8jt7r/bp/22+MPsI9FePzFMllcH5ON/R+eIOV2ke1WMIm+SiGngJ9ZnhwXNLTp9mQzfq0/lcIBAvYqX4Ob8X+6subUtvVjnRL7mzWiEdvbi8LS07uicIkdvrLfG5iKSJvltu0hqilAg/UerOJmLzIZ6aO5WJYXNJ2bWRyGm0rW/It5LqIDp5z8n3FHHKs9Su05pu3Ek2ZgdyTdQuppXefr25Vac1tYGLJ4bIjT0TiYyY6nFCj4Tk4ILZtwzs8OB5g5axMH7nUUNWR8HwznDTbQfI4N1kEUGjN1V/L0J3QNuigpy+JUcA/CRWAz+odLIU4/jJ8hB5/ReerqLljqE3WgDcOkeqIaOGrMmUNxuFNTYhfggJbJKOjNdxq1S6swxFkVyhz/P0wuEmfiqW4Uzg6cG6bO+u7idKRiPhPAV8B2ewPn8Nh0KSgL5pgoseP4bzWWoAHCL+z7tDjam2jsT8VBcysFz7kKR2NbgEF/tCNXyBXWmJ0fIswFkEBl7rFvswDDbzBQqCy6U4qWQvX8O0SVmXrsf3RWd9mEpvbaEbezuz1b/84FK/edyqkTIhj2JIi0aYXbV6LiXu0yZSy34pU89tnr+ADfIMcFGRr1897oTfu4RG9JMGGOQ3Ujgr8P65BLyCxlyCBOxOTxecbpeGk5HcEWs1wTl9vAk3myXk5h0cCEjBWOQjc4gRYsToDmLdohfDriZwkLEO4danz3VbvwBeytQVFDkYZ5gOnLyY9PdUIqmApTokYF++YEIMkFDgcS6/7X+gPZd4lVmXvdClODGq4T8p6N58Lt6YKwgK3d3HNpiTKRS8dCVgU0gvforolTZX3o2VkYxPsFkSL8+RiktbQbgySoJj1hJwVCr2nODIVx1phm4/HndON4z7O8spN1jr81jpzZmoXn2URJkHcl8yCOEfzdlrQ+lRTv9HY2/oa9oUQaphUzm/hv0bCLJTVmgbfVgEDLIjkih7yOGvUuKU4IfdrsPwlkAriJYJL0yZ73vRDepkHbkc175jGhgwbO6q/tXXwnTVTFTJbp88iV+HwecNjvZmR5pc4Xor7SpFyCscGqp3Lnzw5aRz4NNNmNX8dE2m6dQkBePDKCVYh+R6YgmBwd+bdatdhkazD6TVpHx56xiqPO3VwRVKsFEBa/JfXqA5wWHumdtRGqtL919xns5jQfXqn4dCGtFWPMIo9d+AwK2SKFIASCslg9DxJAtW256sPsMf4O7xgkQRWN31pByVaA2iU6kE+hZad0qPq6SXZ9sKOTTJHd2xOFylNvqFbKIzVuGcjyqN5Gk03I1xW7JAHdrBCxT7LEsvimkkE3VAbO0kX87uZpEvYg0T6HaarC1fjZeJUM1H0wx2z3qD3S3K9I04MS2G8j4s5wKMDyEoL0SuJSGLLBGFekn0YajWwxYlQBtprvpxFZTq6CY3lFDJktHua3HeLSSb2Z2uCLFtOzoh863VOmV+Q2M866cJKeGXkh5b1tIfXD3VM4QM8eMSxSLw1fSpmWimHb+3smGygWc1dCehTPSBGKgzwrB72WDzPkkTnat6UcNHjXHJLsdxl3ayximsXFxvOfINVlG90xEREB4L+boj9Pq6xbbF6g590MEOa3gfDlCjp/oqMNcmUTWjO0vwcNp1qbB99Bjc18PJTW9BfmAHPO/SroF3pBaBsR8/7gTDoA0Zbw7ksuFb6rftJbJjIM7IwURPV3f+ri8Y70mkNbpJrFwcdq6Imtpk7x4pHcqtvLwLhHOjqbDL7OcZN7bzGCnBzKJ+gza0kGuKz+/F2nQqRcUYOo+TWdJoEwfOV/sb6fwNI7FpVmdN8Icn0A7tKfp+YO7H/7tf9lIhwMO5JEJJxIG/JsegUguzail2ovhXIRdWQUJZjbnE14J1KKnUmiH8Z6euFqrYhYZcJO9hlc2GXWaPmNS5CPJs9/8a5PXsvV1TX77hOYgW5uN9DGb4cvJGrb34glr9lia7d+kn/2eRrMVIPoUNAOEjohoQGQRWnLvAAul0/UJAKchK/xi6gQhuKz7JyaufKNDJsNNMxoHqtvadC9nX3xEahXG0Hl95YW/Sg3OZJAebsA/M2K5LXCiVHoXvdosqGQ/ptM0LWwCzn+SGmHXMc2DsSEWUGwyZDG9LFYD5ZkYe59r6caAEXxsK7KRjhGOolVhk5paFP8nQI3SJsHF4B/rH/xc8t1Lkp7wjJVOUo44exdgcY5Bh6k3OXnzMJc/I9Fx7u1cVHX5y+LmYKehIe4zSnL9FrUdoRBZrtEWjARfkopZsCkaBxnUiMUBiR7FwsNqyJHfP9z12VNj06kyI9hpFq+BhAWYZlHkvZMbVL95J+LdHlLgL4z6xx0khGdCpgCBEX/su2GLBzZCNLSxcMzvy4De/Uez1e5aehqFipMkZIGN4ZZbYTukA/cWJqB1Mc2ox1viEBv9pSjIr+sCMvQp/zX/cvPt29VIm2pJB0+krY6f31Papjg9XF+wUWZ0zp5Nyak+7Nz6f4h5H4Wp4aql13pHB447QQvFaUuae0ITz5bPEVLf1+o+V75Ve6FKvY9OnUu/zs+6DAawqjtO74PhHyx4q6/q56RwbIMGuTzJE/8B1Jou4ukdPXpRQSYxSrfEIOXqA257S26WWvejVPTNrDhsHX9Lp5vBgA5PojegPs/YAIO9lpfOpWc7Ouc0E+6JSP+g1GXDnSUT4ImV0vhQ3RKasLeVpb2uWR3go+V5y+8Hdl+iGp69MsI/WL4rZDLQ9QdWftTr/hdB0YyHwJ/NQAhuMlA6F4cpQfIaHk5pHXzSHQKmEuGpb63ga2tvdHDeLBH5WRPhrZhTemmk5zFDjiVuzBJMrTt/t9ehtu3Gu//o2fpT/Qi8ybM9FOyhWDVDbtWJ/OGaiJ2+o3YGiFlDlly9RXV/18XbhIVCt0WPrTel5evJirV2uLI7N5fx8jn97oRWuSysBwuPAdY/mnrePu6M1ViDQqxhhh547s5RZdx+2NdzvzVd9UrA+cYG6yXwtUdlJdTR1agF+BdzWag6N6jpj+65G34O2gMs4FukEJIe6THPOIZejjkQdqF/QFhJJjGFsEzW+Er0F4YmWgvUB7AHQWJKiInI5PaiEGfqWL8ObapqHBcrUrr9iQTV4Zz3gj1cLvnpLbefSknd+Y5vRu5Sk389yxUb7zZU1ZYVVmVzAW+XOL2D7XdmztXvnd2yBQDDIPRSy1il6ukp4uxRsH7K1AhUd7g+D+dg/3x5rkLGomiKxss9iag4Cboh7/si5ZjVdwcqYe357Kq4iwipEMSp4z7tnt4BqlApASGgLW2j1EBiqdn7Cvr60KSDqXAqLsGEF6poKGXQL4uAXeJxkn5THM4ojoPfY7U8bekzCkdsYhbtwfoPzibrVIb6y4aa+Qk5E4BqhtX9+ySMQliupLrDnnzu1CJtbJi5dS0rl7Jo6pbZlaT4Z/scV7k6KuP1Q/OzaOByeMAuSfAFNarTNnM9ielPi3Lcb6r7vo15Vp7b4YDD5vGS9bE4ofRw3sb8jHQ94gDsL5QQL8sUZJoj4Bln73tq8bbd6OPI3axHAFaT79zn9GF142szojaxcKnQnrioyEsl6Mqk9W5MA2SsOVWE0gYBofm3aaoX5XLrRMRMxk+3OpgqE/17yzhYuNhx4iiJjSn+VKh2v3sOPBakFj1SdaHC9RQX3Wa2YXD5Znw3hSHCeOz811LztyOCblzSwZTQzSxmQftDupf5sAclBuO5oBn/8CCqDPAMscsgk/zs6xznH0rv59voaBJ8+4f15JDtubO5YhJtZnaUPIn3W3Gd/u2+0TryYTs4+ZbZqXalBJLa1tY89Lr6p6mKaw89BsQ619ln3PAlXMcERmBMibqx8xknCpv633DChAvuUZmtCoJWqOsGG9HEj+muV6a/V7RjbPE1kGl4LMDK7gR1djf6CHzlR267NEDs1X9omTqzO5ouiQka5ZMjXYSZHJa66+Z7mf5rgwa+cyWg7FLizi8o8jf+2J2tQykML8zZUah3liehF/A/YDtTyfN6wvr/08zDxeoafQ+p1vwDAEOqz/SUGo3EGiexCHyYEZiXXuWOKI8kOGbKTWeeRzLQA7do82EZ7VPz7AYeX5cw/3/4co8wsJSG79CRETvehcSy5dtPPu3yf+Kon5iAvnSR+Yacq063H90t9K+/4Wk9elZhgT0U710Gsh5DhXGLIiVh4w4kB71944QqRMwffpP6kXS9KxFzgYxGqpPEJ2KujYpb0WiVcjCgfgM3giowio01a1uTwDZFg4fsF8k3dOhGTpy7/9W5ZpZTcKF0lJidKzl1ZuhEIepMbYb/Kdtaf2D6BotxG6O1tnDjDlsohNPj0/XeFBA6LGcr+ZjLu+T3zTAya89wcHpn87fCGjImZARb6UdN4nQrnyyOkyEF7RCWoTnNgv55RzyMSiDXNe3F79tMiT34ZurgXdexm3gkmr9QtmP9p6WHY9zT8OFUQ/Os0Ngnvp2oXv+W/vNePb+BLscHAp6nsCdnVJ+A+/Rq+wdE7Cazq9nKA65kvb8i1w8AJyOa/dW/2DzuxIc6A8joxmjz1GWnXx+uoCM20UxgC/WFUJ1Y8l5mlizpaAaslMU2VpYaQ7XF6Aafn1Cels1dZrSD97QY6Qu9z9PRRLzqc86WBEB8v+ItR5o0zQyTjZRtm6PDXiAMcF8M5eW7G0Xk6VMIt1lyxuPLs/ix+o8IiYJiSGlTtYKIgkrEb97Tc2GvzqdBu0kk92+pQG3QGUwns+lpJlTmo6oKnTuY1ElMysRIuGqEdbEsBiat+TJpOiOSs099iIEW/1UcFwRJwkFCMcOMqCWNQF0nWKEu4J0zD1rVsVbPr5RAoCS7mlFpPLm4mFjxEJbaKmEk6wbZVWEVmFPhe5SWB/B2VgNjzzuO3Z51Cj1RsL5gfhn3wd8eZnFTC65L7NnZLzdD1JSgs6zX8jQzbNhsqAD/HGiaHP7W5A3Y6rSFOzitT2egWJ5C/pmmSHgnxdoK/o/2U8aa15pq66mcBPKzLzdMiIGnu3Nv/mLp3vd+OBJe8KYC/o1KZCH1lSCOl5YFebGS8MYqzgdEFW/xYyEdJo6yVzYUpv+JnCiSe/DrClVifFSjZzkMeil0c/VvJfegkgf8x0B2ivwNcszoWSK832v9+AneD3Hg3XuZGy2n7CUU+bkYmtzstypQmD/4zzu2hdkyD5mKC0SCq/zzf7HTf+XjyCLo2dMc3o3qvoW7iZO08R8OHCJEYrpCQaOemjF6gFqQWcavpNjl4EEWU614UAxeNPsr2T1ntWtWr3cQS63MowgpGNQnD74KWwJAtWnZgKoXwB7L89MKIbW6iIhwTlLIKs8MP5I++Bqq08S87r5gxwyF/OSv24evt27o0W2+gvRR3ObXknvtn/clZ24yOqT+e59H4UMhPaIVaNKvr317B/1HHMroIqR1BgB6k50e92owgjH2vAwqofaHKttvKIXpV7VcYZjnSOBnk3Vk/EyBU2oBpPOeFL6hlUBm6KL3skqx2bgHwGmNKKRAB/TnWxjX2ZK45FjUkh2lzj+WY8kGqFf9cPFX/ch3nMcB1p6OBvkCad1l5iNqWj730vCqpqsScCEW1HiafEGzhYOdXegbQ4eu7csb/EHHd/0S0No4VIpD0Sn9yLEaBe86GRw3+IgUUmlJaJsqFMkl9v2KrSqXzOiolpSQ8egNVO6vCZDIzS+uTtOlOTJlHwDnwEqgv7cyjnsyhO+mCIiGOsuoHl1/02EHYQf9Nj30rrsl+M2ICsmo+TwbXfHcqOEnGaXDY33Sdz12DaJbQj6iJt+/btscqXkabQAPkbz+HBScTKGqml+kiAWTwSRbqPdEHK0hs2xS662FEJRJRHl+UhwSK1QY7fjDE8ezLpcjXZgUueDtqUtPZTq/4gdWGTs7b+C65k7LoH0xi1HQWjPY6z8eYLRi47Era+E7F++C6m+cbwU3QRqZNQk4/QwOSAeoAghwtQF79WzjdCIQCmMksXqR/g+1qa4taNgFXr4NGjKO5aPDqXK87T3y8i/BhMTJQ2L8nbfVg7jYdoI/o67xQEIJM21NA97cR+JsyPW0qTICKUTnilkeRc/KbSO7HfQBsuH/1h/CLaEvJpd54fvrJR/+OTetC96NEkNgKuo/8QLS24BeNGtLj9wHEon7FffFEvr6vUZY8RxyVY6MtsjBTeAUZxXKCT3VzSVRCvXSCh/1b2Vu1kYFEWCmAfE0ScX+0qSujmwk97WRZVgToq5SN71WEAKj9J4IWqLi44rtV3iiWuH2BqxlcmsIdoa2hUwuf8h8zfxb5LypRKNZWvkVrJirzl+BEOMM6IUERrMeGL74TEAQ6nxFIlQh1jygTKq1xKlmTeSwMlya34wNfYDLGn66RiU7eznRScqY7en06K6/oDWtNVKy7bwCHz406/n0p5tktKKm70F/G3UWWYRveavWmBKsCWkeXF/BXL8VNZC3qiT1zOJoqeqHYvVgaLglxTeoZ9kc+Hlh63kKNIg4s72DSV8YUdLMHLFXApjfRSVLS649Z9HIxi5kWj2jFtEL2WBBBwmfb3EBnhiVUJ1kre4yYWcRSOXQxZtUcWXKKeyA4phYRvmgsqaobBeJTHUZW9WR/JFfe7cLc+EhQf/LDMGO8BdLl5rh2wOOkBY7njFkiEWdJARXGdkwZmUTIHb0FfkMma6/DmY6tqvd7Kilf82cTr0dWh64R047+m/ve6al19/LDVE1iBvYpT5hm38icCKfAUCaulY+Nb69YBKO/h0mnpSWnf4rPPZLTBOLdA3+M2utvthbTWouNgB2Lt8jB2561dd1YsnnBcC5ZUF8x/PYPSFbaAwxLcf/ZFPqJ1gI/fw+LVjeVkc950JMstrs7bwm8aRFm+5A4S2571laZ35Q1MIdZuE0A21vjw8EEP8PYFW6oyMNqOfA9wjyYFG4LG9kDyqb3l9Voybcl7FiLFnddXxddJBQVuALWKZ4e3qOnK3urDhVHgrVhuus4x5u8jwKx33t3oxTMu5sycaE8enyuHdbzMvmaFlxjWAA83oxkNjekZSXD9p2R4gY//A2rhhHyXkxhHzdqAyNDw8F2P8hMsNvaD9IS7a8z55YjQMRiHKRWHIlsrbN+CTWWeyKBqy59/1phBJ8QDyxVAnkHcaOrxtYLd2fgK3a/SKXr9km/Gjcyg5utSh84agX02foQJF4X3lUOVYRCSQF0gJq1cXkMBVYLxbWF0C3U+qwVab97enXetsQehk8XMDdvQ6l0YVFp9ZKsEILOEXnLZCEpMQIOvc0WnwT3B05ZtwckAezrGEno5PeSzE2/3AJh7WB37DcOF5B4quJwLATlPmC7YfAM7s61TvGd1sNmi/sxC2FsYSa3ijLFqPf75p/i7rPBz+LyZrIDIalaR6HRQDK1GOgAB9sQiBwNqIcjLEvD84nMMg+fwulGmlRb8ehjzNED73o2YYbnP6suzmiR1DKybTHKcb6F1yW5B5zfPIp+vO+fyARCC/wzfOjw0LhfaZL+aY3KMC4XaVUOSZDJTRvCkLtXVikO7n1Vb2GAXSh3Fb1ghOOzlo2hPFIrYLVe1AdxV1TtTH5LLXHDlqLm6/Q3u7bN8InvHxlelyIXbINr/qIB8FkA4eIrRowAl64IeXbaXweBW25AgBnJrpW8VHI+vkHaIh22sUqukEkklgvMpZ+F3THSmK3ojOctj9afiBguKmn9iHFwHltYrLapoLdxYFur1pEb26QCBvzCj4lgT8hJq4awaZXa6CtsvFV8i1199E+an0pr3eI8UA0sng3nI7HULmUVswD1L8rfbNf2yTw23pa+i/QhF+xY+pr/Dv2kbJPxBU1q2Y8MVYqbxyiVhiGQd6DWd6GzUvVjXR/y4g+A9r6YYyf2I1s+T2Z45kTDhZZL+DD34pUoGjTACj1e+7oGa9pzWgOJ8glSoSQTIkXiuXPiUyO4vk5zWSG3lloMpuIUWLNT2YBJL/QXUhxBwMWhYN2TB5AKy8easvADcHcGd1YSwTIRWhnVgmXZQCh8hMbtP7DezKuzYZo9bVVj3ZuKqWUMCE4ggpxKSZSBaJ0gFM4/Sn9rtBqN87FXCGRr4nUfHnQ2qYIUNsqqf/33oSV+isYy3yxCpOXumrS+ABv+B/LsMIWK4dHRVtCKdzrhB8LWWbmDwGUGWLeyBa3nx/SI5nApGrQxxPdShEhW7KdRX3Rn8s9vkgOrWYg2NCArbYZC3/hNhWZP0kRC+4GFWeAn96QqW3XzRyCOe19wPO5G2AXNBgMu0WUqcf2qb6VFn+gEgbU4wnlsC17CRzPmV07jE9zc9v7I5WP93I8OIS78q5wV87duj/8pq161b/zpTUherpSwxYzgEeq9IeYWcKSzB+P6nEq/+QvHvxntOTYSiKa1VwLaAyydaIljO/g+UcWqRemm/0S/wYzfnh8CNo1181AsUGKdqGNU/ebJybyruAXoL9JfyIT54AIATK2pdsZ8YoNOMJxI1onBPeMWoaswSveZfGgK8jspNwMtXS99LJTtC8/z8ce+6jU2NysrCwb6O/TQQbuUIVIphljYYqrx4HYNZsjSV7DyRQgGFdtxELQogcHZINlovsrXcM6ZYc3t6QHAFolV2PW6OpoqaLv5y7hoIRxQ92UqqkJk4ly+jJUZHf2+fLpiDRDP7u/2DgXz3l1a8Yq4xSeEoKRokxQO9pcPEZZN9qs4vIJlZ+ouV1vwLKPHVQA1sqjAoXHmZiCwxrQ/mbQasOtilaCW2ydFhcePLtbIYiCOAqSMqCtl0Lrxq0IyhU+pcX8oZAqzg1C/WisODY+Bx5VaKRHbLgCMntFK1tsyYUl32V1TTyBgD+YUtS1fYlpG6HcZ7gGL+ysL2aZjvIxFXcj3durzBGhQNSnsvRpht+SjvtJKjT7CcPgV0egDiHA3SZb1p6w/HqE/Hr0KHalCkieHQMPKkaTeBOMQxrl9EwtSCQd8iRR5sCpKuC2SNLxNQknyEGh6gfaC3Ykvwoc3Lwluz0VfhqwkJFpSq3V+yVcmbFKwOjO6KbTmimnJyMupxfwGPYePGEmrU2OjAgMBpmFGnXNFCxYZfcrEZi+qupambfJpcjVUBnrMp7uthZfdD3lLQmp5neXRkzq9H2tin/JB6jEvHo3qd0f7CDGTs3s7QKyCEagaE/T4PIdF4s56OV0fLCPaQxJOkXe2fBeWNjETfNe8bzh0YFV1WynkTFpqrn6f0IWcF+i7SrorT/DLBJhPDsbjwbCST2r4qyEU034iMD2wkd1RHhQDGAZvIiCKmtA9EfsGrQs6fXVfFkWOhhoDG1laf+2r4uwNYXS76OLYfU7sk3AT/utwow/iJE3k2WM8gSgzIUNwZ4tSgvvpYO+a2fHH9sMW6EOVJ0aKl9ncgdwQAXSZIcpWhLnvnQgYfhQiNBhuw62HBzGT5zkX+gKK4AuhvoDm7QCViMGnFyvKLN3nMRLOKoDQ/j81uqtdGH2Ag1P8iVCHqcb7xrO9uRzkcQUKoFT89pMyKh6KVQjU1dQdVChrU3DGZOxTpwcvYTeGYndARlZhBD9Vb1GDvyrgjlUnMAwZ8alrPqVoZQYD06YmYjYgTn76xbr3ABjYLRaLO3DO5PpOWaaGeR3kHDQJsuUs9g0oPpFyypAtGCeU2IKeGcmLMzIuo5SSc8GXQ5l8X1P3E5uiq2UyQhBsYqGeTsBhqhC/X+mYRmv0lHLZK2QEaF2n5Vnf8NCjQDmx3X84mIY7PchVBE2Nm27Hi3J5iNIOhvj/gYkwrcfXDwbhNNzRP3aY/EfXm3o7wbQcoEHZggz1GEFSRcrS2PHGEjYJsbm/NdNSrkmeSJ0pi/+DLXv9Kk6GXeoC1xqqDQ6Zubtvn7mOf6yiQ/H7lTf6vrLCrbU8Ur5iwhyckHJXtPcdhFdY/PAE4qc/bd6vBapFMj6KlxlDdyCBwGHKao9HwEp/HC4/qceGH/jUUTTJsiDwTj2REsI8RLoIQswi2517+TyPY3TSxzysj7NJnBoTgIFmK4rImUPDOBWnUG4mK7wOXprQ0oIyfSMYOXVkcina0Its8Ht8YP1QHG9IaclQ7t9iYiY/fuDicOWy3HC+0M5pF70sG9s9hIi2dIyIGH0NY49VCcf/VgV+Z8r0q2R/QaYoiMpaqvE1skgMXLvPfHy1eF+Obsw1JNthOv4d34n1bK2JwZTLqppsKY6RldtvC+4vwTy7Rkro+JOvJo2/UFd0/ER1CbT6G2qahIBmcQBzccgU7wriDVog71mwEX8hRz5JBCy4Y0SKsdMpLpydztu+uRsGlpvN/IcSLKq5MgFEtvDhCk5NzlBW8ws8kyyrKkZyuEysBZ+MYVBSaRqQ8SnzyzXvpcSymQ7++WPhvQSZqF4vALodygvlxYI6b4pfEAxKX2BaS6ycjicfSveuy6gnfQCMwiYOlf2YZcfjhHNbjnxtgzxfUiNQctEGKIoA3AIlOFowBDD3w5gnk01X/eoJWHVvUlRrB95gqGGzg8sQWgfoGmBWVpgqIJnCBs+/wSv/6k5qOI2x9Brp1UsiXtt7PluN9rUBPIF9mskATBK+Uihp1fJKLBv2ry8JOj5K9ovM12ovrF7WhAdb+0eP1upj056+GzyhH3dvpLg+2pb4iFe8mAoB0QC6eV4HYUxh4oaxOKhN1+I//9ekf7GyRrml5k1VKqNFvzq5pNBhY8dbC6JSBJXyhJw7cl3S94cMviEcboOy/NfNyN18Mq2IBCOenZYo4ICw37ntSgkDqNg8njlbeueREtS7n7ImbR/fl/YWbn5rUa85K5HKXTkQV7H8yJjJQW4ESDd7/9d97lSo2NquK1Krij1EfRanbbi7DjQtU+vD/p6O/A6OCgFgaJZJ0zurHlOlf8U3u03GRZNFmTZ+sf2hzyk5Q3m89VPjPaEv/yq4L01FoaoRYmXOPvDla+jm2hsmE7N/xgUCbCzHIIBirfUDHRWgIYT9edlHFdfs6gL17vN2SkXdkir4nxyyxHaDac5mEKj8NICGQ4x/IUMvCyqLzRPAPZygAYJnLTqwTh6EAA9BLTcgrnMGRIK64b+5IaPUEMT7NpssSojQ9YPss7A9jjT0qrw5GBCTjY6vZKQpuEdQ3z9O2AzwbW9G4g9uxb9THL6s8JQaTfjdQTb14g2AJEl8ZFSoJJY/cgdEeqnRSCQ1WWClDCVPZbm7vQbha5MSmZAAZ9VHBCxRJCguhgKAF38jqmsKXOw705vWgzOFcsfltGHVi3/T1EMEX3FUr/uaX5tkNcdGjAPJuI+cglhqu11Qu7U/iqIOyJE0eXvjnp9A1g1xRbsRKjwMBA6ofvY1Atih6blt7lIbTxmhE1wTNSHcCuvAnIOj5bH7ofswRA4+A8PuncBni2pLknW6/fhLoe0VH1nzH9lSSUJIzYHqUHCmAJWZ6BSYkdRVXnBC56B0uUrxp3zh95Ia9+b3XA7PMrGO1nONzk0DAwKxjo7MBmy7vODF9MV6q1nmDWyJ7GyRRcFHszadzmHsoEz7zjQaZpc7vV7Wc70vZn5f0pZGHyVjKV3AZgNJd04+F0ulgPp2hmxnUOiBvPj4P3CdZcn+pi/EKtzNC3sfSEqtsxhHSvL+WnMcGvv+ftjn2agcNUiCoAjJUNXy4agqqyKWfFRk+kO2ce68dJw8Kx1FRugPlFxfMcRDQcZ8sPfShJ9YuCh6BcSmNiFCASDuxc265YxhEVEKm5qCaEHCjE4osa7YPvWm9irdo5mkrkalpfRUjZTaR/Hbq7knD6/UReg5ZpFzfrJ8NX+74alArktzHFzwfo94OCXNuViWuo0GYNjnRV3FLVzKtwlKXnmQl+GRHBkNMwhhXcSg+JXrQAsghyBvDvpOH5Yopx4okawOvDsV3WzwzSUymUZaaTFt0U3yJq1NYRNn1P9uCtZdpOv5K1TbsFY9BwsmZv8i5UorT3xYDZFztN/fY8NzzpSiU1XsANjzspKaJXNkJIkK/ANGQolrSf+vo01PbRFsfJMx8h77eNCjLMomtIyNNURhqhnN0Lp968LusENwJlVsb0634Xnm7c1ZwkqzF9rvnWwOS9GN1kTy1o620hlyLRVoX7DtWgwx0w7t63ERQGnv8rfuAoIlJH18VFtM/iM3t8WnuoEmec9DRTK2UjJfDBXrlkgdu+sCtMuml+EAoZZTstiRjAlWVGWsgNzC9e2PuhvKx36GP7HMdgOZj7MFYip1b2vkQAUMHdFsGp1W2t1A4jg0LkOw+B8YrKvDWEkH15bn1TCZ9N76l2BKltDPQM69iXaeXo4PLv455dAFyouMw8F1kXDD3zR7FYf58VgMkGrKm90B3K/G+eHzPIHX9dm3iFDeHl2shLtjuJESGi8yB16/hPN9pwidzDsDXI40MfrQ9gQdQMBaH8dStx9+55gZnvr1Zla1laQy8t/LFb8HoPvkfss4Mfrjw2ujC9sYh6Ek/2KpMjF181U/E/LmDzKBYqT2HVw+XDgOUU91XlZ+lHonIpCtPcigb7YNMy9Ple9LbO5XhBJM/y2ZNX25BAiULwhLZO4SBPSSpvdlZuZRpsxgXR2ZuACuwD44FJxnWhcQ3lIm1/MpWXfedxoSExHSlQ+jCiP4eQgd2xfVbJKDj7YnHLbUI4BRzJcEYkfWqExJhKEo2/qIEao6uVDfpij5tbDKGeGW3pYHB6/8Hux7Yq5HnPiM7rbC8vrtvRhwMqEI7Yvxsm7A9NYO3WiaEEDEx3lwByN2Txxl/vtSHzseFqaXdshU82cop443a0R8hpIYbQYA1ds54lDQHaxwrmJbkdorJHHZiEcw8O52N4MznAfd/XiDCaXKMfnvpa41xkK5+CPjyN73InXmgSswhSII3Nm0nTlS3WKY8wwg0boQZW45AVMf6OdYAOWLqFIZKbJsrHFewSD90hILzRxHxaybXX46thLoBwuZJqLv3fWyT707Afbh6PpD2ZBHLUWM1Wo+BIAXoAU0HG+KIRmZt0sONiBQtaQium7+QhM9v/rFhkVYpHeVRDJLUTuXxPvLxKiKx2OViTavKrKXBTQL1TTYgw2vL4CFxZfwKmR1eASbvNLnnkrnL9Nk17viYiH7IVfx4MnGICPwvlxwNYp5V2okMjvNSVr488dneuzpDP3CBdCJy0R9u582gkQS8qWWOaBVCt2iyV9iJRKjDmkQrZGNYdp+JCbr0tOxH+mGaMa1KZS/69zpvGROwZe93PrMZr49Xk2C13C54rQUMw9D3wJPr2o2GK3N8/F7R+IfKdxmluEDc5fl7nrlSclG/Rv2LS6gPRwbaODfBCYCjO0YAXmkHehbuKpT/hylWgbenAYYBMv3oTy5RwJVGoq6tA30ycOxsxEv2HLtLeQduWVZ+DV1cD2TbjmU4vJpmkyaGLqVPGOk3oVa5Rc6mTFlOceZ6MRYb6pZcZSdHFXtvyN3/gTK9jknHJ9SlRlmFpqLz7B2QSORovEukp9biIIVF6TU7GKhRmY4ab3R7yHavAGgXvHn/S9eWZF0baUlTBwMe9xXDwL5qhFCoQMvVvDmsE2qtNsCGCNuZn1oRlUI35dC2epp71TKXb6GtHkcCmyYrDt+G6KKlmTA516Ld+wzjc/qxuFCDu5lkkMn2HytucuEBEutU/SUosYXZUYenDrbyYFKo+s9BJPias6xBKPmqlkmiednoIwY6lf9FaoOHp8j4qH8OiNFp0Y/5kGCoQ0/6CclRSzYJAGIC6pjk0lycJlyVlGl8gi2h8uyAhtLyKiLwKmPRkQa+Ovt+YhAXHbLYTD5QPNnMBpE5yq6OPe39ohHUkCKldian2VyMQyFiQvertsOF0vxyRhFtFma/0jOavX+lfZGjBwYhvd1w4hTVmugHCxSV+W8pKpSJ1lwsxHk0LAhlaj45IfFiuAQVsgUVxaE+5HUW4WP/FXJdveJc2pyOSRRKLMG+MKR56CdK0zzTR5o5iZlC28YUqYOy+KZ0uMLKPD9s/uee0tK89rdy2stQddB8JMErM9r8/8eoyGV+v4o8702dSQrIQ7TQOUSgqur0kzmWgg95eJimrR9av22sD0NMtzMtDKtkrFoUC7ShhGnrjWR3enbdOc1PdpuEN5S5G5mhrYo+mUvLgU5poTkdup/3VXEim5VLlEV+cWBrp2CRIPdbMu9FZDA+A+Gk6LvIYDvlbnnED45Kvm5vVMdt/VtbDNpr8IjpKczs3H8a10tXmd0QxFimZCTP/fFLqb5+lUkOZDxlwt3ZJdBA4dvUuh5WuS0qRKmLjpa/rxoZBpl+pzBjndV+xrc8+HS0t8V6dRrtCvRgdkQ8xiqqUY5jzQNAJjcELfwtlj/+wHlwiGZoCFTfNAe7qrUGCWBd040/pfYnTnnrZxHjUu7EVfCY9kPtEBYw4929GOdRg/PYzdd/3smnJovKXROqn3SY+EEgib+8QttLJPPmU/Sql/5unc1aW0dqVOJdEmyNgUu3LWYGCPzdXjrGbp+teo5s1EmkSo6PdKEeBeJnQXWt9yYkg/4O3sgr99lJ4paIc64B7ulgUB/sdWQ3OqVqCzJvsGy9TycJ4YOXyQYo3VIK66FcH65iZpHhu9F9CUb3sbFggzGaqPsh9n38dI2YdUfh55eMoWzWespCKXETTpluMDkvCyIKrDusyswLVTlRd84v4ynj48tO1m+t5c2f+KgRUhdvqtD+0n1X/U5BGwygJR2KVqy0TSANrr/yTaglk+Ep6PMI7fwA5QRmJPujoB7vOEqiQh5ViWUS4H9x0cKBjfSi8N2wf+FVtXIY+iqatNRo2WZFTBzjZkORzFHgbm4c7W2Vdkx5rFLWigbrpGwo4LNLeedALC1r905OEgaqvvsVWqEShcWIrD/I6tgka4ospdq67RJzhXEi4WL8Now8da2Qnz/J10uoyniVTBR1oZxxEEhoJyyt45Hos1EYxhM2Q4wRBDwDLxMC197Fr5cG7WV066G8vvwvYj7dfYo9e/NsMnFvcetS4YVIjv93jwNKG5NdrnudLo1b/3Nla0O5Q8DV3hEfSRMI12M4fXiOLqbCjAJzlx4632BUPCjsx54XZ/8JqI4/jcGtog6zQh0K1gta2tBhYWrjICiW3kkMdzgKArQ4HRQXhk9cUX5pS5etzUbYvBMSWrf9mXXsQ/Ktmr/fdJ8hnfvjo10g85JuSDBuwBFEvGMfuVUePDAUIK33iNagK3/IRlzOny3TAJYB3SWUV/G5AQvJ1zWylaMS4m8NRl8h5EKCm4nMTFxUg+qNDaxACptltYJw8BYtXC65PTU2GG/28UtuZepLGUZRz7UwqCh/jUtW52MEEKwOuii7Z7T9rBjq2ayK31oSbMysj466OwcC3qQJ2XmEPWr9EJKpQXkDIxv6Yitj8Uw8GdGLRpHDPuDbSeBniipGjgGvM4ZogcLPyZN1woFZ4tjeDx4vsd8PetcWrlKYBZHtC8FGsKGctFA1lhpuSUOVguRMvQPIgM1AEUZIXlgQWwjruHIDDP5mjEZeLLolc0hptA/sIgW2sOGu4HV4QD5v96T+yAhTuRNL1+8ZRwOo1ZdkCdSRGhEnd6llnd+YBG09Wwvqn9mRV+o3dutXKcKJtN8QR6xAmHcr62Bt19sNys6GcWt4/9TkI16IAaBfkVhCvA/f1Tbim2plvbLDwrlNsnWDRK1RnGy+wstcGVNQN3PvDzIGTZrkPssPPMabbyjUxSKRoJR2wGvuXC6OVEOjCWEjHe2GGjftWfyYtfdGs28Kc/DlTsEpC9rums2lkZls+5XbCxp12qVoqZ6lncpJgewgiAa96D3VeQ0rZXW6Z7mGcSgqovd19+jGvdfRya6mzuBHa6d0wKybdxR92DiFI1ixJXOF+/hPAZZKKR8JENxNkGizJ+bk9Wor6aDIo5kg+0PQ8oYygg6jD8Tt446eJXlHgwyqaP98imMUKOPh3XQa56mfqvS6wePqd/IkyCv/aj1DgwrtRSZcAmoGntUjJeoV7aPQeuNR8pO02G7aZhwa1Nb31tUMTG/MLBSrHuKJ9Fg3qodGuprmBXhcGx8UDHjKV0/d7UihC/gz3gCyyff2mRI4S9xf15xxfE2OuzYpdAqQ9/eRv3IqubAiZmCaLL0SS4NZ9dS6lzBkcc4vBY2AN0TG4ZLVmR3c57QPH9ib23xLC5ao597TbALrHG/R1cwdOYmpm+uir7/zWu8boadlWHP0uRL4owbRwPYVD0CQDjb70uWp2TsUCvgoIfyhqVgNfS+BccBwSGFsjx3ePCpjFiO69RfcNare5NtpLV2Y8pZuTDJKVyJIlx6uPIaXCwgDShHDbwp9oQEWQtiaG7NjWXVqSwaJfS6MgJTOBsCigwiUUCfUIRrnjETe9XKswfb0ltXSFMTdlb/12CSkjqveOVpjqdIPU8+jC2+L7ojlE2GMAs0ZlGcEchklaU2UnQcQWhM+1BsnCaA59b0653DVpMJQ+0aqKCLhUtzpXy6hLewwAyoNdmLlps9sY832glSdthDZIx2B+lF5RXHXF8Il73JntnPcmBI//LG4ZfJn5Blf/hOIMfTeY/zd/DxraJtds95fMXoLA+wlIijNPYrYEJ+XJgzpkLeOe5Z3NXl5ao9xMCoJoHcJrejxMu5InaAzMOyLB6wY/PTcE8baW1amlgYO609uFQDPxOb4A+4FLAa5GtjM9NbDqvu4uxojwzBPMX0c1d16woJ5HLoi1eL2jB/FQ0WpnZMbuzuZc+gurDD/e5hVhqYpFVVELSzKSPvQ2aTU2E6dg/75LN5BFt1rtuKCAM4EKfnuzm/l24oPGAWI3vnsi8x3YdnUiZe46zy78MN72E2f68PbfbJIA1kQg8qaf15B4LlIDTUpjLFSKUXin2mkyvRGTIiM7NBcoqzfzPHJO/XAiRDxQMs31h6rOn115253J5vZ4h7al6DvXfvSbhoJG2bZRuH7MjTyTU3Gk7pNrPiKWowgMMCHym0SCrSumIwzm7TAYqJJEiL5m/QJHRly5YQcCLlJiRcUwUF/JFxf/s3ApZpuiUlGzofGxRbwXZPfiyYkJhyNVKjtF8hRNo554o428mgFu8oi/FTsj5zZaJurU5unVIqMpoqI77EkW7ZXxjUpN1CUgQ/e6PKEadpgoCfJDMpqM2jSilrkBZ2+2MTBLz9Gck7D8iEQ794SAMHRxGOAXLwpmrqitti0zz/YKWFXvsABkxXB1qjGx1xFYov1cGYMpsqz1CCXBBWL/Htrs4tv2wVVdokxOJI32ou8E940gsvtFX/wlJHEnNREaoZ2PLghyFpeBnV8Wwsx5I9GamN7y2s7dtPsQoTif2qW9sEHX3Lpsjadixmc8yC20hP+Fop4j8gCbHU7TqxKAlXVlwEE8JP7CE0qtRsmlXAC+TTrR6cpOv9VlSA7lsIWoSO9vs4tHvtys/rhCvTyLUYZgJWdTb4yE6P9c4K6ViGOMIaD86qShF+RjILKIFYVccXy+d0oMyo+0vtiPJpazoUxBqN1YnOlqo7bwkY3l9OI0DsJBsdWwYQouDuq7EBlTGJC8F1clMIxpuJts6GgezLIHascBayL0m1qMkz2c294d8TbcBHkLWEf+Bc6xTZknECKf5K7B0rheA/Ak7cRbKO3rZUIbloPa3Eo9+ixCXiM7Rh7NaCmvYVE8Ft9bljkcinvFhGusBWyYFkcP5YJL0ToNfeYAT+Muui7o7ZkQS17aB68V1L3/k5QDiALPAQBp6SopPHraXvezTphXC9jhAPYf7bjyKUKFmjlQzcbeEbFteguPMvm4FUXGumGDkEnrJTtl71rguuu1mYYVurbCru+f2E4UmxKlPCzSMUFN1FRMu+qlZs3m8YnnuALtdZ6DRhzC5oae2Qafa1gfX68STGYoZsXceWRCxzB6LBqC9N0KsHm2aekqvEkgKzgPDP2dBnKE5eCLBqwqNf0kf66eo+zNwM29UDWyjatXRCA8dzJP7YzCrfibsq4jGjqywZAwvtx5mfFQRxtCcgFxM3Mov/RtW1xgfhQktCig88R/XR0FsyVpcpeB9Zr69YT+qQupWy4oB3dMx3mewl3livhNmRvDMpg9mf1HnvjdoDBqR+XxSusOMA0LosMhkz5lWCGOb5LWLu08ow3HWjYbB9v5dPk5AqOWGQyZcM2ty26ygzOQlz+Ic98LpC9DXMMXxV6hwNwaaCPUvL0e5yiyQ46Z9N2xpXSjeC15vnQ6B4LaPXNhsB2AjsQng95+fUxuNuour7vbzOsb2lhbFW9QqAnFFR3iwTeLTlG+mgBAg86cIEbnrfXAN2KAMN+blNl5K3Zf7PrKmOGO627oa1MoArDH5fiS5qaH2sqlAG2WUrW6KOKrec2+ld4+e5FT0Qqr3+CibgLB19swFm5sCwEsFDXws0+yrDQoitnPOpT317Xh//qUZouO75IXM/UBaKK+8K38fdJ4can4pYBKWwRyBi1biyNkUIdUeAF411Zwz89gWIvB68VFPz/bPb9def1wArac/+SHmTrSm0rlkpZq56GyBfVVKNZaMsU5WpnqDLl8T0IaYN9wgnEqKZH7KYbKP0wupA5p/L6x0mbsepoxHQ7a21jPtojTXfC/rXmZdRWZDD9lNHitC8l5BISWGEzmX+nYCwjQ1pNS9UDAoe1r1VJSuCDZ2t3r3xxZUcaDRPmx8y6q+CBC5yitAmuypFQdNq1B7jgXLM/LfAHFqmwFRvOYRZqFq4a+ODAMqX5Ln6WHjje8vhSDC4xDr9XVrQnEpEGcYNQocxio4MQsjXSZDaR0fHl1AAPuJmw3RRPvSfAtgUdPJ/Nl5NNC3Uj0afAb5YOw832lNpvmTr5M9gSIH9FPOyOHNMEXCmUpUzCSplfNjRE7HLWgeVWd32f57eNL7V9vTeY8cCDl9O7+MhagHfPNmpfdNYJ5gFpw7Zcq5pYNFd2ftOVsh93NuVLwGkON8kxZC+DjvPZbmWHJxFoymQiTJsQyPkPvd3DiBMCUdpevaylj6Gz2123ZPHjispEJp9+t0jpLhXHOv5Aur8fJnvrmouaqj+ixTGb1d+ynrxlYlflOI4ehvczK8xMiJ3vA3OPp4xrYba9eIoGIryi1QbKNSaADBKW1ku3g/23rTEMpVchzailbqeNjBqYvJQRlwM81X4jTI2Hq6JbqOiNZ9xoL9VYNbA2RbKVwZcCz3kdqEpZsHq+UgdKAKdAkEjYZHIyrbymytfZkIJoZwl0uvt6VE6pxfCssaJBWmDFigdnWt2bm7TdHBgpXvmP8w3qHBoMbmnLJup7wL8ysGOQcZKuaL9RbkT/eLcGWwu83NmH8MlQS/TAvwSKLF6NcDL0BRmXMxrNnKaukg1voQGXsAq6+D8mEZAJyE1466CS93DdJq0E/nTn7ZERq7GDo9WGgcLIewosW/ScJOX2hVuH9yjpPY/r/bzNbFs+1cRawQx0w2s0PqXzz1UqsZMKUNN4ZPumutyipq6ow9KlmRKh/j0vatfBCYlU+Mf36MIlY0rojF42UffMdYq+iTrSH8ITsGc2Zf6G9CQalxNqOUDPpUb/5K51dxMEUAX7B2s8zVM2R+UmHyyGMLuho+NsFO8wcyelvcgqdnYraGAnAhno8mqHjyyqGdojgT+JQ2NwYx7q2K1xG4BwuLIc5j7+92C9z3fwf17GLTpTZ4N/UZfE2kPqoioThZOMEiR9pSAPhcuVnqCWqo5jKI2QQ0eoKNmyxIQdInkt478yh0gIK6Rdhxqb0Alj6bt+WNDiFFFRYw/Z4qeKxykddWaHfV+4OR1dAdHDkNU7GZRxsBHRBzVbGK4UNxp6XB4BI0qWZGsMokLBIJ8IOsZX+g7zFu0TAlfnteKlHqRf59VZqAueXiy/IR+ly1F9Otgy9VHZQBdUHnXcypFKRkzPI3MdIvG5ksFsaROr79Zl/he87xj5tssLalli3vqPkQfeWecporb9Z+wWMvWww/WVhLyl3Ae+cA1rHNwVVhTCo3XTYtUF5nq5jPuY3cyzDyO5mE6Svs6GLAqwmJQjkaE399tmMwYIljxaTEKy3Oz+iDqtCnRy+7fSkQheS/TjqvIpsDjVKsHJK8REuqA5EdL+ke2ZDjg5uGLk80UVkU7x06vsL2ZGTdmYz++aKnnehpj5eRDIuNR6vU4SSkSDim1JPDNPp7dv6tq5RviPpYW7Ei0P6HY5D8sbmdhXPH031YYVxL0ZJKJhETPzJmXBq9t7n3sEmt2YTE1l2UzXo+4OSMnh5wkDT5nqMfUjN437dCw5oQ92RLCeR83D8SMh23YWo41LO39aSmRDCm200eHfInSq/lKfdug4ISyqSPOqsMYoxWBToKHcK24K5rGSGK7dpXbVGlme3K8sC+MdCPscsyzC8evwFAYxM9bLbc/ZkLeJrWgRCLflnSE614bB+WFsCEBoYIxf3siIeQT1laS0FYFZWS+npwvoCd9Vt6ct+KuulIRqAEmQM1+ckxS+xo3bE1SkgQVyqzMByk2PbLidQ39k5mi83fDu7fJaQPComKu+UmW7yX9aoz8PVeULd0OzQ0uI90pG15ux6R+GM0YL345AHGgjqsD4HSEsnzkJtZwuy13zI1HxPB3OTU1F3AY2t5Ale57PJAYmCwVnhrCA5M2jB/InsMNYX5yPH6eCdcL/SiQfw2IorJA1oLGU9ZRx7hexnI1M0fMJjRikNDxBVVbZtqnin5k1hM/5v/mq8gEuPkXbldak5L8h2bak0XY1T0wxxs6NdZr0JDBN3+32FlpTOtkBBb/LPSs6zQagBVvLZGB34mw8hQaXDA3CpvIT/yp4jdPbNq5jyRCbJ0Ek/hMix27tV7+PV6qQxfcMrV4pvO0DpjTfPUfVKdT0Pu3AtiuzdpjITBRQ0boMx5s2JVufG2ljPxK+EW4Pmm/KEpjjelovxBT0DuOwR9LIE8TpuybQ5Z/owcSkGIh4r70XX/lFHt9QOdQaSG3oKIxNkciumSX9jaxLhwUmiDo4mZxLVjukZ3Sh+uVlXMAOnn6hZADWmhKyjb2pSu0N4nklIrUDzSX+qvQLQa7V+yYB+OcImBZ2RTHp8FEGPzb0H2pb2x9l2p3XTAVJSJBNeblk8aP+/9d2GctvnP01E9D9UxW2490sdOsNOA5movA5rpZIDAQkvP4XpDv5bGLxeX80Ta4SbJHVBZd3fFYWI4yR13rvvKUsYqYVbq21K2GkRmqJbCEYD2OguyXTMe1x97+r8SWcsWwv3ClRG3a9Tb67j4YNSWjiiqZeMXSgt5VdY7K9XDlksql0/QpcBMdTP88GPbZEAT8himfFUJugLDLToGLoqrmGKra0NxTzWY1w/tQyPoBi+6tbZrnKsX4S+MuOLoiL63qOgdKA85FLgOldJFoELILTVQe8Xuyqy6Jf0wowaT3z8mItiHj5RBHWl8pnmJBiXM9trunH9sqrWKM7zQPpiNqBL98oJngUIFnunbs1rhtu38mwCCkyWLH+bB6XKsnGCUorMGrQoV5CuzGRV9ZYtiZGee2+Mc825PfTKB+6hhy3RnX0CW1FxmTyWZO5dh6fXR5Kebtyv640AJ5FAOzCqfj9EcCiOLt0MLoucB2Jq5OFS3vV4+8IyfVsTx/FoQVCopzsRh86p40ygVhKP/zg4Bv92MQE6suoYr+AuqS6w9bNw8UOpQep0UfrzWFgvM1MJpTh/zZzRgX32E/A23cL7n51D9ALqPL7TuplZ2RC4zP3zBPC9Ik6rqc6xqszG80nRpPag11lJnajrMow0Y8dJiAyDV6oGLWQTMRQGvU5dFlR1AecyctOOHMgMCbAWVIMFUADvd1J9cDixtPHP2sHipUzg0ZA2KuYBobwklHUlT7rSKKMKYLe7Y1MEzJvP+QFOygHfrQXUl3deuxtE5PGAKKX67RGt3DYXaYK2jm1/3eVE/SdH83ymWD4rqirAS2KVMbPzkwHUDOTn8c6C/YK314KBuclkwIsw+ittmh8YyB3v8EDHwM0UIWtvRyJDc410h1gQDNcYTcVxgWo9bkZjtMLCIOMZ294HiDr3GeLYlELweiU0GNrr6pRwyKEgxYAEev8WHsrWmIDkjPdBluZJ9CimwMOL4lWKnIJRAWWRQiS5R7dMe4VYLc8Cugu4YkAJQZMRuhu6ksp0Pgn6+LInN6vEDrH2Vn85yAavq2J+yNUuXLO9Z44tMZsc+ahf+yrll5iYy9PkBi3PjEXH0eV80XNIwdMz/8kJ8aSnbpSOQgS5+Kf7qNGvhlgjUMiFbcIyDcBZ55DazCRDMBMnFVv34b2omdc/G0wDBnsW1eP92KvlSz42AQmPhtd2td0JABrmsVrceKFBCUZjWB1mOM3b9a3vsm+FirKk5eEaTbfBkzrQ+nyr9G4HORQpimK4U9xLHV/CkSTTicwAUY8GT4VD0zaVHjIqL8yt8zxeKn/5G1cmPKqs8GrRTelPilgELKTZIGcexZSTaQazN07tLZLXBrWogDKU3+B29tgsBys9dZD48DKe3dpIkV7jC96FPGxSEk0Zs7DYVVIfmEKMO/PZ9tMfgFTxBt2N7qD3a+27xmxRsLzq9y/plNpliIiak8dXRXyQadwfSON5MdnUuqDR5I+00er2zTFkzlAmHJ45AFYjkRbt622WGHvgJg2JEfCU9Bdz4EGR2UL9DM8qjnliDQmotDqJvvRhRyELtFzJ2SAHWtuPsjMwu9m6fCJaQCTrLDTAOPwhj8nVaVZwlL9Dwu4kWqjzB7/cIQ/whgrApO6GlwwRAv2hWPpYMShvycDaCd4jfNKcAXJuNhJfIbbp3VowD1ImvDImx4V1BLXUPkrpMPyjD2EI1+gIQGy4K1hO7WMPG2SUc2pGU6SBCT4Q56ZujNDHrxPXrgwijYrscEPt6cAUW/O9aDWvJ849v0I7+derEUjLlKFRn3Rz+r3s22H1ZtkQgClEj3LHP9uZBj4efB7F08aHacFZHuOcrEy7JvKrClCTCdZ5iOI4PdemQZZMfJmDsZr0lKwH1+fRFpXa+aN3mTrlfRvCyPKkz2o2GR8dasiRrlgmsHAyrdkiiJ6oHazyO8vTa4hOClwBCPZ0mt+WUpmYjIy5O1z9disN+Jp8scBnkvqXihhcsU4s+mzTKEw//9NUQ+KLyg6YWl1MlYDZvzAdfTyjNAC7gFdmFFzhfkehEkQ/WoAZBX9hzdkd98wLe31Nadr5/WVXlDhGuVqXrH97ikfoh09gMRKDy2e5n5TfRjymX24VkhEtnZp7r53kasIeASxvwezn5Nj7C5FfDrIR3Z01bTSuJGbvBPOdJZBtOV31nooXBRwEPSWtUSlcN/eOiIJ9yICbp17limdeoNCU2WGurmYH3lDMAWTVGW8xeD/zsq5Uo+eAGU1wfuSSoPdmcMmbQrR2uFi2ft1sEW7f8tXtfTB9qeC8TWXxc3CduJoItWf8QAMoIHL0+0FsA0xyZzZPqZo3an1YU/NlfBr5WBtZFtpv0V5jO50/dQui9AL0CziKDpS3mPyNFy5hcBAtrkuXVniYE5+WNibfz0Y3IGCXb6n1Y2OhN8a6nX1q7mT0V48bskbZHvtKpkkSCALavuhKmcZYUi/LtMfQmt4OxDrWHd6bCjg+07/SzRU2erIEAPs6pMq9mrK2iRkZ5bAfUemmL4vKNirUUkLQ8sxoFJ7XKEyFNjG5/AEruKmnnxMNWrN/khqnXtKlG43EbUjbLcNq1EOD85qAWqvFBLEfbc7jdgr7TLsnIN5LotgcBSZGWJOPWz8Nb/u6pWSjWr33PL3C44k5SqXV6jF29HQjXQe8czZ6qRHR9n0EyH1yXWHPmrCCH+AY4oOKAdZS4zNfNa/TvNubNN9RihcbyFcPhAqIX7JPiGqqY50F+5WOzutM+0HQC4aFLShYwCiM5cMcxuYZb2iB597937OIpJZbsHDlLl4zNL4JIeW/+Mp0jpzVBp3VcK6RH50bcdjnySPRTf1z4jioIu0YCglR9L4sSyfuY/a8oy/Gd+WcJmjE/GJrQ6z//tlLn3TZQ2r+R7MA50iHryU+uXFDFuxQKtoxQ0tUGLclCXMC1Nn8Pa/SSUUjXfLUWWJ3RzMzhQVVMMcWntaGjDTrU7bOrq8plNPd7Mv586OgtNO1zA5MQEDsdACS3px25z+hppUAXtKFiDYq3qoLn82atD4PzxB9eq9GGMr29jgS/gCewU5SyQnWqgQflGxixHxbd6YYOOScF6oIU0yMhpwpp5nbtSPClSlt4NEdCu092NW2JtGMUDzNT+9+zFDLvalDwzuCN56VXy5oGkVwhRbOHRIu5QzCd9RdoO6hYWAbGmTIvQD4v2UVvXnaoJ0QCno50Msd4ny7U1up0feDZtzedelbUzJziSRUWNpVz4OZQNA4+q9Ln3qklVgveblIUGfMvcEcKu1ey5L4wg5VbkXr1LrSESn+zYHezD/jv02nTioYf7lRlSV6+rscqCdykCWlzJt7d9BrNaqJgG3n/S7iHwujqXZXK1iVC3Zp6JnKvsHJdNtny/asxG0j1QomMe/n8zgobbbrkNTLgi90s9U1Mx1V+bER/7mFXcV7xOAzXy6DItQxyly+6zvJ3wuxEZvp7NPuD++cbg7NbaGt3SmorXJA7qXmcBYAX1sv+iMI7ZOhZz3Sj624zFZ06QCVK76lMKr+qvPRbIrvBeqQVWYkx1xdKSZTzb2yJVGVeKepvXOCxbhC6WpTCbCQEtxeIFtWnjO17ZDPhrQgUiGW1k6kZozrTZyvDXJEO3r6ncLlGNLipk86HifiYQT+beZuDuQTaj/tUTNFxEh7gjfmoIrfXOgOjIkFA4yoDJn4E4VttaA5uUg9eZMTa/faLptDjQ0XtXFoPSmk3l7oK9972tJOqPo1uZpQXBFVjcSoxU6uw3a9n5fKsDO3RZr76A3+dbHcpHxEop3fiWVeCOC5WRh3HUxUHP1OqzvxAmy2TmqSqrfe85mpe8cqIUBC0YC2b3eBN8Tlo9FIsofY6cldQQxN2P4Ud5jm5dyb2DtLHsuy09fRgeE1winkUqMqCkW0qDKgXZ7pIVdhs3hXhh1CjIhIHGDEDtt5wFjG1HP0Ew/LjU2dJRA8C9VtOcjsK/69tezOGzU+7miM8/Q59gJ4h9hy77lquYw0dkgheZ/0vI/OxnD7Q9D+hlpVaEQUQSAgTvKV3KOnUAR6Ae1i3Lm4C+KG/lgcRdn0mdSjTNGNpPnCpq2na/O9IsZ065NgSHajgposCgU2lHU1oLGsBXnC1lDf0nJMkW6grJM8KMABi5Gnb6iuQwz3BucSV4Ia0m+3+XxpwhIbFdznr901Tv2QfwWy0juBqowqEUXJ7YWhYKXGmjqHC2lIm5LXZSegsNlwIgOQ7hAtp4WUZkIlJjMyADuUcsf15hLkl2u2nohCLsP84yxVVaEL7CAq7iLDDOGEUFqn3Uflm+J/JyTKA3pmS9qgIMDY+1SDYX74/8Qp7IkNkl0wL8NDPIC/gi5xmg08hgRKE1Htp+M08AAJMinr6MTWjPP8V9FsoC8myPo8L9dDaKloJvS1gbU3T/B8F0et1H52F2ppiJ/GdTF60HeksH4cjpoNYf2yZqdODboH5kEDh/AOBzR9VqOHzya0dII/JZFKcF87iPUUi8jwPUiyScGCdVsRruVNyZPEERhwqVlCCnpSh5TIwG41Du4Ts+GtEro9Tdq6f04koqWVKzwPyhx8Tla/F+ECUcbJteQ2WLHuqwTvIDHQLM2H0BKohO08ShZtEUm7XaJiydP/K9szU2LKt+/kSOsdKX7JlcNAh75+mzaRpQJp/Ww6NDaGFGsg4g/y9ozTg+9NWTXQV9/aFY5TJ+ZJM/vs1rb0Zl6WN5JiQw/7UeAekgeaTB/8PuhzboVK/5OlyiWD/T/AMoFF+4pk7raCFtaJw2TzAnhoP4zptzswn2mYA3kg+q18uonpBo205WQJRqhE1gPc8VWHA/Z2ukZqscCTW+Vk8ULtfKFz8qpS+0LcfamN8/Lm5chrTvhd/wva67RBy/RPNI41lctQG0L2Akt/AUO+auR9UKs4JPJFZ5DVWV76nr87D5aYPYiAh8L58l3X2ygZwlaVZve8J9b8jMeso3S8wMDIlhn9lBnbwWewGTHfyPCOXzegWiJUilOQXzvgG3zehFgvfInPTkMA6XH2P66+/l0h5UsGgYIoAxKm1zCS03/b47MrkSROImXH2OAxc+IvsIn+Br3T6NvUKRjINsEVvfp7elF9cegGwosPUIo/Bjq5+SY1T9uVuOCyBdaFbYKGBMRRurwx86wrqrWaThKsu4GI2jz0xKKRbLv47ymAYcll4q/GdgwCE/fsHjQ5y5Y9ylqpZa/HOQ9Z2k5UEzXD1rqrd46e8bXsd4RafkQfmfw0VpRK3YvKFsCOUHzWs8bnJdxDgAlfEYJZgGCXw54704MfId3c2pi0lrJ9Xz8cVb9JwPmCxoOQS9/kfJFEoXMGOaz2c4hFY4JrY5iNVye3wILbMMjafvzlV798ezx0jmssbI7/LmNOOqF9m0VJz5dbN/B+XuPubbuVfCTcZgVimq3Gj3WvkDO/4RwCJ5SWAASrW/UqPCqv3aQbQ5eFBJV/XQCqWYNcqpXB3zSeSgt5SQkqRCpk/c81kMvP2KP/IJ2M3thYhWZoQ+CznZUWSdei5N3q6jc9sL2tZ1OzAgKFKnN5zmiGm6MUoj4izOOB3slhb5TLGlAUJGCDm3N2CpKPwOco/iu9lIsvWB04UplFKXIAHUuWjZ/2+PwqB7l3iO2qwm9Dzl2V4cIObHWHL2KuFePrNtcujSIEy+A+03ZCjbBe7Q93qi4BCDA4bBiC+9A3czTz29L63tGZ4B86BMAkgiL87IuA7l0bQPyCH7snBxJoTb6/RFq4lWTtY3iETv/YmJNWckVrRK+6Gfyla8mpylCW8gD8lwCvmANsBSBubXIw9BGQq0eOLzuYME+FbpIS8diQE5lzawMZid8qx3+LYwZ4l8UV5U12rRgExxG9kR8MA8fRTymmzzMzAoHfrXH3T6U4EL53P0L0+pNL+10NroiHHlNfEEHieTi7C4kEHXRdxQ6Y7XwWM50zH5E54JbEDOoinkKH+MdnfBi8Jen8PlkeEUNAIk+DKfUMsZIQAXq7x+i6som9GDIODIAzmo/eE9XIEMsrEshzlBAWfmsjugamwCCnJtE7Q7vH0izoR9KixLktaA47aic2Nu/Hd4jdd3PImivSUmz1SJP81TOOtJ4FNEdDHKJpsuogX35Mo/pg57XzBfFtCPxuMvnIqZlTZqUf15L5XrOce3iMgQMsWwFa1SzqKVcf3rNPBVgb5u46/JSwpQ/mlf68YJwmRajDoYIy+3wT6e+b0RobqisCRnAdYg/WFZmTjToSn497EoeXUawsXq3HZnqRNyMgJR8uPoICDXmjdI+Du7Sbk3H0l6mcSFx7iza9PzjN+W7xZmPT1mYV3h1s4JvQh8sLeHyVGAME4MATi3l6mo8t7P1WLfGpWOS9JXmC1YMnK5cnBYMHLSrDIG7jAaCUpkgCyG8+q0PQCUEFHpnYUyEHevmiMRUOS1mn7Z//+6UvZjMY2Uv96lURKGnsDw5IZKPAAM5tJcjzp4FPgQonNwv35CNRT/sAXef52sozM7nIRzeh9xaDq+NNxLPlGyE0zKvpxdy3pwV2DmXjruylGzNeA6XTToZyV4orYCSYNB5sywl3lkfrLuaxXeZefuUha+GiCUejtOEdP+qZNZRsKhxSUfeOtfpYhf/ZWCj6VJUGXYNiPEeuhchyeqXhsN83xYVdSGAfNkRSGUq6DdyILUdbRC2b4h94KnImXqGEF6XE7CmGHcSLrAKJp12KXiRwpK+cYCHdIt6z90ORUeqCNKxrVSG1ot4RUrP0mvT7N7CPiU4myZx7lEMnS8R9Q/zQGoDUVXe+R1ZPM2H0IBTIM3hnIy3jbwhkHxXSLmpj1FJL7/9tTm18UXsJ/KFe6i5ZrVeoNJOX/qxCjKNO1ab/e4sO4csgcHLv5MDm8Pk6o/5mkHiL3U/a7jCDE8ICIhJ9l4wsdCiKWXiFtQkNhI7W+682ep3JQ1zFy2ItW3cnhAprWbzjql1fxAxS+Qp80HeuUjnONgPmLIqclY2+RDUdn4NZSRGg6froVA3lRBlc8ROErZf1OHVYLz6R/kskmR7r/S5BE3vxTVl1tcEwy7ThMe5bKZenahuIjwG5udMEN0n9OZGLMulL1RUH3tHGuFuH7RnBdwvwe2gMiHW0MK146hFlDGg5gBOZ3yMbdhENhD5II0dBYUoZhoqiKABgb0AMjY8gIM3QFutNPd1DP82n48hGw7CmCUSDXo/O4CMQM3B8AeWGd2nD3jMQ5CVhZdqUWnVJCzeiFN+yOcbxYssZ5sNUCZiKq7v/X5ldJX7MfzmhcVjFSSjub+Am6ILH/P/g2GyHkPcSKZDxHSWggR7Kg4tk9or3XYE+AfUQmlv9RkSlj78ii52jtTBxfSfKhaZ+wiVieZmQX62H2iWFlXZiAL6sc/DsZsphPNiLwfS4Z6nUG2V1us3KOsV4flyPMElkrZyKm59EWuuGcmg3sGdoC9qvVkx8GsLcrknaVQF3Iosv23y3JCbP5jdlr78I9PZSEAn9Zyh+o6Vh11QjXCFw9Ux5tpoVeSh97kI6g08GqMgnOEmNWCnbNqd9qts350SqdS18BMMExqsYmrK4HcBftLKA0N36o8iAxyE7gFjNZUTQ3JbnB14wrrAaL+qZHRszgvV3YFDbWkTCvZNd0RK3c9Tk/zz3sjJQBI+q8+ecQd2jR9mQbT7ij3EycSy+ou/UnixQbzhJ2Hwz1aSy48rPfK/Yb+i/udxkbfuSdi7JinYQZWAOEL1RUhsNy0d9sUJ6Dz2XQU20I+NdzwCTt6GSB4aQiuwF+7yv+G3uZH+Il7i/IdxLj/PLmVOmKb7LtSY+qlKFXx6PvbDbR+6e7Qw7xDUW1EBrwgOgBGPyNVloYidCFENMZck8LY8ugc8PjDMbA026MgleaIgqeiIf+fHqY6IKofIsI7twhelzvkSVDoderDKfG006Ho4yyqCxbFf6rZeALTVPD46fZfXb2K8XWzDQrObNkcnKEEAhmImYSmlYxilCLqbaTya+zLkrvnWvaBtJiU6/pbqX0T4JN51ce+F1oQUzaXPGKD0oKta8QgG9wc5fto8G8wlStbstKayWaFCvEdP43xvyKHLZ9NGuiHfXJJedmJe+OI0HhqzMNWzQYmHEsLua/BtR435dHWCbNDvJNGmWDATuamu95OHje9cfFa48WCe1xULNjvNnLQSZP0b+jOtaXMMvi8+rOtQQOaZQDMpQM0Wy5kWv9C8GHlSC3tj0OWpDbNKYgLdU20xuOCOj48G+u1RrMBEAa/PPKi7NyrMhpPb6ixhkIuoXAbXqIs0+Z5kMg28KgBcRnygJe7tvSjAzUvCU8rbBxDd5weFr8lOY+ufWf/nZW7L15yOli2bTcl5QzHbnWVsPAGVheem5Qlr+nxcClUrGvgY4WL+TYARzeKJWEM5ClHQxMD4WYiscqRRQ9Qb81OS5d+QiQ3njBV1Km6Jr0ecxp3yiJJth8489khO+Yv4F3/UodNCeLwYIhCcufdQhLNnTSzoShCdnW5H7HZp2eQzeUv/Yb0Y2u9fHqBqHNHHnbapKwK9ebaIEFhDH4owV6bIyrkXmWOrsybMP4FngzJcGF09iYPsZ4O8SeBj2FxzPPuRPPprr4NrMVZwgeKisU9nfd5K2Dk9juSrZ2L/PYdCwqTSZIGGUxPgrtSXCRXbPwT6X7IIEy938ve3CdKrVyCnwm0phqm0eCeMip9LwtgMahj08v1OeRSkc9dGf24VOuG4KcD5+D6YKyhliTXDJdm+Yvqx8Kn7gSkRKht4irAvdDHoYdUGlb0n9CJ+v3Hoj0x+/LURByTe3OSS8dSqHdJVLMaeoRUv7ZiuIqVXXwHBFf2qx0s20YUVtjLRzwg5Yn4COh8xjImV+QqlEJDfu80zOuQA6E/J1nBf9q08SD/gTHSJpbJv4vrehqr8eH82nJXS4j8Zjsi6B0Y/VkCWbPQrpWuxYtGpdu//DLy4LNGPT9qB608vW+Rmv1AGXgCje6amezcUVfwCG/OK7JVOkIemh8IAyiMY2/M/mKIddtgV0HzYYG4MJCyM2O/XJrBrukRcvwDt2ljUiMk89J/Giz0wu0QWERP/GIgfMCNG5KizW3wVUH8M5NdfgLwWnK4EU+p8/E6FJL1yOoP4q2gR3DngE/Six9fQ9sweDcQhT3gErnooL0c8qgW6fq/yPjWfxr9R63Q4mUuZ4cI5IwW1zcIuOvytgExxUKcwv86BXto48IXh+VGBP+t9Mgez6EgsQdfGdyeB3LC3QMq+jHkWCuIQMWCkQjmH1M7tDdS+u9YN2RotuPY02V2R0dlTbdXXF4Q8gA4d8Xorekdhys+1wPD9NrIBiO1FyjkR1u25w4EpC42rPpmoKpDl1vk2cpybHg8t3jBB+kz0/k3/WiKpNqdthx9+nr0d+IuuTLhpygw6NASDFcNaKa62GqiZIpf46up+5FM/0dGSS811+CfsOeZGQqBk/IgTe4rPnSfnRFBDzLcXkn3w+rw/tSHhVZy54+NcRxTi4YkQJgfkg0xS+WBSezHoJsoDi78KgSe3Ki4467QLt7nG0C5rSkCL5oF8cDLLIU/IOsmD8xx8Z04KgD6xy2l8fGCoap6Tnq4Jx1P4Jhlg8pN2uzrLgWrejcy+AyECuPDQLxzaNlALNMfmn05HeOcw/deDyNr6o+7pozyTsCkJ1wLzHjPbaFDcDbAKL4zCb66mK76XlsGPfkDSByYNS2MBtCMBRr9THCgBOi2AxP1TdYKIp7jXupW7sME2aH9+Vc8h9t6oTU/usocWU52exoSMEn+neoTb/Paoo0LVgcUbPNMOVwCv9w+N4GTktzUnKjnn/qTnjDvk0eorNCh0cXaTiiUZKMD4PJXD1x4SNhcFs35YxiXnNMhsAVGvP+MVsotkqeBnfcFDDvoJFb3VzlNe/XSevUnzHuvVgw+W7iO8WZRagvxXfsokJ8GmhoJOxiytqtBSwB2dmNNOzTWOIXw77PKKo1D6YMct/J0xjBrGSiSzsjs3z9dAlPTCh5PL/MHhjmL623WGaKZqI2aFKuvFyl4C/ucYqktWbxDvZzwpjL7y4/SieiMDZgB+MhKpFk6QuJmfizKllcJGSPLXtEFk5iK9XZgeU4EvViCj29+3l6BnQziYFZ+3ZImdpBlVTin5L8cUaXTPaBhayu9CG7MIIEqjk7IS5pi4yU7e5MpDfSx/eO11+TzazfUoSzTLCdH9V0mLoh428zi3Aw0KAC/cIfAZHNJVQZLVV28Ywx2KN8WSzwpZh2DQEEHqxOp4d8wb5SnPT/IZtcz2Awpad041W3jnSvygkp/5XFug5AH3YoFKqRfrO2r4LMJNO5c5cSt2oicJ3VSqy337wtzXbQ6T3KNfJSkAoVD9dqH29bqKh2uVu/+A/aD6GqYzp58CJsshWdMWly2k80ho2N4obWsvfVuVS7NXya+pk3AwFFt3GKw8Q887UKufc2pfrO+kchTK7io7PEs/l+Yf13UEnpiueGAzj43wem34uOAE6I6/GIzAVN7AcbaaVMkPriqImxy+0Dz7R+/oScQOr0dscH3kV7gvL2t2OGI+vugdoHKfDtttrGNI8/wH69Gom++GL26afTdN+A1NzrwM8rRndxgWZo//ZHBZiFoeYtMTsz1yRRQ0rkEgBfd8Td5PZT8A1IGvxFve0DJDCee9L5R1O/BH4DS8DZT8EvHJkUCXr1myr33ICStHZ4nxI3L5J9x7y455choLCNWQPWiCmKH5/xoLe3rGI6tCjbY0DWdxeY4RivHYfQg6Tb+FB/ZMYVLn9jKxUtqPwR3zKxNwML+/K6F1LTUsaAFdYpTBDfCBXodeDe7N7KunKxPgDESsrWC0pXM629zzVDWzdbZtmWDL6TEsS58olJY+FcwyzX1EqhaNuJIPZNHftcYVPq1McIKuPmOMRJTx/cnIzTHyvhRU5VFXlnmnwjJOCu6bWTIdzOX+6GcOPkliRzJ7HRNR8hjd3HmM0OB+NfeOQX+cFZYQSOEf3j/JfMIwyRW6QerQUn0s+/NUU/EXmbW/lo7qXnmJUifnh5SJVOJaCp9NmOJ5f5mBPZXdL5KJq9zcb4k07WJdNkdgE6zTwcKNpaAMJo9tvkGcZ5BmtgyYXeruDNHrLyYuTqYpCIE3bUO3RvI396z5/QkxJBY8r6vKNpW8mat78iaRvum4ZuqK9mrVIge0v7c+8l54KGMLV9jaP6k+nG3+AEvEjicMsyOuXJyQmsGeaZP0/3shG7vZSF3C51a9prvP/r05iYaVID9S4loYiaDG5YY7zY8osjRnMYIrkIIzV8TeJsRjd40J2SVE7W7wNunU8sLgjgA26OJek20yP2K+iKEFkb3JVoq6ZJXUbVwpq0ArZNHbJVF/Dn0uJHKPNqwOt+X2p/CLA4XSDI4fYT+QOr9/j3/qUR/o7uN3mV0mD/1iuDZ8JCQR2Q2rfx9EM7OlaK52X5p9nKYnWKeRcbu3sXYpsWchFpu4Fsz9+k89E3pNS9sPiN9BZRWcXnpgK2OP2SXQ7nUjNeoAUBeIDuPXYhM3Rk72STJX3CyVFSGEeQZK50hRepdlsk7nuHyI/eYXd/8Af+4LS7/5LDfE6L/X/a0Uuwt+xIfuI6/W1t9NeYf0gDyC2LxILzcQffR7N5gJzOmidM2K4EDG+p0AbkHXmoYHY9XdtMuM6I0wFOQ5YpIt+U3MBX4GiGjA9x02uPGRNYIbB1p4o1b7ZmPNltWirVVnK+Dfsb2dS6AhqETjb2X660NaahHnDHQzYSWmBhGDFg8o+2rCVnc75zk6DlQee75Y6zZgBD52K1sWJ1KmKLHVGNHR4yIxJ+9Ww8beUFEXLmCeWeOYfOQnrYAtxCPtXCPo4cLa7QzQJvez7aaLPUErBiJSdxaDQnVUmtWGS8suMiuesZjTjPh4uZZdQvXjVqQ/JPvKvirCW5n8zNQay2ojDINSO72gU1Fa44/D23jU/OQmQ7beXVmiiPes81nUpphnNshKAAr1pk83HRpGtK0RXZee7Vyp+Bb1NtnHV097zluJwPVtAXHmTM6NIBU7/9lO6qseKwvg9Y4deD0w7h//l0YapIQmBmbBfwXB9m9x/x8z8MuzGmBeQqwU+nbqwCN9y+a0ysIPLydahKVCWVuzw2tPsNVRGPYTiNH4nA5ULHJlnF9zQyWz+r/m2ZHauGM9571Fq9AnwDvvyCUU1TWUlqjnqoVAR82AJ334OUPLhmabX4UMzMP9WVcb8UoOCIb/fSpTIiUyq5FGShm5A2SoSGJYJJ3F0JsW4MV/7uFGTwbqG1V0dPh0FVNWjb1d1wpvx8hJlLBhnKdEvc/Vms6J8HGKlDnneigvaLeLf3T5I5rX0UY6uh/X5ODOKX8CF+LGMTK8wheHoRXiDGM2XhYnFeni7kcntvou6CxJQPeH8EcrWjtc1vcmlzdFwo1qfASY+7JwVBCHCucPR8So7Sq40/p38pRnUigfRAuGwT15mOsaryQ7rgY4FKQ6iHhIkWnrGFIWT5nw9Ib6bm+hJ6l5bKnaKdFmaFaA9YwEOo2IRaKWw6w9Un70gBTeMtn2qjqaDrE9X4y/kEUbPF4f2F6XrKwJiiVxNIylcTyjHTEfKQpuqGZTpSTNANrVuTxH44HrjYFTOSjpVcb9t93lNjVF7RCyyeDAUiGQ0SKAmL/L8+Y21S1rYxdkd6i29tyz1SvwuXQg1T7xLkjcj8kzwhMtNhVbw/YublfTNy0BCY9PJNpPFZOSEtwa9znmgbAgMLx54K/Jd8yjGs1svAVqJMi/R12Syj9/s+6zHGzsQxI8qkpPCjfwePECZ6xKePHimM3JeJdeYwWHzH1/hurj4Nl4AZH6LdJyG0tNjwtcIwlO+z6IjS8g6+L7kTj6yxdDvmr/2ZvpYJnB1WTWAMANwuzRDDNbQdihMvW8QZ/mbkBa7fUZJYfhr57gzs9E2eEIKcigZIiy9m+wKTnuEDrO+0AQ6bKpPlEOl4/d86o2XsLHnGXplrHAtr8VJfCSxW8bgx8z+G95/bCmbuav2cCequcowUPeYO65ITjftZYXQO/kop6U9I4nX7/H4Uyzf2bbIw8bBNqf79HO2FDnv8ObRXh1XovwZylswwmIK989qHXJcyi/rCJZDp4KDZwnwHcU6NGeED6LPpei9EdgFcVRixJWaeW76K/Y7orb6iEHThncoHDL5DPQkAwKGpR4grbIAJExtCzCMJUq/4XG3hTSeeGEny81oRZ0kAMdrmRW6jJ2G7f05UuK6o08dAMAy3tqqORd1ffHB07CSa5PDV/VyLVSnjQ2Gqo2R6crfAXFWzrWp9rAB3uBMrTtWgQnoPdpeNon887BeYBGhliQ/5pqeCxjwf7mtz+z8PLUqjx23JX+C7tjAOEwe513RfYgkJ32CB0AoVJmtoUjBXXIWBhDX1f7FTV6qHgfW3I7nGVqhKkt8cqZvVhdG9sB9tXzNckeFQ9UJFleCKHoOZ5S9XTT+YkGqAN7AdlqAdsNYxkLKCsCQ/+AUhlqntMj2Ad7VS41ootYZJ9tZOIwy9PZRg+G9eeQJjrXT4hPn+JA1UHbZTlG2CzQbIV57qdp5GPVYhfnwdStnVGp1GF0QfRPf1qNRptkAKPXuRAoDXlomINMfsYUhj0XBWDUZQul0TLnzlXQY1DQaJOLKL9tnvpNmBHjwLBA0OgTDiT0m9Lqw2CyIv9jB8KnffuQY9nUGKg4+xZtUc7wUuDxOONqnVwQ6n/c4QSdrbJefExAn5aGcARE8sl/ctlAQ/0vBK9lX1VM27JOsR/TNeG9verQ4MRmgJ+hMhl3Lr7PBq36tqEjVGOlRA60rY/fK2w3vGL0x9DxcEYF0rx1xsMyo7jbdBzcb9ql/fQwrr4C5M+EN5Q/N1wuFQx70aHe8YC2Hyb0A+R4g/tkgpK5nsD7IE2CxCCH/WMPEwgoSVFLVwWLe6Hwlvy0AS/awW5jExFORyNgR6k+vdjeU34Ft7OgJYpmVrJKqCx+OAMFJmvsZ+i9549iw+xGHMeqJXT15t0KTrOdqZjSiXulgGJYQ46IaWejnvq0UiRQudAvv08ARuyTABn/PmWqSAEJI+sbkNxTqm7NYfzsWLCksKIiEWLUJ/uFXGmZmft5YvI3vsoz475BhSBjjY/0IXjMQO2jwahME3Zl6Z6nyiqV5HbQoXKxtSNqy+PKeTG1SDMau3/5NiM3FfEODc7O+uud57UBxPifzz3MPt9wLfvG6M5bqL3LxPxbSJjITKWivfJu3UetafBBeOwjf0vpEgJRUn+GSwvqwtbiO+uJFOs7W6qFeIH3qEZhd1hGRH6sANTQJYpft0Aeh/3DkLUh1PAt+uCoOoq0ZdsYS8qsjgmsBwTR9dWOqXvHtRhirZAPCR2gG8GxVJO41AkKPL7QxMZM5F+TcQzPn34iRtEY82R/eD/SgRd/Ob/ibiQvZeVa+gh9jdJZBsh69qVPK6z/nZf2NE1ZZ8zzSEg8iO399XjAtEwbo7B+6ohjqY7+NIUvgpshrnUHSfS34FQxQyUfkI9sry0frMmkuh+gauIIEjvmv0685woabwszFTuTn8mNhHJTlpppXU7vUt4qDcr7nT63wnrDslPUQjwoWws+IXr8odvTE7u2CjZhaPPQmM/Oqn1A1J9XlBPVg1NlMYIcX8+Vc5YydCyrvrTMGcMxUh+PLH1aDAzP50LvvZh2useC5FjTPCNJIAWhkWalEbAiBHheRqXUv9GGFVg8q+TeD2swoXusnc7NDWmihLB6zRCv1wqIf6RT4AcfF3Z99j7LxSQs/tN7bAeZVilJKryDAZFqe4hMrJJ35A+DcrQkxe+LGT1PTsgPBCxmlXVbWxaVIonSiyFgtBaT3qgCwVBLzY6b/ylDufhMufJw571aU3fpy9ucLpRWzbw7iBjDB38aRTbyjL58ovp3P8swNJPVANWvO2RVF1LJGKofP2o3taqM5i7jzhZIG0BWXtPxtRA24jzibjqbvXeAwoj4ZhNfJkTUnVaEs7E06HqLUehWNf45IbdxmfvELQds8G0lJDPiTcH5DHKWRZgd0I6vmKOUjKoo/pnbxOAvA8mWtVBez/caKzqwDUl5EHJIFV+VBp5dWIAAcLdKHCdnp09Zxjjd52Jc73DuB11lIPCUp6qL/+Ol/CmUQDGkYgol/5YxYFWF0Ai0VIyAj9kH73c9DsHqd/khvE68vs3ShBWf/cvbALaxmdUX7hrzCZcVXuBFaF2isVY5yiFcIvn15tyv5BX7YcHvYJEAxoli5NIjdK341bQfjm1IRd01yOaOUMkpufg2NusVS4RHyb6ZCho+BFdl/4FeL3NjI30ewPa7comm2vvde2k1QF4rzZs5Wm8pYPCJZc4zA4w2ohpB78jWjeUrs3eoNVVvP92e5aPYowLjIj20JbhZIa66ETcNbTc3WFEemEz/RZ0QFoU93b+XWwaJT2cekVzzcCzWhZNTxOzhLUL+qA5x4YbzuEO3lbCR+Cz1u0z7Quk+I8FvmcCtASCd/Svg4oErvDOLHdp+eu9pVRAK1Aj7yk51NzVq2Hx0mSR+279ZTXLM9am6oYpNhLq++t7/PF2Tto2f3qUnD9MrJvQBGdlRfzBDUXFkGGPw7usJSzV0s4fYmIIRjjII96jc/qWsKg9mPaEyoR11RHNSwfjsfIVQ6mdMYF7rJqnpbDv6peyDs51uBJi5ezmwQojCtkatngNpfXQ3QLAxr7QYngLIc2QPf3AzLeQ9mfCQ44/bwM1rB2CGqTDj+Aq7fS3b7/uslkvpLnqO2UQWeJXL0wB86Neu8JQJW3nkAvvcLxJBMM4fW7lnfb1R/mzFjYOetJxhvQstQp1Qda+5dmIu1U2wBkCJosxvA6SK9HGgEJfE4cGCbYfIvuJeZS6/Od5O4TRAbezw2L+waVb7c0zqYloRO07pQvP8VY4WUBuFmF6Jbzd0QJ7I/Dd6X9OTYUys1s/wu/cf5Y22oAJMwjES7a1ErnYiTttxaCBgI8HnU4/21/T+5BJxMYEtFWUYumHZ24Ul7LOt1ZEcqT9NwW8esVAMSz/HKui9Lhz85FBalSzAqaO+Ozqs+HO7yTClZsDGS3KhgMM7aSxOCS3qlXhN+VOuNrl7jFUgihCpWivRZ5UkE4SObXrM3oNwmF7wIZiwaiRenKLbFNnmIu4YGSE9zeYEMbEaxJSXp7Pg9evLz3oKsLyvcZZzn0pUd0gQ3kNAWRjSnAIMVX8w45Y1UGpqKB4Y07tHR/LZILLTPRdrxGyCTPsPV7p4u5EkDMbd6BHMUl6qjSo5B6lokiq/WLYVhwYfI5jBdXc0ayyEbRB+eiaxyky2cvoXqkN90J5q/nmaAxwCztbPr3Ihe5GXtiodiFS9cwaQxMXovKy0QNjwZnrb9SiEAGBzpbFPSBz7EeEhadLFNZ3w/RMgQvnGYVbhvQGkNVvrVV48ATu8brz5YfEsLCmnwek//LgEX3d9l3PMVHXwjgKe5PsmHEibcdVmFw6six7kSLWEXRvooqaNENaNc+E372PkiFH7+DPm9NK92dtz5ceIVlMHwCWp4/oPHEID/3PmAqjQOAtQChYuqBvZNozuirK184TCjq9OsuOQcqEoVLROiTRGvPhaxqJbCMKjMT3HgpeOvpIE2tuMyNUx6bIr3amxFSyvqdMlKzYhZV6ZNpavA7xSxzE3vNPkyYEquUyMHeGLhYosiCZ0Od7vcOKd5xh7ulsQTLdU45IwNLShdnyaVfnDKMTRESJ+QJBrBKsJPk4xSBjPGSLrRrkPh5DDCO7AbayMSmBQ8+fhSxlMArSkmpwplxbOqReR08+3brGLbOKCkrYNyEZp0KA0YdXLkHgCf50fa4KxmLc1HTeqOK6edZo2ib4ai42vf+Od3IYgwiviO8fYrFMm3LfD/i8zyaEJGRgsTs/0bCCHCxuxyEL1CIm+wOsid8eVKv3qQJi7wzRpF3SITRWIZoWrl7tv7Tk9TpzHPo+wRXnp2hxOC+4qvs0ASUDW10VEk7Ug8JV0WOTh0rODv7QPg2z7ERKWSuHWnH8sfYyPblX0kTZVjGsSwpcUgkuYgTtqcGBnBgKjY1R8yK6UALcwxgF/3Bx8JkGLsPMb5RS7E0Sv0lt59aD+qFES+uZXIE2BN9pPT9J5yi/81X2QEaNRJFboLFPm0NgNhhrLnFYywUscxGYTA6t+tzctmxS1So4CEW0IOMrGgtbWDNEBdHEIeVXM71G/+wdWS3euWLWDuCzz+9+i8B5ixf9dK+5aOiooNIMXLQFamkVdPgjV6p99kK88n01gZrCOEJn1aHQDXogzndeMqz8KkZ0DwrDSjMgQUWn2Ei4lYvQYA7LJ1zuAZ6vOc3EtYp5HOpxRI8vUX/BkwfiXX3ld42q3iyhdjqjYtP8vMCmRkXEtjYEO1k2JX1aaNWlREJ9Czu3oLvTjcLlEGYtZj2PHgxBXxftymqESuM9rRKBzpWwvqUTphsSAPKIz8N5IUK24aFUguQ4DnhYZ1cGRfw2ktyBeSVa5QlHGEWXwJ45qXgIVImkRZvEt4MlV1UsbStn6ZuzkFAGTQBQB+/SM0x5bxuOJpEfHdnTsuUAi/f9Av4TSfDecnVr/mDmOda0H3FCQB7zTrGLs4vwWF8kHMUSx8MX82u7kkS0BBx5LMyoGIcXblXr5XTI/iM2dj/IL7CnTk12pus24YyxH/3r/VtCh2qSU07dMll7y5fyi16C/7ViDAlHi7CD5mALUE8UksyfEdpP9SzzQqXhs5k/20IRqFDPBIQJHLDUOHFhYTnW0r8bG0HRyTroQi7ITqkkPIM/X40k4kQVC7RgE4P2a7zkAv2rg9QUcWCxLG1ZBlP+NkYDMG6q/27Ovt2YHEWB1EX8D6qJjxserRdYyBGLgv/Xp9mDRK3lHeKKg2ACoWrHRYL/6r8foL4y1vwBt/+hkf3c1LCgDxmiigqrzxh909S+F2xBq86X2wQqYoIw8GsMwgBNzE7sRyGoTY5fIO+0P9ylgoDUmYJKdZi77FCXijBfTpLs+4fXzVzpv85hHraQo0dsMhK+oo8kOlIAqIdInCl+SrpqYISTqv1XW1Wt/kj3cYIK1BAahrc2j4/bhRkvhDPoE6ztmVIkAVY10lrcYbt74qocpWl3gl1xo4mqET8n5Kadrk/xp3YIevuCnK/SSsxyHMbPbUCX3aNbZqOYvx14abxvdl0AvlVcLWR19CxyjHSUKpUtQf1rlSDP8cQvsAFx2+U2TXQs1rqU5e5CoX1u+q2FePaxPt9SpR0vhqyk+zyOE7/zN9wgbP4t4xC0QycheusDnCso8iKM2SFfVIjOcYIx+gWxiCk3zLev0R6JNqZBjTMKihI56VEN/3PMFNMxALvr9kw0KE27wL7QV41+jt3c3D78ZbXkKerpY5a1bggA0SZHbiJXs+YuWAm8urfwGVBw4xM5UE5Gqf/4njuBzt56B1xRIDLAcgf3/+SWlMuHDAABvqtwh73GrfO3GMp66nWqUOmlcnUVhAkIkT7M0w4JTgMshgxrLX1xaosdkIzy3Vpp3DxPi2MWXrUnvyruKjXiS86D/Y3fzzP1d1Qdogu/ZN6OFy+XpV80Tlxk5i0h9Zn45iGygP+SSfZWRtGCbAGd0nJEE4KNIBdeG+ewf0V8+XCMFeqt2wJl76V1Of2AtgxU83kn9QfFVt47oWGXpQe9JiwswM/thk98r1BM7l5P6/oJgbaNTDqVAlQGxN3SUTTh3XWv8QuO9Ne2QVnZnjvpAg0sDkCYDNlzEfRhL4l/bj4caiEDQB+sWs3/yvGUnLQjjmMjSfmMFA3xBLxCxNthSoHearOTeRh/RWB9irtkp/5GPzhJvOw0l0oOCN3is61QXoo03gtWVLp0LStx1RQBtlcwpb4yRCI/92MaXZquigyo+SzyGcUkKFKjIlLtmc54VdkXiwCXemND7Mm1DWsZHal9Pqysc5a9jvr7l8Nr0P4ljOw1n6ynd1wz/VxBE/Xh1wONEM1VNX0LeXrKJ+y+lByp2U3JlgTusho6scLwOIY5e/ksispzIlgJWtYqW9WhF3HzM3p0R+0cvytNVcWddk12fvQNj6ba7CHTzjRLAT+tPqdOqe1DUM/iGnjSOiytkX8nOrRA1MwA3eYAFNAzjGvl+ZD/ZJqv4UAhnFMqIt/ux6NWmz2v8JlNxo/KfKEHbHk486lrOM7RWJW+LDVCUCPKMUDF3Cu1K7941cr4I1Te8PciwdxCvYi0vmH4BHKZo5G0UI/yDNz9DumUmOn1snaDW6KBRNP0YsMWxtWa+bOegImPhSxE7IGzB0kg8UrxyzkbacPq/SXKUppnOSwFsx8jTzj0zRc+mrCAcMb0t6IFNELWmS0ZzRbjJp/htG6ieqGcdCJt/mzsSMBvSLPMSaMMS802Q/Bqj/XOoxSV911eMn8YIZjeljaQRN3AhjedHaMfqwPTP0cXCtCqSpsOx33zYYVqOm2xN9MZhO27PcdMA0ZdSsfwqoCb6v4uHZyfwce/NurswyrecRGCbRg3RukmsOv7P79PaVLyB+4zh7FMt0kGgzhFK7a+1nXiyj02fYcpYpLNaJRCEGWHRGyPI46k/asmRTwKD+1tgp/r+t5TWJNbTwYhQVEeL8T9qxmPswdqAQbDHPhb4Wy7h8RFddZkOyGbVqt1EZAcoqEn283o7iiU3v8dsILUDHGNiaXGYLnpCd6bED0Gjlg0cuuqzw3zoieY+i4HXPp3heYd4at0w8Dn8mLx9bPOcl1XyhnTGM1N22BcRr08wnHSzupx964HhyByA5btic9LdTqyk3GERONV7yU15XXTMHDTOUhori8bfL4Ok4BsPyFjrxBbMP+BH0byXBk8E2lHnymRF/WzVaLgEETP0Zb8A1UroF8xvtzlMGMxAfSbDelVKtF6xy90NQcFubkBrfoEziKZE1V1oWMuV6U2Wo2zaDiCxxQReIGQlZuxZDDc+eVz4BjtQ6RtjpxE4g4kd8EUGyAQYGrEyMuae0lwwqlCE5fuQiQ8i/7PUwiAA1qphgGgGC/rz7Vberfn+KiWK6fOgeXenXY5SlhgjSI0bl9wXlb9rEsa2V9oRXGSl5Xvl7nert4zxwOH6gmax0pOqFdWJ5/nKzvjvIp+PEEGI3yycJ0rqQgsCbtPxA2NAxO+kEvbRx69nlT6V1wpkARDxtWUyrmcroHKvW0gJ7utFLa53YIBI24EgYo8VRBxQ3p0dVnr0V9rCfkMjkFHlAvmcSSmwxj3JWvv/y2nnUhvuXHWMj/YBWiWufJg/cIexaiv7wP40h2XrLu4IlycbcllFjCU4nn5l+AVKVtsY3H6OQOeQ1kFFDpkJXS5r2Cfv0hFKSv5dZhtcxAtYYLFnuX3YIjI7S6fI5RC41MY6g8Y7TfBObAvOQ+mbZTL/2gKEf//mF26Dy+lWmcL1bLwe5pKGjpj0yg/RK+x9QRgqbZugPGjgic9Vrxa6QZNCjJouSxQeqeCLnHcuVL573OFvZP6GZ5LYh8Ew3kRAvaIbY1FjgfouhqJ9s3tRwQ/ZneNlfXKg73YEwCNjZ7uhipktrNRXoLqJR1BxtpC18wYZl8URyBAMx9xbyQ3pPGVhPMzzwXi7dtiUNl83utoXX3NIFhUvpPQ7n9y6eA7jTdzDmdj/RrOWVODtxvKjgWHIwNqtePy6P34fpVkGYXfUR2b9YxKWbYel1WqP88MS0HcsoR5KdTzjBS8KhXdv0aBO8tDU6/GKLL8ae+Qym+SZSphmES0LSk7kJSRqTWxIWXg09Y6dQq2BaijLxH1E8cOrax3aYPeG+HuXjAMXpcf3+7xIWuA1U2+/6lTE3ps7UjuB/2rTOqj5Qq6xjXIxOfRH3HYH0rrolf2ydZqyCcH4VSbIpN6LN+Ih+y/vCB+hA49bQYnS175wLSeX8rdd7dunlVP0HI0J78/BrYdiYW0Lp9IEqlMf2zQygwMQZ47x0/b8g+k3x97zSv3i8ibmsZiK95lKQdyQ1WKe4TcuwDOyfA2mgo4CAFrOsujNbCjM8fwwmO4EB+Ft5g8drl51amWT+3EuVVWw+7B2AaR4iOdrGYq2CIKVUIAGYteBwHxnYqDfj3j7nCIzjxEFJpXq4e9fiplaxPzRCe+UME0gf5jSBbQyHGvp87+NemvlgrebreATtNlPfGNPWaZQYz1g1aQmeZ7AY7YhE2I4rS0xQWgnSRr78+ze1l86WSgiXog5dYAgO+L1s1oJPf/VjStSJVeVjFvKN5AzJ5c0eZjvTCANnSzmkXjRIkfLRQ1UxPBviZS/sWzHs92JoWsgCcsG0IQFFy0cMVyytd/afpEnbV1TGzYuIT2J6dwqxq7VKoGEdC/uYChm4LZoNivzfIuywcwve6+8Wq5rB8+k0JgEqZKcY6vskPx7X0M0h24Q9e3aFnyB5u5Gn7EvFNP+agkMzxdVmRz/zAvQGp+jAMfv8yEodJiLQgK+fmAF4wXwYvdlUBPsSc01O5E2j3yuLFw6nQxECNoePNWs/mNp1QLbhBJ4f/UJcNtiWOSS/IzO1Vhe+hxm5vx2j1WcXMfRj0g33GI24r+mxMHc0A3+Ev6m8GfATgad71zOiFiULudmgUNnB76JhA5eMpkKDB9GYTzJvOrHnwyw1YvmT7kjoq1wqJ7eN5mfg//GzLpxv/o+4NHpSfXHPMtAGc7jCY5fTuPWIs+c6XKHj6dgTKp+B9br2oySbhCuf2Za5j7Nn0308we2T0tIsV5MZIJXoMDZ6EUa+chTItcI+xliIfZG2NeKQqoYTX1y81+11cfcLfhbcXPqPgDTqng2/SCgPVwGN6Y+dk2PufF8RxiubEmo3T+Z3fUK9Q5gq7SbpEJZtglWCyAhqpZoj8H+M4kMDR/vSwFyZ/vXeN6nTp/q8hBSxhGZzx2rakCo4ROCdcQtWMS+xsxIbpAECzJFiVu3a/+oxmtGrlYiUD96tIfMIk9+OxcK6K+y5Ni85aQEOKICrf0m0tncthxtu0RY2RaQXR3Fat5Al6SFWK8zE6ighu72ZTulfrKP8azEcqofjPJ8upXgTLCHEXnTbR0cZyltGGO180aychQMJUW72e1Bb5QEEs7i40HO/jqqIw8VyQgGco/UrfZbuaT9DQTXwNcGB2m3Mmca3Xzez7Ky9i0qJKXRWYQ27SnM82UB9sDEris8NeKAKCkbwmLa7oq2WF5ADfQOciejsUIf2537TQbyniAWEgSDezoLLtHkgLcvkgKOMXjgyXi4X8i7ucKxnoJjTB999HXbEDyyoqf+XX4F0rWNNg4XnofHIlvnSbcJdzVSNxiJ52LNEE7T6mDauzlrJsVwghpA/Won30YkkaR0roWC7RyPxdch8Ij7kdafWGC9WJrr8dvfeJio+qBGMpF86WoMAKHIOL8j1O+h5r2dH7rlZTzem7x2I3Z6zdqogCzIiFnOMFasdVfi+AOsuXBV464n69OZtSPcHSfU4uAAlsQbQHoUgUuxFgtWDJqWnyCQNL1N0Rw4Jsd7ueg3dNBzCxJdmEezzNvkHNRL8PMG/jfBoWeiChSMrVm5FZvTkAPzFdI/e0HOogyfq7+DoOtY7b2F+mLyWZc4MV/W30WO+uDYs7QNKRDfCpTIhKrdq67qWPaIcdFpmoUnxyyxWMe8kur6OqxW6YWh9c3ywRwSnHObMNFvpB5HCCew7/Qj5pL/7Aqsb7fF3ZDyjHQ1iG87d3EIrG0NCo043MySRxUtni7o1/HcPnMawyd9cQN2Ap6gWIQHI3yG0dsUveuviMjRdsb0p7oHGqJS3OCxQ+XGHtuKJ8CWnwFR4Npy5X15PAfC86JTpNm0dKpXeRxy3D6F8qQuX0saysOO3CGLAWj1+xeufPB+ePiQbzaQB48Nku+AIWKRXQOfZixhFGXTsnmqYdjwuaixu5AYFyeDr2gW6mfQ8e+jStLfSbOw+S/Fu4yl8o75YUBXIonq6/oSijCW4wuLRZA1sZQ1kK6siqSGQhSZQnyrWKY5Drips+rUP1Om4Qo1QhH9vjJxljjbAKpmbbQpkjz2JJfKtVlmr/xmUMooAEadcecEgr8I0Umhj5uE9Vq15Edy85Z/kcvd0/c1PRSFmqiV+3i/EuL6RcSYpYSjVXSslCeuaxG2gG9NLuEDxRZExn1S3WeFgOeEWuEjVSnuCTGxeAdwA2sQ628rtiCYxyofB+YWoJ6liYKYfKyJ/6I7EUBLujhUMx8x0ScNQIozZk/JuwfTkP0I1BH7CKLMoL8Rw+0Ui9V6ube2TUE5w3M0KHs3TXzDG3iAwkb0Ik2JxaeIYEZJ3f9g/TzazNdi7GCKhPm7G0ae+hSGU5HpwzGxyKoCL0p3mRZ8LxE+n3Xg3hJ4pEWPCICbeGoyB7Qcdcek/5LzPI197i3HyKd4zOclacjMTzsNGL7DLCO6Vu9g899Vu6bnppk7yle3Mr9mZRyQY1kS+kmClWHQ0aoIDKxbzjUtOTZkzugArY6pdaDnu8jprSOk6KohjElkeuhd9sUZ1cWOElYvxiaaeavW6G8xUjLVcrvcE+02HLRvF8q2rPUrK9FwmJDtu7h8JwoEpopJrPolt20qBhqZjhyGwVzWMFN40gov8s05FDK9yZpu9pTiHtmANfdTMCJa05NDeAtOIGJUY27cr2DDtiZQK28hBZojXYkFms0zUD7ZA5uW02IyVcVSPAoq3mRtCYD0LxpAudt6DWo3ixfjNSMxKF4+PRQf+7Hk4xDntXbna0Issmy6EU6DbG0W2ySu3oGA6l5rfX5123KAdxGVTeE4w8BzqK0/UAaTSZ2myFIDKsMImNHuzX8G4yBWvttFf7oJYhg5flRIfqkqtklwsu60XexHHqktasTwFg20j2ke9dIAdEcDbVNAUdvjHeLUxwLxLq6xd1cPTLRo9ybFxkMI1Vo+irt5a3VzHcn9aoXOXwbvqhe0epw6TsqEJkWSXV4pCEF8YpR5srclBZ9UwljGWgPj9LSvme12g2/bKHAALHHyfwJKvEDi5zEZ3mcfzPmoyo8eLY9mvvJxcMWVDu1kxfPDFT46TZFfZW695uRb5b1h09MQGV7hFRIVwm43j7dPPGRdXHyy/T3LgGoqaQxwbUkhlYvVFyt36Cn8BjhTO+2P+2P6rUDJd64xIVF0N6MQ5518G4FS1wyPsLZzN7BEfO5yDgY0R8ozDUFNbgzreYrknCs3j/uWMXcWvSuQXQD4CLWaVQtfbxgtDouKjom4QZ0HC/2C1m+yCjK+VYKiYdJqHTNzl428mEgiWIied5j1iROzATd/N5fc1qD6m0ImMTdnCZGBr4kofDstjvrpA7xzE2xCGtFPLoFgpyp+cKOwFQeCCDWhB8vb8ZGyBndILrsz9FF8EoIheIleR5DMI2oXIpF40LH+7QsZBes2sgV+VfXcmCmRUIs9XAz/gvMn473PK3Bslx1RdgfeNcCDyJTP7P3eLhTuOc/TyKmNENnL/1VDSACzwhAY01XDD73eN7ceDYCcfUGc2Bn+S6ZvjMyTAxXVYm0h5WPh/b/uhti/qdxybUQHb8Uqi/ULB0BwRpgIm723TkttvBaPR/uAZO5+v6PaALLgSnV9mXxdO0odFJh+QTH7lZRWASAP6yfc0FmsQkjzr6sOgRq0YTzMbsyMAE+rgiWbJ+iv9zXBjoizkOiqgOrfP8LQmBcBhykKQFxu5w/UGwDDEUn/Jteh011xgQ8OcwuF+euMNa9o0dYACxZ8Kkz7DtkmbLmniyXHkd1GAEEbQbhLa6VDAAc8PDC6KhZueVYhhYd6UsT163FccRnC42lJyAuQjImi5ZmO3tJvmaKzyDpP5VhE6i78ZfibNXu7YFUL7R8r4MwEwtHcKR3LC+z5O/e1DCfIzEqnrCj7khX0SQDDt0c5l3EzkTH0ZlyPx94vvHEIiMN7mLWEtRe0tTipE7zY71QZsh7W0s35Oe67b4H7f2KdzicuqrHhPG6wa1VkNJUDqx+unKB0DWXqGNIYbz/8ODA1ZSUWvJeZvKH7XBmDPQ43xkJbBoGVtppCyOA7rbfD7KbMPYe2ks1S9KTc8fLpc0TcDcbeL8kiiupc6/9Cr0gX9wXO6QJ11XL4WWZRe4R3wYS4aJIxbOVmBDIByKH1BWlqM9nQyGymBsCKlyl55OSZmf0fjMufna0wAIxPX9ky9Qc7sF0lnA6UDjWVhcUQCVsTRSpxH7mWLTMfdBG/e3/SW4YE9DgmKqIkUWOMSfiA2Fw6+SPu7TYexZfz+NO4URZYl16remLsXrEvZirk5ufpR1eTJwR47L4Vb87H7oWN20pEP7H0aMp3y0RPmMOLWPeWwUWzy9X0Lg63NZyKJ7mFxaLXNaGAN7yzdLKR3eI5qSwCbpLnTqcDqsrXimdY6ZZfTJGg1neYTB5RwBbhacQlImaMcfWxTCk6lQkdVoNpHy2qa/l/TMlM8wWq1HMbHlYS8g28689OFrUNrAO+Awh93vAbJn2uCOD2hcHgInmH4Yd/LMu4r7J1vCxlo5quBXolVItkDU/B3wPi8JFX9fe39KdLMcl7D+iUlcIrwDr4oGtHrqghUbMjmB989G0Nm2GCCAjGvIRlhOWLANoS5enT+ndVhn6+paA2nYVJbMVsZ6ksA1J5WqgT7F7c4/nL6kBgkSKFMxWoiFz0VhfZd89VqUKI9ky9pHNQGjERQHLU3aSocgpU4Pss88KpmHxLIsyl/DDwVbrevQm4PNOn1H7CXw4SpXN0F5aSjXTlv6G/VS/Jg35Oir6q/2vSBndJZRFU+xzUXsU3V6IASmNjFutk8u5DppKUYI3uMUrOKDXfEnFclwidgEOHEiE7gjRFvvVOgonalveXzc0FhXJ8fJrJ+zZ7COnom/ZWhUlnjfUcLOBkBnkH8RBAtzNvJtNYba4T7gt4mMkw8TnxIS1f1p7xFi3Zf/fmrTK1r8XLIAaszqDlHOWb9zfYVtRxrVBed9rpif2SWW4+KEAPjzjqAd6ER3Yp6OTwstmBNiIg2ilRF//txnHulhf98cGeCpGL+uR8z5b8dcekMJCe1ZiQ4H6cPTJQiLM8D2HsK6gA9IhmT87jyKF0+vN+uTf8R0Zf9Q2J8euYuaFfwjvpn/CgnHxT7IDGAHa1dShTbNgiMi8unxFwNYN5lhEGY1bchcYFPdoY5kcM5vJ5u9ONpubQjxrwtI2RQmD7FJBr+WCWqqoBaSpplAbeb0Q1V4AXOpp5dU6ceIrHAeYFH5bd3ZCDP180bzwiDZILi9BeSA2XGV9q2/PazMcJrS+wzlkO4O/mcyLipgyw+viplyNHCkg9S+P2lftGWYA1beE87hajU1+xHdUTYI1/CRfdmtGX02lkkaUwjd88LRtf1hi7hVIntM1Oa5kHnHGfT5CCEdo96YW38JDIh3OaU9mMseP8MHkRL3EzNKONVc5gqvXhamYILWryMSqioH3m9WFGk5Zv2Ip8o3uidxG3UdiavFlc5uwoYIPJWJNkd6rxEitw1Tkt+ErSd9laXybGpd8F+LxQ0u0qp4NX4fRmVwPcex4nl3nQWqRjKM3VLWEx12VnumhQP4Bi1AIM//i73gasPhOt1D0VFZxd58i0bEQNrxQ24b+HFB4xHgrQiUwdSK6LRaiMA2gFAiP117zD5qaaa2vDhh7rxsI3Tr3T/ZmpgtUH8yOapHQH3u5OvXyJ91kzxs3ZztFXaTBuAiY9pis+0irkyCsju8QrqlQ2Fjyey+9NRgAwf6H+U16kdoxu2hmt8QGr4X7Twr3ITsoYGvPaNhL1pTE7dVtZgZP2460D8RUOtACfuUWHKpUNMagYoLkRJCD1zY8diWoNcgZIDQArrLAuz4VgGvfCDKPRzXdMTDuqTUg+yatLIFTOnI27PnO+BN2SBEtYb+TCLm6bYdS6KYXsoMsfl2ANNJfaXQ1Mdg4/TzJzDjCbks8T9anQzE7oGiJ5R5vjScAKAopK+ddgBDAbFcwNkx9KPF4ptY1LffT+ryTAoItU9grZM8EaAMRbjXaGxU6c7EzpQfGvzVC9hJi55u/DceP92eZdboT3udSGabMkJxQKzFOFFPJQyc5mscakSdHbm+BiYNvV0eIhNjAIVdeBz9XoccJ8NIYCknsBdlwAUiaKarwFrHGdwjuxOU7yD0RuIA1t8jP9f2A8V15uheyG7x85W48piaZ1fZXgHueeVFsQjjAj976p70LgqjjOgTm5cGrkzLDyptE8Fe8zyFboIIu7E9MJlJzo0mwMFOQikXre2ZAjhbwIc219NvXJDIcIj961LQ7z2SrjU7PS912rFYYdxifSLFKkr34fTbuUwEwVuGWijr8mwYzh+yVQ0mP7G3b+/Z36XrQfSO5QRkFsLAraONMIzrsEzR6m1BZ9COeYPcggk9Lq8EmZAOHOb67i1+eEi78DmdqMQZbVgdPPsiisj6W8ltPshII1hN0ScvOb/I2wwo1Wnyv6Ob+S6AT2joUmzftVuZSYySo2s5ET9l7TlXx1gVYHvEdCeWeBpfCNKUrIdJsYjyNCZRow/z2U5NRRHnF1XVOiT9xNlcF49SS+ClklQp6pMIoIAxSKB0909pLNeO+82T6Jy9/7TtHwjgnTbgClxVzYj0FZJdrDwyC0x0k6ZPaj1RK3dUnGN1kjt4qP3UAn0FAu7iZQxU7fQ29a+wgAXWODYseodzL35ry7MXZuQjVKrMmpXzGULJ3lnd5/5CxRD7uKmR0JeotNAtaM+x+Q8CqWeWYaZGmnOm9IsQfEWtighZ1y00lbeI/4+VnGFGmmuxiNu1YshjMI7AKHcEr4h4bY9wNWJSnWAcuzCmdLVdAB3v8aCLc3Wo3U1jZ2MnY8lo9/Y9L1U5vIXfeb82KLMNfAKdn0dHZr/IBhazudtxMoTkwp6bcilIsWEatSIVW8LB1jUTdLQQsmZsVn3V8hVBTf+gfDiOgNGhra/ODZCdJlFoe3oxL13bLAZsvHMYr8fZwkaXQ1OalQguahnmgKCZWBGBmxJwaomOPrZq3qePT094AKHDjZLzrOg8NfDRh1v1xpsJCspNTJMDX70L1d+Qh/Fua6+j0xnu+Rpea+b4JfP+vChPiEplyox3YF/YN+NUJLRWFOW67z5vidTxEi8jQCuAm6I+NIygUP5mw4593qy1p6H/SpnMC7E6gxYBN3eGhXE4qYNhVoYsc1L+WCo1hqMufdfLwlTiXkZy7gZ5iSdx6wIQPFehlLdzrufhyO7e97cb/7fouXkfnyBFaVEASG0QZt5KXqXeLWGWM7b5FHF3Ou6dwshTEBbbxCa7nzykus05TRIzsZUt2mAgO5lXDYKppL+9tpb1DwVQprrDDctTpjLNQFfo60+fdmB23yDRQ2GI4FbTWiX/CkrZ912XDkZdApLQpb66t61Jlq9cib3z/gCeIFmmAYUfiTbPGF0FkT1hpNH7y4C97bUDoYZl0onrV/yKzrwmMWAHUMyYFjRSYea+3cOO7jzJ9/hu98nsZIpZBv2oJXva/Z4rxW+ZvI25GIZDRU/muL23xck9FkqLT4avnsJKBz3w+b1wI391K/x3HnwftiuRBf7pjbVObnkKvMdyQvlbYn7qFWpLxieEfCuuImSH6rm3YhetWMev6n8h6KOa3X5H/9P5lq2uUZaIdGicSivizFNXSxHGx3qLiffsiEv2hvQOxVMtD9PSRdkAjcDJHACa9+bfiIvQs12gHjmSNfFkEKADDziBIIwAA43dgK/1eS5IEBZeX8v0XXnqs0VViWAX+WF60DGbrIDOCtm+kxPpDlibPdp60rAhMQzTuMxmIfbhiPYN7HKB57V4xcPnPRbhnVaDJ6ti/mDpZvczoSaNp/uHb0xiHORhS4ABmPvizLJ43Nrz4NkxnXN+odtzQ5CPPzI7dtKhQpoPKq93bbo81fw+9WF7hBVxatWxKJ5upXlvn8TURxPj31jz+DjWUNt+YE9MBvnu30Ay3ldHg6vumOUm3NHP5R6dTBbgfpe0TWmDOrAnzolU5JNMtmk1ASmC2WeVGVxyMI+TYJlK/Cu8LqcPGE60fDIcXZw4duI7pbHjBRaBJjc8Ruo7tq4D31B4wBVTGFlsMt0huYvLSZCTQvB3FIDsSdOno8EMUJLk0sPkygy6GGWXPzUyUMDnCU1BDAIRb643ZOryn9975zVeTPS74/rhR1C5LW5IRdL8AmuBBuagAa5h091Ya7TkWBVz/Ic9qziot1+4cclMw3bD71RY2IPItBLeeNAJbUrLfqg18Aj7OYGwNjQMdSNd1uoHiLeOmT+N58TEGfMWZ2RcqOccVn/rR511DThd1IOqOTzKfi7pn9BM51I22rNt3VUui4mXr9FdVupg/sUwvvofhR4wRy07pNqLu31NCeqY/ELTr5cTk1/lJc3N+K2SU6PwJ8zrlG3GOLF7mSkMZyZgCLpDVeYF5R94E9fh2z0CbgxOiOUqmaiOWakBFjZJyzHmuwJ0PsIasDvddIS56YQdGLDzsA0mqH9jlI+mt12ul25XTh2tmwyxF64FdyEtEAIHODD6CcxHjwTuwEOj3P9JGcOp0W4+G6XGjV6erjqxZmGeaSYruU90KLHbotBJ4NURQqldf10VQiNvpJGDThbPWNADVxBqz6EbSPzBDIQSBAaO6mtyOGlSb1OGFr1xnpnyRF/G9Uwak1h894Y7jRjMsW/gRKOH5lLqFPmA4jWfJbkzvLDuA2yywNSmaEo1mlEuIb+jCcykW6ZL/9m9vXfJa/+EztdXHy2iWIA3Qzs281lQuslVzGY0tU6I/ch7HbXteviwgwLpV0m4tkrF2TiDXgyUpdmT6vDyLePsDeegWnKBME6RzYxCG3w1y/UWGPMTuaDzmT21jok9bzOzsfx9VFDyu1XDhVMHQQTFazuIQVYYmTjM2FNV5hKURR219cLGy8AX68+epLCBma0vUiFF1IPPoUbbHhkJeNdKymbjFe/NScqQjH9nnaHi7Zmd7CGq4UlnC2nmJzUr6f++LR5z55AzMB2T9gMMu+Wo8PEzooIBEnBcGuHAD2vGJZUengBuUA1MQmSnx6iqc7xhtZD6+3b87WwPS2GptKKRSfpWIRcQnMRtS+7lr640iw1fVAR5C0TqmUTuXxPZ+1Q/qT4p766CGI91oJWCPAqmQDMYjDFGvYveAdUUZ42S7Wje/i2h44ee/+KGr+tiHqtxcMyYImfNAyU0Q5mX0NEasGXfDKj4HI2wQIDAa/BLUj4B8yM6a1qDDCrlwFaDe9KRlgZWFnABnxBQ9ii6FnXfhMkt39xjMi0uO2yPDP3Y80ytVQLCNnMlVtBovKmgqlS5xHQFhIn6B/nFjshDkHo+OALmzGwHhUjHueVNmKc3/6tq2cgCLCgHRcY8SRDn3Pv7WvXnqyPVsXp3jD/UZSwQZISjGEmE0DcA2awlFSH2ztFa/CtBBEyX4Xb035qGpfJ69l0iHsyB4W08XiX5UfHMfkDI6Uu85FNOSXnKxTJgfsdnfVZkjwEEJ0UlkhNwPhs6gHzB26A89voqCWfxsZIssH0Qw3ox6tfwEqrFb8SVTVWs6ezpORXpmzqtue7ufwHo/MHeEYi3AQjG6JLEW4bNPpg2NvaLuG2nD4I+MJz9QONWpn9Vck6BT5oafLU0ZRtnlCwZJcNCdONmYQwbvdxjoLGetd+NJaUItk2vGRUvGXRtUNzgOSt0On6Om8gBryHwmv5gVpKxp5/LP6mC9hRNq0wAKI/FsnnlSAJ8eYp90igQvw0AwaekH2PKxq+6deeB28DLgO5ulzOjryu5A+wRm23wuLEIc+eDiRhDy1BC4N0CsmTjGtatlOjd53YIX97lm+yeKMsHnBjMFVNUMGQhWR3g8VJx8L5kSWe/z8NuNGr9+0F0rYZElZglb17MjwnDxUTFFLHrrMGUGvOyBQsWbFDhSt7pJBaidHO3fP217j+UpzkKIbG210Odrpf1U/43ARwY+FUxSsYpqkh1EZAV/xoBZNZxXlPZP3b3PM6G6vUvvJxT1LioJQ9xNq+hfY3RCDnC0WLoik7oTRjswyPJ9sMQpgsW57UmPhKXdNoMZMCROxQ/ms+yamJF2pSqciPrIGNqtF9xXemgmAsB3CKbnmo6URuZ1qGDVTSuLLbjTo8pHQHlopbCuVZk/fzvnxUVHdVQeSXY478woVTTt5wG90P50bVLMb761wco1qR98shTSVWY6W42LLrcEQvoYNi04WePpHUuvHWMcxR6ZNF4fFpKgtrr4GwxfQOFQ92LhV9nY/vU6FbF+q6cNQOK7ZxYuC+Q/0Y317x7y7xqJxBdIKyuU8LvodrMuJCKMOkJJq6bRaECAdrvafdvAD36DR+dUKi2+IODVNQUJtUKfPKge3tg7KpOrL26SrKWGxWuufKitF+OqELHsVQvfuVpCkHCO2RVFqyBOD5dqqcCCFryEGXL1cwO+Fq8T9KtEvAnFnd+kZJqYdf9Zpy/u0YmrsADxrjtpHkbbAaLAcf/CnpLrduyxH2b929uV73wnCT9xlkLhA/mqt+6hFydes0HNtrGbVI/0zElGksWJFGe4btupRXNjg3FtrfNgPWCosDdbfv1M//sRFuaaTqHhj9IqIpvNJ1i4FQ5aviRdHtrvb3oSiRyxawOnQZRk75sZICpYLsGUI4uqUr5qp5TVmXKIWFJ+peadJ+L86EFYjapnhhhMsh90NBEDHnzj/Y/r4BpmMeU6rD/hZJ+Tmt5RNAOfHCenVNoygICf7qdOnMpdpyI/eO7t4NGzUzJ/x4hPJwT+AbaTVUITvFV05FBnXGLKOKJleEO0zwD1Kdcm+xba1T02UEeXKJHzL3/IbCeawLwGHRCPwRI5odvGCVhZJwlD/FMevbOVH6pVslnej/GxwahGYzAp9IphhZ3YCAPVEwxQp06eeJlAoKeVtc4HpzkXJETOsF2L+VVQ1pcN1pPZoSabtI5CqdI5lBXOK9ubIHzfMLsz3kS0x/vDatU4xoOxZ6qnFEJQycByYnUvRf9j8x76evKA6n7axXnobxg5M2Mjt4m40hUH81479Ea/yhK6q0VUY3RdWD3f0HDjSOqrQYH7744YlJ4cZm/VCjUa2GwhbOAoWq2OxEMfBhPjyYW3jItxek0GQR14hJx952kh5aD68lDDhLMsspVe3hcmoBJEPWtaL3VOoEGe5Q8lRWbLmPhZwCIo9Hc7IzCCdcjjLjox1NBdhzrAwNAabuXBjo14SmGEXk5D4RDlUuJTaDLZ2bDTzyCXoZZ8ufiUW8hnE4OyMTwb+aZcWiW6XCoRYMvh99md0zbtFGljIVgD14aIOlGzGHx1oROOPHBbjjpqwoNIzXWGYzUrUtr+MeqWReR2KBx3eKQ+Bh0FBnl+I20uqOcD3G1pTTXmxdy7fw/rz8xuedjDq5OmpkzSpdYDfwidzpcpIfLfr7PH/wg7f+gDBMDenoDUEDoIOPEB4JCH2qcH3C7GoTVaqXeK9n0sSRiTQN+SKwal8WOeazmq8EJqCrhGl+gzEemcFCFaNvj70yPC18oNYRayufpcxNTcvDkY905qey3hpiLDvI5cNw1Dzixcaolc4T5pbG/QGyPii9oCThqyN8eJ7bQpxKV4LsEYYZiKSp1/iCMqYmAM3wcu5OuLRcYAnXrYw4vNrErjNcMMJCZbvnkH6j6aWUvRSc1keqY7gi5PT7VR85iGxFjUxznOqoEWOqAb053f8gS8vM32c1b+ixD2kSS9WUrGs2T9ZmQe5oAQvivoIFpUCaLeNVXcpRK5mAdDi9iM+9ry6Yk4FHP8UzsxGmfj9nCp8xidMT/hOoREfEeFJPPX49XNMRwgsWIJwIYrDosir450eDdnAvPYSWM1wcaoioc6FO256Ds9/lGFgbnB8+eGXGMEylocbMGQ/MlZhLf0ofjxcA3w6LCdrrhjkODMHNK0Me/fgSd5R0t9Whx9EG9hl0BFnMUoCHn++XSr4rVsq76u7lPkfFNiBnm6aW/MH5ftCcwBTtrItYJj2mowLCgbPAuPIue/uOaWvDXSjejEXMQ5v2w/pJvGY2M0u5jYl8+p6X5u+liaebbENmg2qrkhb8nQqeQdcxsF5Y9DGRm4oHQsx0oOqksdJu54fpvLHu6z3fdEQhL+It8pbS+Ke9ReJwlTEr0e2U3FbgqUFtS78S1UxluTb45/f0xje2HfgElL9preYsGMX3guLM4JwxlGZZ38n5jMNhjndcuEygjwq2wa5uQ0cp2b2U+HdCz9Xi261P7UjqRKdpCDBHwIxbX58PU6Qxf7K3czLSfnhkTLZzKaXR6+fYEtIHAeVKu29CTNSVVy2Ij2vEU46B0A2v76qkTAJY1miwlYUGtkZeovf2pE8LjzDbgAbUgKAQGvBL2yeb2NxMdEDjEgHzoC8kEaCociww+KBW2gZLxzdGnJg077hKNN5z6NMI+B5VaffQdm6uOlRaY/LuR6K1hgr2jmwX/7jAqJAY7QHi2Cx9sgA/R2EaEFJ1SaHINbNLipOx6zzYD/7OoMKw8dlk6q8+5GcYqXhiIoZuIbLy4rDvjzkD3Ehe10KJgUZ8/sFNOLihySMm2Vgt0Ik3InW5pC9Yf/J7HvL8nBtpKwl5XJMcfcHDKhr0hB9FB/c6L0aooe1b0zc/ZeUH8ppKfyp2lsp9++kg9VEftr2z1uyE5FEU2dO6D7noVf5eAXAO32Xe0x7WL77BPBNJ/TxR5ObpRz3o6e0r330bjyxH1O7/3JKg12gFNQ/frecjeZfgSC7XO6JAbGd3pwYZrvGhUXuAyXKjZQNWE0qmpk6RUJu7fpFlEJVcqh9ibDtnTMzj9scKLNhcCSiCFHXF1NCTub6a2hEnlZkAlfVDTMtx+l54RmSCHo31dt4Y4FyUEgLrrYMUv9Pd4rFrxpa55jGzzbwK1cs1yYtxh8wQ98wr/wTKGQAUZVVydMhoFCunu10FJobNmX2h3YNDcRTQ7RCS5h28Ly4nAZvoo+zGCkndwF/bEW/uMZhJgYLmtOOCJou6p0duu00kXFYsBELywqayFz763s6FulX+S6Fk+pr9HFK1kgN19LLoXGGmtzrsVqBkJoMO9hC9jd2kWOnIe20GkN60346vwQxPeOG3r8kDLHS0VUxHyX5sOilXrb6CsOURwJJQRFcHSMabYfCad/iYzpSfOMM+2jLxnThWI5UpNH8QhXUFYIcVqbmC3DqvK9CUoZjXDYbUJci4vsmczJ47M1RD19l4rIQtUGvh4RUxHTdRYWAd7ksg3Tt4kXaqDLwcvpFzGjAbAQYoGweIxa1wSTol0LHiCa8a6JMz04nmw8ef5i0b1cE4hW9RtfU5W4AK7nQBCOef/Ckp+TWGhI+MU7ePzQXSHw2lH49mgkmigEaY7w0BCBkg7Fl7zMerWlZnQnt1WMptu4dRTuvIgLPnl3X62O6tA42peNUe13yIeHkPMBCGex+N0MzW5+r/+/Bv/YU9XyTY3yo94AenIdZgSnMCB77fXq0g+rwNweKC2ZgKeWxbgPGQ4hVXLWqA+JFtGyAmOBIgp15s1iAPLNl9gHwbwWynyUet6p+zGiAC0iFOShS77lCYDQcrnNBZ79CQYsBGaPsnrHLbrWvAVHktCDjqLTsusRM4HX/tdpfIkLCOMsfzDIlptqe1Zj5k8kP6UQuGkaDLEQyFAXsk/QN1aZZID/f0m/2N53ZNmcVtSAEt9yY7cQqtgGNP/Mb6hF/BWyV/YbS+PqXm1kxyIo5DivhpcIauRn3xnXoG6rIY1nRnY3AveGtoVwBKC81Djhb3SgQC37G9Dn11z5gUy+PpT2HenGjLDl2ua8eerOeqtj8MZj0Euj2xPW6/E4j6WKMvQA8C1b5DGn3lyzlmPf8DZAJib8I+vEe0SB8HtEdO3oE5RMK4tuuTjhEoC9cyygXx6eyGIYnJE+sEKNDvWBhO9rRH+yZRJJ8Uc1smA185f+/UYfBi+PlIs4pRtu/1cxPU7E/bYMrT9DsaSvIq8agQogChjotyMR/404QpH+HJDQSdkUDlHRsrlPJRafEFAHxKR1xr+wEfw16mA+fJjD9RlpyG46j+UQK8Q5jIMnOI5qgZkyl25OJrul4pvTjRZlrQNyQLvUhvCVPmHlZZqZuL8A5zg0gKJ6n0Wkmt1jPe9w/gXA1FnGd1HwhsRPGYUaQpEm/oGkJW8ecMw8vJGuiK6OnXjC9UHf2uA4xMM3TJTFTib+iniSn5Z3rK5NHy9s1pcA49Mk4FuGmXaNHtT4PwmO10H3tErCdQFGO2nXFVpP7RbSKC6qJ24GQdUHxL9uSs6q9WpNfnUTO7FImNCATvEkeLLJnY8QKOkSkvShf67VWFWXp8T1ZvZZD9SpQE9BCCsARVZ+f6uVonQc+d8pBX+eZWF86L48VMyw1Jcq/SMfhWolywMKOz/Y0D6sQoULBIrgfXtXivxbpZvnJmpt2YdzLBsZDHACLkBS4iHK3M6ZES6oBGXIY0iTqpQfTmp5pXGbW0sT4HURsUlWqMxoxpV6/w1nwl4s1YUCSoNjWgGsZOT83dzdbxr4atByXiNotVSuyh4EqI904qLTqgj7LfoC01Q6hUe9c2uDMkyO0lcy6C6hNVEK3LVz/hANodxwjCLbSD3eBq6GTmPofSIl5Y0ioYFS+0ioyH4xhCFsH9nK7Ip0o8bhe4kJwYwpgNOO7sDfxKDw5KJCIyLShRsi6MGWDwH88MKcKI+I5s16Fl+TL0TjZ+mtgd0kQyIeYRtLyIrCJpvQwXyh5R7VVVvMESInPst5K4gSpGZhpebJUW6DS5D1BvEFieX6Su4GyPbgSv4IoTKtq4Mvre19OX2xmIocFhxGdbWNCjKRldIxOdFKyiwsIUI0rsDJwVTMUzF0jZXnM9dSqIrsUKCKJ/dGFkppd9iM8WykjfuLxdXhKjX3Rfxf6YQakgChHf/ZQbtxiBCj6nC7e/8PcxFrl32Y+j2Fc3vFc+5Y0UlrMpgPyfdGsjSF/PmITXvufPT8FGS+hMfN7KyE6B2VKPTYMhoFRjg+floD1b5TOCRSOg+6rYUJw5pxJ+vZlYjHuLwtef9xCcthAUHypHNquX5T8AHZohezZCuJJ9zGfgVFWnsMg+vbCee62KXqhj9Gf2nIo3kB/IveFe2pZz4Fi19Uu6V0Vtm0f08yfG1kP7WoVIEMlc9YynlSk8wRGPwCtXZ4FyhnmC/Xa7CWEEJoLOPWsDV9+0qGbYOrkrajcJI/80+3hEqcuYVmZWCNxDFVpUvoR/o3VMoyiO1KUTR+CwEsxzzPFQ5vtu82IunlKWZGNCt/AftEzj8dXowgUh1XWXiip7pSHYFnc3FIB3CQaw2c/UZFq1DKJsaUGN3dem7I/Q4l3RJQ+W1X4HAzdieBd52wqFHmybBYZtk0K4z5OeN4ukf9Jpcx4ulPvMA3YtA2KMmouv5siSl98tui/nqpCF/nZ+pTIs+vHN0/Y3u8eb0ue/hx6QMw1wJK+2ocLTebwBS+KQZCFKnayQ9MdbCiQaZzW75GiKCS4EwPRt36IyQYcGYaOAASMfPm7Q8QimhivO+3vqk1UmkCOXIz6FOU2LGi0p7wdd9Dp1dxm0q7xUMxNeHS1eILTqOow8graC02V/z4mO77+EqvEoAUDu2ly4gdwNbhjsC9CVysBXPslqLcoZa0RWohAXE8Nz2iYguZL2LuVcZUoXX0VuNxuu9qqIZtxGk7KfmmkKXcXrBYFFZbmo1OZyfsAtK8PyyoINrzPs7BGbvPTyxO+1clq+z9ibZl+Ykqi0zIngXJECh8yapi9DkEo0ORF+J1cjzSY3cFh5yK5cD/Zhozcvccn/VvZplimj1MSlER/mrs4f2IlnWtM6PRRtoOT/V8wKxI02O11zOxtrux07DJlvLLvTkpnWuKf8L9NcuAqngYGMzn+Ljd99tJqdHocGsi+gmiNLSujssSrWCmek1eCYbgUl/aw5XLzwbCQfQ91Z03KjlYemdgePmCy9dWNQ5+vybD7dWTTqpkTDy7UlD2rtkAj4gUPodVC01Kvj23LDAy5oWhV7QLHWQX3FYM3eLJ5xnOFHADd+FyEpYY1NXbOOg67YeK28GPrYuISutkvMdnigal6/X/nTzlRYQShJlthhxQrWzNmdCR3HtF+oAQ3EDd3KBFPUNNR+srfE8E+UKe34C4XpxrI0lIJb42XG+//iEAKO+rohzxgbUnoeDeKCXGy+eU6sjQAkXXL9P8lErunDW2Gdhs+oTrLvQSRP8E5IFZjtcw4fctO3bYKz/xW0JtFWBIttvnZhtBXecDezwrAg/CRdT5iS/aR0v6ZdfANtg1uhcSNSf5HVjOgVJbWL3vKDpv5RrtvMHQSQW/xOeNr0YkQih/dx6Iz2uTcFcDs03gv2RgODS+tblGlJgAHL8tWosx4p7WZR1GAJEcW0a/Hkpp/MCvMITD2uLtFnplCJTYhzoYhrGqFXQP7/xUtW+x0IM0M5Fchsi2lR1BmJ3Q7PoflODS9AbLMWgT3nHoCLrp5zAkvdAA/Gp/lgZibC3Pnwigxg4FDisaWUy3n7fJ6+ChMgXdUsz+bKgaseQOgZulqQp+axMdDJTwqoE0Z1qB1Qc/bLJeWtOoOhwta9OaEx4rYLd7vA/tm+Kf/TEHDErKi3jWsSk0fMiMxDjYwVFuUuL/bpl7qnwSA89J8NkXGaBiIMVeF817ovoG9Kruwh8SZcr04WL4XfqoKQD9f3NMmZvtfz789ATUwE8O2aaAjyldm/bfuULjcRl+H1LadrfmmxOfIcV9Z+LYh7lSFJxtKMqllRM8YeXR4lNVeykIxJCCvOme61upMeKLFF/0oOrg0T1iE4xqemBDkqghyeEj8c/e5t7ek4xBtR1jCCc5lIBRzyU4jS0HVl7ycbprrTfP1tx3oWBtRyW1Kv8NK8BcDKItjFuBT+mHED74pMyDMA1VNE5QD6Sc97XFcbQJIVYHO7FlxYgen1DpDkSA8Xl9yCBEx6u56inC77d/grTL+V4eJVJYFynU0AHwSU6W1ATelZAwMv5jDyFU3ThbZXjcB0Rz8YGychdOOCWm1Pr5cTIeIxFbWevry9UYjrgsSB6YT0wPJdYNR39R+YbsRJ6dPVzb7Wu63A6tNjXphic0hH/WTI/piCADbCrLR5jsMlqhmgfNjVPmmvkFgcWDEQ7xB2il4y/fkUqbwnGHpscoRyHHhdU21lU3ZJK7PUwZZCA5OfMxNhyRM4qON6KWIBEPa91/FAHZDgo2OyVymzbXNcukIrhIXJ7VFwp7fblZlIki16XXRYSsMD76FDQ2ZuG6knGZAt3H6DBZhZT75/jG2HTLE86Z3xEAWd90zf5wC5n6TkdliNyKjQ/xAZfd3nr+zaAPhNGO+O7L8SVUsS+WEm2xyCxc04SDcSf8ebbnkrgcuZGnTM5NFUROJ/l9KUyHMOIMuXuFfKmu20vtUkypmzXIVeEuPZvBpBmolHujK+lmnyOo58rlfH8VgQ/6Xshy9sLeAd4mSnUZq3y4+LP+s7/1KvpVUEWN+8b9/N7tQEfBo7WkqSu4dzy3eQeONscRnFGbQ3wVaWgYJycBbtIjbmHAbdNnJtIKkQwZElUMJB67sEGjJddB4wXGmTIzFOuudjgJwSF6geJiK4cn2Vm3BViXH2uKo/NBNozxkH/yfLb9eGLvO0+rhtoSMi5LuoGpkbY+rPJcPPwZNp/cPPXagmPZ0YjM+Orb/yedzgonhhOItI43qsMbHBOTrqGh1eq2amZsn467GOWOEapBhZYbCx2YO+oxtfmSqhETIIWnItyPvceBHIcF1tkjWfJWUqUa+3QUsqVXb/8Zj5M+ozrSygz3zgbkxF/ll6ftKHAjNAOGSksoW8fjERupci98/I6y3av6Tm8nHYsim/Wv4NyPJzRjQzeHUwOXUSrulzOLx3o7GUtFS3sdACpvgCTd/qIJNBjkWW5R2URb0Bc23GQ17PtLTTD+Tt4AsngtAc4+xwfoblATJtOCh7WAfTVAp7IwGxXUCgIhcxl0TLsBitxcMlH71SiX4ITQ+5OhuhuLIqK1sm1dynLJs4XEABHnR52zJDPBT2Y39yYlqwNbAqjQXfPt67LP/jh7ecvB1xTPWlILW1rgraRAyJ+nYtaiQH76ne9DJRDGIpkIzxPZf4aFnFYNTWLiTVbGbb1KyNlTKICMwW8zpkxkwFP13bl62UI/V9XeJC1+erqJJL6SUBopJ+oyF5W68Q/hlUT0PoMFPARrJWbY82rWlUJQl1UnSqOnamUC7uxZg2djdJoviUZEbAtdC6M/3gpnbKiKE1ipFE93FfIuuoXKyQ0YvNGJzEhFo3FagdMZ0Q+NJGpKkNcLACKoHV4f7HiVZWtfHiPZNQouBI4BonR8ly5UW+kItwdmOj9ItMptF4O4RbIhoMw66GM9r8tZqrltSqJJEYNMfaBqEhag+ABhSlo3ooVUVGqHnnYvAYmyGqln2hINJUQteF9/58JchnugxJ/4qLBwQQunrvTn+j4lw4uxD5U84wUHRV7CiHsvaZWfD6LO0dwUZOqVANHKWa1tWwtEimpFcFfzaOheZbpHlFESkpLvTUVjDChokTIHnR7MRARMYhr5QxJU8RSFTgwm5Ue1duCreOPZi8um6A1sXMzZP1BDwuRK870EGV4I+4xXSof8OZXPn02KHOvHcKaQzX8IleTCXBgoqsGZvzhtUyrJZvXo0oiE1dVQ8ZIqfF6dbSRIhPRzdZkSJMCxCynsvNPWwlEi6o7MpQH8jB+kzAzm7tdWZtZF/CkvRijvoEAROXETAUjgLgSC28QCNY9iCRrQ4ysZ1ScGJlg/Og7IqBwCZImiiFNEXqg7W5YD1E066dXqj4n/YtnoVWdfzIKfsUJImK9Nc9DnslB74otz4/5lXwFxHx/Sidil1GiLldkro+t4/yVN7gAN/mYEIBgmWnznJuEBqVsbfaQ7FE9Jk12IzH1deAwX/YT1eFc4bmRM0rOxWrGsA1IB95ESakS81hGEOX3jsePQYdA30JqhhFGGnbzBorQjf40SB8NHWdsGEduuSNokn8jn614q8F8C8Zn2urTOFsNpEIr09LdEJRXpkbBhNImlxNonubLA4FXs5MmFQDN/i1vbTx6+dvJKw/Uh8Voo2NxoEj4XflxUelqLs55Oqe6ekn9Hm+B2UuDjbLY6YXhbQu5zAV6FH14tQir4ta+0ZbnW5MfHT3QhjtwJV+Tjeb2eVbLJFQd0mRb7fb8UoxXvyf9xWfk/zizfNd/RpRAWpZWDbpDO7ATj74g2YrC8hP/B8+AyD9dzzCsMDCAcns9NdpMvO/rL0DUSjyDVdGm3MaWPPopwEOnY3yyq57OzBwQBIk3hwam188LkA4+/8/S8vh/pBld/tX2UKvH044Gjd6qiIdE8Vd+qrWJUz+ep2I35Ash5EABhpQiOreKbMwIXjZaCsBBl6HTxOJ6jK/oEt0pAXmJ1+QJqyqdsdqW2M5YTX00mFdSvEKG2U9kLtCbMcymPebfCLikSOczIxlWQL4hg0nss+TJ9RtBFwP1+JC2eAU1l6Vu4L4Gj0cknjsosCP6UmzUq9/C45BF2aYQh6zcZ1O1bfn1I5rAd6+fkxASaQJMvLlOpdymFv2DwKw5BiA+PXx8AJk+ltadNsAL/QMHUXCS5V79Lq4hEexNwGxuKqiFf8g70r7d+92u8M+oEXc6GU6PpKs/9178xK7ahhPiRlnpKtAXBiyj+e0C+KqIYtK7dDFOzPoBug6SvZegkur4sNIzeSmdfahsGETphZThlrJF51XpwechtxOznYHVJOjfmf9TnzcIdLShjQjJD6tt95DgJGC5fuu+79bcSNl6VNtjG1nUKoPdvgERwVSq7ZUtQ5MCqJkw3E8ALLDco9hyiRmSsuIoOsYI/lobllJXzrk0wdmZPlXBla3IrtgxqVO4OzvOQskQHu0p/RR6KOZcCgnunKDlNAomWjnIHCB1+bXwp2wwlKE5ejfMPO17FhB4JyDJ3BirxQ0wYsPumI0jtauXtVZ/fi8qHB2HVyTN3gstFIESCECiZ/vch9H9EeuiaE5cSmBsH8l53apuLwW3WHhbI9TFp+XjHlVFBbqEY4OFPrQaO3yZC1zNjQcIJfvULcfAanJfNFZBhYXSIZN5sJY2qnxAPrWFYcGBjLlqQ/My1Bc6fn7TzaVGYTuR/Vp3yNvWovBQTO/YbrSYtOxRVG2LfiE1n0q0c8jc1kY2QaF2YDb9hLjOeuNXYRx2mRLPS4gNpUVAJPgEc9sT4VrjEM+pW2/Qq4IjQ0jJEKrC1OIWCzdQy/5R7+doG3IAgVPNONvoA6mgLOfH20FMfboA6LfGWcwFqymf5ugjcrX71IIkbS4pNN/emkAlKdUr67tJVokK4xbX0pIBXsyfZAyT5cg+xaKliGhbJaCHc36YPSqbi6KjaMWn1cmKb6u3R0StudWN0qyIyjg9bfd89qo9IgQ2jO3OnhlwK51XgFrkoHWiIV+wWFWDuJgWiqF8GCf0Hkn+TKayjs+tPCVzucJj+qkCbbsfvNYzLxeVRzGNQNtPruSZSbFdkbfQRjw83m4+54k+KAofsI/XDwQj69zQScCFoXKEbDnaIoPVOo2vvY/BA7+MRTok7pxsrI3EpVThIXwZEL1lUySeziDsa8NBlfuDAhKowYtTqXqIouCD0LL7Mz7HG4yKUiba/j9aQdJ4cxMjA4Ro3EysKrpqnXOAOgISpbI/DErmbXUGci4O5KuWzStxfVlJqJ9rr1x1g0l2BLA16Xw1A3rZCXVroWWoojyf+8y2/Rf1Sc7zenUu87La28aypJ/vHfWHdPT0Amd/oCFmx4bZIxp3z7u6TSPw55m1PwF1okccJclIjIf3KKe+6KlopCmi5yNzo5ZsX0UaqqsNvr+XpytOlqTSUulkORxB0K3uZn92MoAUhl4QLhJ0r0pXven79WoL+R9LsjvSrhcNYRwLzDZNvpZMjkTqwKYOO4Gf5arWdCaGDmJGYuPU2aBeuUcoqKsYArw6XgahqRU3hp+1pnSX5rC4GI7av3197mKcGFZ7rarp7DIxWsx37fTQTcUJKa/xy0w2rta4Kq65tG0Ux6WrXrLBmWdQwYnYWHQEjMnre5jaYqnjL8kyt2jQ798bQOw2vVqhQ7P6uDfEBJETVPXo3dis22EU5VT+dcR95jg/RCSUOVsIEg3W729+SFi/ajK5I1+kbLnkgzsy2XvHIcsoZx3NmnnbkKceXrYsU8gAvuuvYCPtq3Zxkb4eXhLOkTUmN8WiXsCY4f7StZ2Y6DKhRKLVUxUnv8xfVWb8ZDx4nUqZPeofC/6LoYV1LkPmnn4NY9JgLFxxy8rYhaTUri0larAaC2+ZJKUGJgwnahoUy+9NggznlEGrtyz9g/ZvmTnC95z8Hp1mGwCY7mAWuWUMtT1sfpZsepytrSS5L2Siww6smkL2exTcLcHHYRxcRKp8u8KmbZw/XvSCEiGOwXOyU5K1XFUMexqcK8yA/eL2pPDWykUGCC3dFPw4CjNPOOg+Bff5j1X5ifeJENrsiIYQk0Zlykej1yTHf/vP6dyFb2P+QV/cRT1os98z1nwQ8ykROP+FPys5InQ6ye9EMG0hpqfkSAIqgBKxXiBWfY9cgENayBe5QkDAG2p9r64sqaee23kj7IZIgi1upoEfAmF3IilU6kYniW6KcV050gXyu5xb+NJOXpbdVqMIScD9K2CT2Qt4rKLLXUtwAOVTuuJ/37zQdEyCd3c4t4Fg8sfZhf/vNLZuR7QbnHDIkQKDaOofyFoX0UTm6WQpnBdromFoqCLfYCpkyRCcexB6++IcaKlKFRNgweIiTXDl/DA3mZa8+uL4GAxZvTXUs2EacYx3aa6oaDXaV6k6kYH4Lfg+Ttk7lpm2iUk1AI+95xWo2C2p7cPndPmcWQaGS41nFIjeDpdP7sEqA6xGuIRcAxQJDScDL7KmVxjC8GJE7rsXBtmiMKKvT0OX9bAGuH9rusxRM6oKBtBiuwhT2Lr4whijsTIHBl8j9S2Qx7suzN25PJHH2nfoJ8EOipKRVdGsJPjb96Ng68Wid/5+PCpS+6c5EbAoE9LKHpH/7LJoGRbpXISLRVnZum8rdfw78zn0LuUX/j9G0k5GsxIrMT2Hao7DI6/F3i9LjSn5QfOxGW8fdUYvabunsKIWjDy/+iXR0xuxrpdIhQicNoobH/rj77VRrFuSqC5XN7/Uk5owNvFJwed+PphZ3xp4UgCdIf9C3QalCxAeQhg0magpv1aWyg5hitZpnuoAy6ivoi8b3fWvOtdQjwL7FOJ0lJS3o6VSi5QTX0tnV7EyyRNg5xPY1fhRmxNf3auTbjNTSL5bT+oxrImDkUIkGxw8FYV3NvNy3l++Fan9k9h0w5EZUkyHodRXTQOSo33YaWUzWd7kz0FSoUEZtoHm6kunhmnWleE2/lLRtwckmKaAviC1/uIlL9fGWRUhx9aUEh8KmEncQUkJzSXyC/zOwx9ZO9ZsqA7jO/zpvPbUuGH5y7Jcf686rnGaQnNNFCNxp5JLzkZwQr6TopePyDRJox1mzq5ZfoWkAlZ/CxoJJ/Lr6BMdUS9Cw0tniC4PCuJHmQKH49S9II90mfnXmPE8oD8XmPaow6GRzY/w+gcqNsYCGlCZpf9zGVhx5hm6G0OBR94XCNk/Zm97bp0p6PPx3kItfclQ9CU6FLuLQ/KgPxSM4GU4b9RtZwgEtkWhkzIzow/jun32j6oX1EmWCRjv7pS4PrxCC2u8dk+Algjgs7BoG3IDan5hWd3X7WSKAOCGqSZnsbw0l3id20I4/sTrdr3bTGtfWc8oualG41DtvrjzZouwsI0l9tJbJS97V0QawSOOGYsMBCL/I8L863r2HiZ5rmEWL3tswfNKF9FShmsvC4xLOZB6u5z7aY31Vji2j4ekHkh8Z/7KAjDcNlFXFdI65WkvSXG0g33/6bnlVUeN+S6enUfRKp4Nq6L+KQlwLvPwhXefwJSpg5HAxO5bgiboStqyzwGiQ6Iw+Qxa6UCZ231rdMAA7wgGRcT6Lnog8UnskV2siFtJTzFmsST3bjxcy9eRoWGj8KzVA1DTY+x4CG4ntxpYjVksr/+J5evhm4LbCrosB/e4JFy0s7x6AMMxsrLuiRKMsijnYy7SRYrMf28wqrI7utjKnECBAa2i3QGBb3VJW1DyOrfwRg5Krx3q5CtHFl0vvFYwTSIDRu+0KpQ/4vwB/P2Gt7M3GzA0WV0GIXeFwHIU76DuW+D/IQJQdX/cIr0VYrF5ZbvBGe7EgcyDa7fP/CVi34Z5QbD4qJ6KzmNHOKpXdf0HP/VeQatmX7TZVuwap3nxUGyzHVQS9q75WwKa1DK0VyEUydjbgouza+XlcUC30lqVWthMggvkbiG9DKCHPlLNrHhBOjsvhSZf/rT7J8r8u5LGyTBork1s9vwPy8Ebu1N7i/TEEuL7rJ81sxyVdUcG7rG687sbzMPXPOU2hF6dlFoN7Hw//5/9knJoHIgMvAl1P9Fck+JdP9c5sdYOZCK9lsb311LA38DIKlEugx7+2gyAF81rki5htPwtGXvCtVfQewL3Sany6BbUOpMyGaA2raQyEr/dcz+hHq19xp56urInbEFmIZwiftS+OGi4Y7+siypnfxz9R8YUU15s9fmHj11suk38eFnqoSNmZOdhWIEUg+4i+Xop8Zu3EDLM2NurPWyozHAzsyMATp867bJJu24oON+UHmz52DPtr3No55taxltRiPs+cr/wwVmRXNg4Ywnt8YAZnmMktxa2gylvlfRRkrlPEK9lNq8pN31VFzrmEUCkevOdn+uXa6LznZl8Sz2ESovDgKVdljd3dWwvdbFGA52oWzqpleZ3pne4dBYzNgcm2aMlzXCHA4EXgg24MCy0WswQsj4bqNbnJ4lyTC3iIFxDqa5Wv69+pqFPbhuyNRYABvt1XIgILW34+0oS/CxgPbITz2lqSq3GEubY5E6p7rs2TO+6HgNu9bFd+ALQE7P+TbWZBKxTKeiWZkCkH4rNLeAkUQfbyo84Nl5QNtcaQntBt2lX1bTgHhpZ5qJU7JLm5lGZamC81vpzPVvU6Zyl4TjtmdAf19g/NNyStTVDcR+jlRBAII3Ne0IFqxv0HANSO6M1SNpjqUhaRnF6LlgepIGHiE2QidhxO4DPZ1+1ox7hhvJfcnYBz3OFeGxN4ioYtLdBRtbZhuLQBCvl5AQN0pGotFnG6kIgt2IfxPb3mJLhoc3VOCiszlwGdPsGkrqv+w6GaKnkr69UrAtSciR+pFcBs0pCL6V1f+NPUwu7CaCsaVXXiDpLrfOPIgR5nKmviZW0lLIagg9Pl5hVcjnMryJD4oRMnbJlnBtWd5SdwZl4DudhI0ledsNm+xAAg9MWO/wy0C3iT9KPa5/pFaxtOqZmmpPF/NFP6uoRSFsHJ3GP1gLMsTZo6Ub2fKxQLz8BM9qzH9k/lqceHOVZTveodjEbELjzcb1MnAZS3EAKve32Uf0rUiorWoTHt8CXrEzlo2qSdlzPWFd3AA6aI15gim4GRmKbGZWYWGrmJNNiTu8WIUJOWFzPYsT5/nux6UtW0OLpMbIaCRfU9gqQ2tY0c9tHDRedaGMGiJsoLguAsPO6QCbx7jb9GOsySwocy7Ox5WAMb+4drBOzh5QQf2YbDulZdrIUKum2xkxVmzyFysjRiauGlmE/8N1e0tdlGvXvGciKxOukxNWFW6KH2rzdmbHpCSCeQXrJgiOwD9DSuyxNuDpNUQbE79gyHYQ6dD87/weJt5XoomWGl1bf6hunKB7/6vhu3nfL5sUwTvFIECnnMpjuDHrxf+19RnVm/ge7SKM+1www+XqlZxwUh3GqiYH9EyJwyRY/82lItuglYy6JNwztiU8E1HX+/a+pPm3P7QWo9cPl3sQ/v3WMcWoDH1RbdeZEmLUClb0cLWEqOxqx5lXXhndic49AJq1HmWU9G4r9RJ17Wzt0s7TABYxoQIOAU1+sG+hC9IUAP8JjO66VyBeR1VAg9N7Nveix1yhcpqOLmdxRIZuillspXPQ0+eXDdStADM54iny+jJvt7CSmUNL5ujFd/lIU2aXaOk19PMGZiIwYe3oFH1zorUWdw7aroGO6gJXcEsy6ILHhGyJFZre3N0gpU2d1r/PyB43BY8clMvKz82gxNzg0bolncoXpaYzgdg38ATxRZt7WaopuPHoSLkoJ69+0PGqgsrzwjgMHYY1yzAJW2zIQD5RGskmL5mR00dz5SjQBJu6VUohyBF/6KqeSYeYacn89c0aLSyndQn9y3rmFIWj63T0G83MUfNqDyjNyQGkqgD2Mz+mqNk8QmPZsSeAmKd5hjt8cIGeo6IyU7coUCO3Wh8fNnv/EDQ1mA1OERozFi02qRzEBLOlD+uiAUb/0k9wTdfkrZBzvY7Ldhnrzvt2RtlVVjv4ko3rBXxuYv+Aptu+IQfKxZ0RwNL4kNRFRNzVnpkAvBSD61yONhXlSZOw/81OEJtbDPL4lbrjkAr0GnBpBF3o781PwXVjd+j2tZMvGIH/r+SXwXZacho43AdH6FMSJg3OWSBB2SMWNETzgW1YXusozoE/Kjkmz4pCAOJXyL+zOhCB3AsLAIznWpinUUmF3ReMGqugESXYNvUp/xkfNMfIsJefAO/VJKQUNyNQi7j6/+NEZXQOiyxZOvG/PNMIOU5BfW0TXzAp0gtEpQW7NY5SCv3h7+6Ut++3NIJLkGEcRm8s4EXKcZX8OSR6b8jvNWydaX5OjFjECot1TtXoR5lr8BIDB2SklmVuQA/i/K3FhORWVo1OouxUjR9CZVnsjhg36/g7AVsCZXYyw5AFqZ+YG2rOONZXAFfearOrde8vLAV867uvNyHAapsPV9joXYHR8RlTOdRhDcnt+3wjMCUn95OeOrF+sLQzIVPZJrJHRMrU5E/8PHdOSkcwgLZuh4GLpG17QUN7sI0Vfp3Cwa3cVXODj3DxYtdJyItM4LBZy8Md1JN0pqVUyRpnGZ33us3fZ4osS8wxigM+ZBWpLWr8JeiIwINJB3m1kUn8bpt+dXfDANWXsAV+z6l4XCxPB2XGUQjax29wv4NGgudtXiT4LPEHjkMtn7wBpil0eAT74Fk0peruA9n8Y75ruq+0gzvJsJ/IobaCDkZDyW9/vCR4w0wKThxz3Cm1Jbs5Q2yN/1Oqb20k4kgH++V1ZKFMGfVWx1+bBF/V4nayhyjE27FffrH3o/OXR+WJVKIG83QeSzJE2JRjx2zkyGQc9IkYRg+zvCzuKNCweUBBsRZG16ys5/3rh2D6GhXoLW7J6v699QVy+kdZjKRtQk0k+uv2ynLVc+mKWlej9UK5Qflio9waLSX1zg5ZoYXEDWFD6quSK4FZ9Q5EK/1wDnn5GGZRlIezYLUHHY2iWby5HA8jzk5L0km961a6P1V7BqCYQTdKMGgQ9Abv4zLm/c71c5BM6srDclue1HCsA2gBTxSKHKqzciCKeXxd4Z7DGESr7yFOwkej3PnGLzk7jcUGm+BtQubGIVdc86RR2/fkUKXPKVTwKP9sSS2zXJ20H6bmujHc3arIxugynTl23acrgxPRLfXEkIsE3Qxjo7z899LHoi5oGY8J7wQV8GxdqUwZNwjNGRbHJvntSeRyuPOJQQK29wEjEsn2D9F1teXlgQYbdbPBsCCk7RmALiMT3/m0B0pizXjqQZMVeS2xxmIWjxIv2TBKNFjVRSBW2rtUZr2t5F4Xrcj4YKgAjO9M60u/QAu494bycijnMgisIB8vVyGphLB7qrBm5+D9+bWeU78Rx7h9v4bTXOee/vl2ktb3R1SzVeTTsz0w2T8H4D+V8CJ3A6QQk1E6xqwqIfDJCPJ0qcnnmRgE953BraFTZVqpPb4oeEaK78L5gVz8DmNA92xXsdXW+NiYfKg6bVg2Yyet9DpyFrPPbDHLS/63o0gbHXGrzQ0fdjCI00O0rJi0lMVH1ZlNEXqHI6KG7FV4/CB2xJWtdbp17t8sUMmiDgXlsz/W/4ENc/XAjeciYYamVq273XJ7YkfuWFXK/6mtnPQl0ci9qUfUSxogQHzDaVJyZiilqwUu13xBhhIy3Yyq/dTyvOrWm3tjTuM4bJejecPYF8B4AtKZDs868YR9UeJ142/T3PH7dHCjStSZVHz4pGN/jYEgNO6GQ5vxbOgWJmxDGFwD/AkiKq1sGLnVtJE/EhcNlnmRIN8e4JT4Xe5WUlia4DN1AxapjlxI53lg1GTcKvY7TBHE/VKUVQuKujcJkh/kNKSHO9K20XxwnxIga2Wt5CVvl4wcjN5S5DspMkK3sv+lbiRgY4lS+eQwwWb+u5Ata8BE4AWCEbk0r3CRdXBGJwgVjZDyA5P5gG6T/asQiMEUNAsV8yjZ1C3BWnzUq1XxJ2rGML00anJYFq93Bc8mmu+94pKwaquI8PmGQIvEsMtCvcZekjaPmOfXrdb9hbGXowuFTXkuxJp+l3t96yMmxwuYSzyyzldYhiK2IpJaWsCKGZeCfLlBWW0MFP307L4txxy8kbj2tgK4+V8G+z+mgdKc7yQ3lBLTWPhEyLicJkdjc1LKUvrFNdzCtqEY8mtCDkgXA7fItLDUc4RflKCg5R77Gfvo3tsDgESjmI5QEOZ3/IMJKIb21KvpgPs54OkhQREkPYp7ULW4xmiL73sBXWndjI0baF1JVNuRfaiMyEL78R3lN+DYiXWD9yVrK274IHI41YVHWUmY6h2YwhkPXv4/dtNCmxBt0wCs5XF7Ytgdye77wIA5l7nPHVQCkGL/YA9mj790oj6Ulu/qnhfwfAOOQIbACprm+IDb9xevlUKFMvZPpmflAqa9VJA8IXytSWNeRw89AxaqfLnbwBSGEhJ2yPDe5Kur/A3zQ1malYX1Nz/kfEVgvH62P9l+r4IjrDnJHB3Slloou0QvoBc/UKIsAouzLrmMpDnkgesvT+R7pm7vZgKSUYhtpie+5hfr86qkNfzOT6jHlIIzMcsq7t+oktn9Psgy6ruIQM5HzPkSyNZSZZcHPCeqsWJH5CoenxFPuSeYc5OmP/OFNIS9AOEKV2tsY00V1ADe6JH3ue3jtTI/nhovgk3hsjHdZ/HVlJgI1BzjcfOkg5uGfsmRO2wzfPNe0A+9hH4D0WgSSf4zlGRzQQkQORdbHWogdM40PP3KdoatnsBlxWX43x3l6f2BFWJpO/kX4GdfLGTzhyNHkcY/u0tm49QVeFkUlVKBXc7TgzpL7MXk4sMrGtk6nrdi6H7HcmQGi3tTRvV4aAbEFaYFxdBw/q6fzvbvYFdQaqv4V+b8wqkUs5SNL00xdkJzDSUBoWnTXV6XZzR1k92VjTtcV51WSk6TMv+VSajqlNGMbVHsyaktbnRbDadt027pQrh4ZEvv/ZzWgU+N+CSmuPTaWyfaZlqcYnRa3+WWCcn0hDzwIE+jSqNNBvdel8PnnmpWVb54pMEeWwIjLVov/d7xo701tIm6QJE1HG7j9GY/wKJCvnkGwW4kpBZyUgV9sMBPk2QgGAHCQDpPd0GsP25OsaG4hGxhZ1aXDJaV2dVnO0Vj+04MIk++tIvUYlol6ZrQ9GCxNLZkCtDwToqMe+PhKGIhAWJ3+6PRfm1tbR2unXyRmiuvTHh8GGidylK0haiRPgBe/Py7Tmz6u1pF2R1uyuK5ohiiT/GFTZYgoW4o500uCIu3L9Vwq2CdkydD/rQPNbq0jXUgSPGCgiHKryAVNWS7NMjWbLHjZ7sOUg/DH9cxUpgLEV6RrmMs/pMY0y1UzYBC5BybexyJTptEHz1DAP7S4gc0b5rsJICjAVwAq36b/784MugQMFwoM6REKMKAi+Yga5q7K4r+tDxgMbItFUS66Bitgmp+pXwBl7pmwYskJhYejjYfF7lJHmTFVnMdI6ZzLv8A4m+BKoNZgPVm4XQaTQwANGbuQJLjEWkkVb51P70RkPDDu41L/iKzVLZGCwYd5Sn3Lp/BsohUgJ1q+jsB2Rj8904hX0whqQuJqeCsDWvWxwBn1jXnZSawYdbU9BSgp7WUgGw1hzpN7z/oFZASPYCa9bU6PDvS22kA2YDdhCSRLaCfWN+eEWI19LCs5QAFDq8VbqQQuf+Y61NHtpVOH1K2243EojQu8Hoxi2xNrz4oh+QDBFLPPdBgDqgXn+J5snqLcdERKr7b4GFMpsr1LNJJihohEOPXQhdH7Gevf7LfyoB58ZnsCKWvqhVSXEa5OHkRrMoAMCRdnC8IasIhAqLgVF6SNsUhiBN6t2TwCQn3Y7PviemzKHSaXLp96XtBbbMHh99CAwd5XCG3RLj9nvGRrqZotBG0w9EB5h38ys9VHqMX5dBCA/vom9iZ3mAlhiCZY5Riu23BYOqEvhQdIfiJBOZ/oQQ+RG2cDmPOWC0zqfEtBqhn2+R1YdMOKvvKEYjaIRMBI/d9zg3eoak0OHoXduIT1c/V8vO/PSOFPqeHdQJYmlDWCBRQ747/i3RX7clnSca8NcGLmWxdmQFcB8psOuFHH7OoSx/G+d9GkOe8PsCR1V8RZgoopAND7YouUJHse31NcaZawDjmuuDO5nAq5oVOh7+7U96EUd17LkrSwI5l+tROue+ISDTG1zC1ZBdwXP1Z4E3ydzwWtSP3/r6VtSeJt9BjiPJDQrLzzjKhbJTv1xVhkUrt3zTD0yagUmQIbuS1e1xDYEk55ZCPFEe70KLpwGl5kMsGVkEnZ6PhtLeWuM+3Pau6Dp1Dv4ftNe0900EhpCaerlGtum9YatltQ+Zv4XFvou9WIAwBc4TezAC1tuextXj2s9+Js6ylo8kfir8XHp5MlZ+DVsRikUtIvLXxoVRhUnBlCvXPKliBT2RyBXgv2jEB7HtqOOvjAVWnFEASkdCqGQYmpbOqj8Z6IYzyUpE40QtWObLeQ4dyoW5qvXPIkyXlNHqgQle4ofQ+WmSWr7P5Ekx/dWAYVP93UIvORYKtw9hkk0eqEpgt1n79iFySnqRu6aiLMsNw+Wht8ktIVL6S/tKxWJPjeAXvGhO1L7bouYOqrb0zmtsHKRcchNfgbi0vG4ZHbdwm0WZbM16hUfyNHu6xplA6QY70DyfsvLQASMeuwTIHlIM6OD3FqHVEe+ZApZcYGNOaRkRF3OodSQAmBtzPWpEzmgjoHgntvCkNlGlOuZlXt8KIBVpDFwUpxVJgqHfwn6eM3VOoLMVs4NOVlkv4zX8am+QalZ2HdKbzlz9MTlykj5x+OEJ+95YTVFIHfohgMJOOHIB3w+px5ZBCY4RYscLrvoBCbXM3LXdTIVIAlqRmQPWpomKjLOi6QW6vtffe1ArYksMGia9qm3mKfj+bybYLztVtiEw1XPSAY7oCKAdgF8+JFloYsI25Y4FlUhs71fJX0QABdCMQsMG0crVVADJ3FhShZ68zzdDB/s9XRFoZa0VV4HDSHyYVOEbG6KOdhYrM0ZvKnbI4e6+yQZpDdZZY2DWm3IZlqT3+LlvsvmjS0icXJ4D6KpK+Y99NqyLF6qhlfsbsMN9dpdoYQGoFTEekscPwQOSjuYTSFlAAEwKOTzBfXnQFs7uqB2Ata73yi0kdVf7ruUmHxOVLwzDf8/EjC8RTZL6v6k9Qc9nn+f9/5YVw1tAuh3DkBKlbmH/Kgrh/BiDSpYwCCy5+3I2rgP8QNBt9HycZLztRIm1GffKEwJPVTi86poatEqA21UcuYnNnGZiEki6AVRaX0iLlUMUgcWVTXC2D9LGj1CEUJli+c6KtZclwlPjVKWyb3Etm+FtHnoFrXRiMcgIbso1ioZAWwnJo+9yA0FurnO4hlLadFtdGlCpBcInjcj6pjvng/fNw+srj8+LsRDGutLeDFO/0W992Z36Yv08iT/pv3AWuJ1f8u3lt1pV1wTzqLS+8jZ3oaUclMjT6yw0FrnVtviMWOOYG7pvVa+2+5fIjfYitQZCEQ3O6uSLpRlL+A8xVKM4+eYht9yCOl2zYq3NKdf4vJFOVut/CdoFrP/0b3CfTCuXUR9StxEHf109LEui3ZDakpFlUvf2C6njsB15s06LK8oczKM0VHSgrZwIzUgSVSu9OMzIRsRmx6wkvfPy7OqvgfMRMOCKTyi+CEi9kPkvn3+HaeieOYZ0/hjYth9g+L0FXU0dxMw6vlJs2T6gr6qWc08AH8YydT6hqWcVjo2MjSzldRZyhDPOSW1acZTET2iWeLMgYYPM5OFGBMnfHpC2uZKvaI4/6+qPhTE/YK8/yE+/j/UL13b8vSThpO74Zsrj84ZBHsu2oAuNwtLQyR1iizqPSbiRbauU3sZaMS6Q/i/4e71+xc3+V+FDA7cvHz/BfQR6NWLyW9R7/h0xPxC46RJGTtfrtRhcfuwroZt1Rxk3L0ru0oXn98CwB6XUW8Ch8mrIsb44LqA+5PRk3TYT2I4V4R0CE2v6W/F8zvleVu5i0YNP3Zel7EvVy1Rudq8Gao6xvf7iXxsbsT+mHU2uL9xFbIKYgdUXD/t6omeHA0rl+TYQxk1ZelISqHiG5IZysj2OgESBQCA5M4o8nt0aZFrp10MMyBd1zl60LWUdVl328SELBdJ2AKh8EsA3/Nw6tL6Mp/S4CmMCPiiYWuPwruhBtBHJwB7tpb6xw9Df4c8lDR40RcPjkv7chepiXWiYWOZrpQUCyp/98Bjno4LnU51gEbicfcBRi4n0EI5qyLFD2SsEHIz2SLFlcFo3x1gBqXd+LW+Rx4wJdP96y5ko8O32raxQ0hMVqzcu05rcQypb12eew+6OhieWZnUHN89UMlA47gPOdi2XHIPAb9BgNBWHZCkYXnuLs027r60Bk9gg+W+IMvi//vfsItw6U7pt3iUXtkC4K91Yb+gTqWu00RD5HJ8OLfYzM/f7NEXhw9+S5cwNoo9QI0ERM8TqFIybDRjaE5Hk/RW1rBWA8IcwT5ENEsrEmf+zRTQ75kXdv8RIQ4Huu1R6amtrQqY7C+ugZpNMkf9eMNrY0wwJPL2skqxAkn+US8NQ0cTEapUFehSc/vjUoYQvDC8/bDsrPyvPeffsnAknlEp4W2nSVTEPrp6CSDXM3v5p+0nLPa3Vdbk0nENDfaUPaTv1gSUHWJpzuw7hi6CWYVddajj/tO4t9dTzALuRa3jBui5XHN78W4/9DKI6i630YyeWOa9A1vUGPutEGYUQ92HR7xa0rMGC/DqMhWg7iq0O+n3iGCri6wOVdmOwMeFjDm9TUsZiDGZN61nt60EncRJHucHKXw1mgNjqJY7OZDwAUu6IiREpxtAXN1wSewFeXJ7bT+R7JzNFQE8OB+qNOpQ0TEfgv/wNscE5CR14HdgPgfH6bbbtXWEr2+vZvGV+1TcOBasTia/S1N9ZT2SldV9Rywu5Rp4B9OR4dG78WCqY0vKLJjeMNdUoIM0IRGghy3eyfZEzLjN9pd1JoGe0sNqshvOYX+D5EGIByXF7sZkc2QirlLsh3ppv0JMhB1MB1Dv3DEXRa28WQ8f/tXS3ppxg9/kCAJHQq0rhmfj6mfRdOh1tdAiI4kgbGF0Q2cPHobdPVtAfyXhyMgWKBzjjsg3MuoX3cAu8LcLK7MjLEf7huAv+4DtVTQ0ttU0bhnujAOfy5HeT2CYrQzT3naWD0JI44XxdOqRIEpmIAgmylLkViyQONirnC3DuzKiNhVpDOWah89j4n+NydVbo1FrXWIOtyl3tJjLUcbSw8T7Ocn182yA81XWnz4iuIsiDmwW41F0dwR33C0BFbqSYMCQ0FNKkh2BThpY6MuPhPPwtjXMn0qiCzWVXzjzaDNAyo/uhU05rY5XL//+mzz3Q/B2tVcS1gsoT/tuzIkjNipJ6PSoXmJulmFNc0w38S/BIj2Td+rvFiW1nyi9vnBsB3SOhX3ABkiSmpnya4wr6L1hvOeRIHDlA4MI6cfzMUwdk09PrBmmLZEmGXgbMTFhYBzHeuaDLXO6wDHdKpJDxsATco/1DYghBScXh6HtB1w1QbccnVnnMlLUac379H9Ns7+V6dz5wHJ78BFP6Q3JZmKjhi2HL3TZ4XtOihK+JnfWbNNf0w0QFtBfOFZ5amPfzhOS3Tw7wWTAq9uzqnQ8IkAGGYmJW+f+M+cp/WcQbgYibA+KLJUQzbhGJ8ue0A5hv4jFxZgwcjbh12sVa9dIvenT7b5/I6b0HByS9/pj0U6lIl028nvsmZeGT1V9DoHETL6WtIuFzfJLaSlzOVIcYydjhalZ8PdkUSTDs9OTTSj6ast5N1JT88ya2r7llioJXrRgWt54TqOPzaq10sK3EtFuKt2bP+yhfqqVHAGDkFjgna1llRtG6mCJXStAIPGg/BqRPCOcRo+vbn/+kI8UDXqGfToSV0c7t5puwAtQ1fq0GqJJFaYBssLBpgV+TKk/colAykTlT9IkRLn9f+rzfPBrPl6cQHKsOvrrAwHlwjo4JU4AEt+DmklqCOuMlh5p6kQB5yjXn5VMlnYuyU9H9dZWecwm8o+7vrjcJJo6UHx+B6JW2jYP0xkx8YH7j7fLgm0REPvYpdWM1xlBp91q3RRrtZexhRbU8HCzm5hxLBheV8meH40/Acw/rYeWTh2bnWWs2S7JBiZ1IE8q7QpdbehDdeCxZSMP1dr0nKM0RB0INKYa+XCMZGybmpu6HLLJslyxNJn0gbRfN9ke9cQcnec3magYRIfFj8qMqLrE9ZU1n7bC9mb8GZIujF+vbRAm3Hhmkz++4Jdlu1QZkpN6edK+S/wVVNQu0fUQ9uOMvVGPU6LAFi9ExEQGOu1JTXCdtQxlOAquYlxQs7n1XoCo0SLg/Zeg7nCpy9/7O6PisdddBGdpqzh3Mxd5/te55aE8IH/FdOG5HcVtK444Evs/SJ2k25dQPT9itkfFOMS36/nn8kCCf14sEpU2lw/hMl/vmwdP+d3pPZk95RoBvrmgcnOy0gvydpTtDipxJi3DDlZlhEcW1BZairgHEKOoZ9RpRyNQ+wOt0lQSJvNQIROFO4gDld7Qj084mHO5ZOGW7PF6p+u5nnftR6s2RRYuhPnFkcoImw29Nv4mayBbZq4jSRr5+tf9oOy6di6AdocESeqU0Vg8sYgJRRdH9tIfmgOT1MsGFVF6aVZ2edXprZMvvJRVc1ycxak0zbdJJUyiu6xyqxE74d26gkzmqpcX497Jds3CdnlkqOgn3R496kDgiKoLcBv5YZvB8bgCLOLY1g+aI1yEHf+lj6BTcuM5ya64rlOAMJfGQuDPun1MCJu9dqbk/i1bU3ORJdYnCpZeZCspr4HMF0GlLCe5tU2cprsd6S5vUICkKkeOmJnOgs5zgqfo5ytN9aNym4BE03/Fv8Tjxr3AzO0dBqx/l2AMAkm0IYHavgFazsWbBmAI7SoFfDLoTTj+GiGe4qh9kMN9I1tw3aGKS0a4stKBgsapt8P3rMrElyl4PLExTSSQrQ2qDM093PlR329yE2kmKUhQC/fICMt6kw8bc9CVrEF51mZDyhXDUuK3O/Xl0wQfit6snqOjBys4kUE64KCt2zt4Qb3lwLTW5AW+gZcoQJisCPxIKNI91XDWcy4n9tGn1UG9q/cb9vWBIFGpUtx6imhTuDo7OqZKmWWBGvTuwRxuzH/2zdRd62DJu6NRypSLtaLEKF/4cH/1mD5wLMfwUF2fI2ptelD9MwMEdSct8uaKkAspJOufSQP8k3exfra5mAr0rIOqg0IJ8nQaQJy+MDMkl9/EkgfXPdQLHyPr5u8osgErnyxrw7YiR6ScP3E3T2TfV9iBYyv/LkLjeYnBRQDjsdGbda6o8DuHjxLngU5ujd0NoE4Z+q7o066F5F/Xk4AhUaiSvdQ6hj1gb/wyjdP5Zmmij5DNKPjUV0bbh4HD4VTqasBzlBCvuMHhSrTDTRPvVPuwa9OtRgL9oSV1CuhRIHZvhID3OowycwyQTzMl4auvRMxK9S9c6pQKGrzk739oDWQfAVCdI/n5Gf0HXD1jo89O0s7BLlYvkbc+upNHesXZPH5y8egqtY1b/PFDIAkFFWixIZDR9XM8Q8n0rhFSmV7ZxHUaVN8SUEWSfjYKVoZtpgBddoG0LfRUQCRE7605n0EqGrr0os036Eh0O9Lk/UYq9mtFglCRBeULpMLfgwoqBD9vnbYkGgcbxIyUdi3LefWfok1kQ1rDC6MDYMvPv3pQMN051pB7tKJXvLquEkbfAVav70KU+PTDXvK5Zn+QwScmEVskUOqDlgL7QKAqRtyJaCq/x7Db+40zsIoygkB8DHLx1pxSvZuKShau3yvn+zyDVpYNKKw5EMKmcXIb5xQLLa0vmRobsYPAk4wkiUAULkFO9tnbXbaI7dGJAl3alqgWA9suVkI9Q9EhtzInmu+PBF/FKPzikp5ef6qhCkMElxzEQKVBnLwn3BQ6JhjswTOUm+5Pf0+wi289lv6sNFJTXB1gGjHRqyShQ6A8Ae7galCpCa3LtZADjCtCzFA9NtUdggxcl6eTOpxnSuixYMKkpdXcrGmeX/hP/dXt8FZ4kCTbMZhlyvUn10d3xxs2VjNGUi61LfXfdka+JhdqeszABt7M/DUfBqeCsxibVjEpqcMHObw2vTvBlKdhcMk/So9hoX43RemjhOYbJdKIipoR4bJMXwKTT6DtVHpI6CmMELyC9p1UNeK9myvWbU7qwvfKBovzJ8JuflwqLExZBmWUpAkG1zuIDhe6XKRYA0tweCQJILjO83H3M3TMNnt7AGPFntXXdD6ujmU2fvIZMcZx55LGlMuBpJmfQMHl1JgcCH7yWwttfX0Ym2Tlkm8ZIFA5sqvufUtnYd1tYo8A+E+ifqmW1SZXkwnK17jhHThiu2WprRdhZCYFBgkndv5WAoZXlB197TQ+rmUVre1wSXpNMVFZzcdu9MWVAQSo96oHtj/t/Uigv1a+mP+9loxJNqmjodvq5qYrsT6OgAQPbscYRVFEk1PVUmAkO7KHcvAT8NptMr/umgow/ybUn0I+QkUpyLLraq4lc72imXE92UVWW2q4CSXjmNfB9qyTh+RamYCXKdPJINm09FXsslURukjmRVzTDBq/Q5jX71K19D4h8ZXaNpr0zZeirXNqERy3XvzXi/e7CNHkpPILfv7QcZSKCXeWRXrJiShAl4hAkrrPwcwJNiaCOTAksILS6jsaWab7ugUPcaPJuoBPAYHujBfLKv0mpKPqSb+pWruTENIJSeCAnk3Va6UGcpQE4ADRbseCwsn8Xp49IvwMxuc+6uOfBKyrm5I/7P6Hbx1kpDoXlAW4xKaF6tankUXQKQtra6MjF2ZSoiKnXJqKydRcZvKYOlL/KZH0rLj5sY5JYOha5PxE+u7cPMUBTBXhx5EePsLWS38mGhTamlpI0NWj1udO1bslBReQfGbbUrp6aMdBkcvoeca0vWf3ECucljQygqtJcQCJ7244OJVwjUXNUxviqfHF08HU/c9qOg8NrngBFLQmiM3NgC36XPxP2OYTIhRI+tmQd3NGTPXeItGbcTlJ4CBTV3cWFV/fB6NOJbT+V3Q6xIo1FNh1Slbi4M/3w+uCpAAEhWYwLxdqaIcyb2SbJhjTehoei02WRclIpcNvtNDxuvhz5PxRBzcJBPL85+fBYtGvsqq0AazNH9eMyEXjDZk50PC6DSq8VzV4OLcNC0SPA7R5h5Wdf6Ma7EPZAPYW44em35kHr687ZnA4eCdqr4KVNry5oB7+cEYJGUMssMf+7qURzoZkfhLxHCQ8l7o5xF6HTO0lmDK5NwCX6KDwztkhadcmnFjLKvbZPJiFDgYgZr7ec8NLxV5vZTWyiCYQcADIXxNMRN32zUUL0AxZCnvQMy/Ujv9m9cBYMLNZMOagtA7KxfTHaZbLeOKMfesbcdmo7v3IdlZTUSvWklI+aokmv46xw19K25ahTC21EmqYSwgZEthiFgjVwAKiooyTop5dheOy67V5iF3vX2/C70DZZx1gNRrp7tPwd7z0mZ1aW/iS8RpJ9SAvMWqeKtAVdclmmw3Xnujf+k84ENMgvLvoy6kuFIrprzlpGdvRvS7Oh7YLhGwsfYeQCvpkMKke2zTn+rQ0ewM6P5mmTZKbtv69rvvfc4hePDQ9qezKm7XBpVhF6x6P065U3flT9G+XGMm4BRny+bi+63Ekac/XXh2HC+lNdyrAaIb2uNoy5BmRldfuSFINWxTIspVpWz6t0dQ2N0DE6QBk438dm68wZWOvXLPRhlA1w6V2mOfpMYle+W9kzzHSSwfnZhVaqv0nP2J7dC7M8GYqIXoL3JCLCzMgmi0j1RO/j/XC0HQjF8KPreAYxWUhFoC1ovM+lESy4/DNgodIf9TBpBRs0fxdhz6ARhorLnylVSF4yBUfH3ZPPrEl8F6YS+HxoyU7waxF56pPajyAJ8M9sIuhATQYyW421l841LGk3Y2VRHMXtAAgqwh7vhKf5eA4OD5kGv0uow9O0TNy4lOYyuaa30WT2DA8W33NI9LY0ysd6JhWQ8kUkKM92m7b7nUqnAbEzBz0qcg9TRnT8fG7h0gAEkHMXXKt5UIvIMrHndjPDzNlnM4NbyV1i5/hcVBk4yDJSk2Es7kdjr1JROqKOyWdFl6d6MW394dtpq54qNvIqnx1HlIkPCLz6tFg+6TQ10WSQOJvC3Ez7ChHEcA3OMjqXmJNb+QRDF3dvHUtB3lrBIzpnFyy+CVMhc11TuRN+GglCI3Yt+5ZKnWG4elKtn9C01HpoUJEpCRX4L4AgBG5qgDAdXfZgcsTrMQ4hz/6gAq17GR0xrBz3qClC4pEbTnoYyWb2p7MxImTr0S+26glkdhj1PCMT7+L6HYeoh881ALLPOPSs1hQXCGcWFVeYX6Igv4F9YYf2efJlh7+G4Ve81LeUpQBsc1y28qf/W+n+P6BCW70v6AoPfHcotJffBdQhtYDoWzWgIo6ql4Q8/xOJ5G2U7jrEFwMse9Vs7O52DWy4+XaS0aGanHyKZkCQKFFJKYh6bVE+a8qc8B0yrKxlkcDeTGVXXOyRJuXqJRq5MXVBkK5umHxdt7gCC9M6BDhtW1KpU330TFmvk2NhlstWkl5z9trJod4OAxzTRdmJy8U2NJhRst+jjQoXCWoOs4oTUlD8TZFyNp2wbZKs855/E11a3HIveqnG8V9UIwXQe2vRcjD9xdff7fyvOt5wnoxjN7Yi/sB6RGOKtmjij2PCbJ0Ckr+RQWfXY5X3BaTqvVIn1UfxSbCgFEGZTA2VHtruSdRzUP4LJRmOuTwwbOodRAI8WYj6kLwaC/iLuRAkXuMz3SdFWS+uXOR8ngD4y3Jbhh18ZewvRZCBe6+cIvJePAOU0/rdIfKlRQwr2aPUDZunGR/SOM1sqeitI58krbrPXq36QhhcCbiiZmUwpqVcn90FVai5r07wGLNt7GSSaUg+6nFJUP5V9nEK5/X8E6f0fHGxokX5XroGYISDDd9jLsfpQqVPtIK/HU0zB5YjaOo1SVxo+pK4ZiABrelCFvP0B2vL8YKVX6gGJ6XZlnlvfdsDM9AykYc8VZ0QnqXNJcSLCyrOHDb5cuXS6pynlS80GWxxSKfPw4db9gKPLVh7mGWDeFsVZCOvLuflA/biaL3uBYF1wbsmxCkjf8tXbYCVt7QDNcVJfF4iqfAXELnLcxJFc6R8mnb/HBU8o3G/LPQudRr53n/1mLQUpnp20e4pcG5yW0iKQWpnfNyJz0et6ToBciUZFiWZh6v7PTpBhBKHQH0x8unB1RYZfJqARIIF54+cKdyRjIAXjEXxnN326/Yfyl4l1GThdD5z/8O3l2pSiVe0D8ofrzxG6LggxTQHgu9nXfhGM5aU0eOUaVmuls/eMrbAs+b21vKYiBF7fZjXiIIxn67Jfu2m3eOkp8rJ3SYb4/uMUtQR7YHkvVNNTe82Egwuh4rNjNMMQ1UrabtoaZwl/PbT/KWuuYNssvzgyhLxBxr3XmImwTDU9cAduAezNUaKU0jGIp2UQq6oFnISOBXzVFm/Cci5wx4lohLWy+wL946Vo65g3PVYZh/9V7eWDlZm3irGIL+zs+Kgz4Fe3Mjgsw9E0aqchu1noKKrVdy/5mhnsXiQWyqHK05ZuE+i+MuukgLgacwhujCToSUOg3qKCYWeogBKbuir5Ehyp0RT8YguKc2W4cughdHJwqI+jJc+/YnENukxlgPuVvBJI9zUHEmd72s6hN9wP8RP1sEJbL9x4XJZ1X52vHYp0/EppImJqVI5V35tbhJiW6h8RigwRBCCepNxF7CP5h6rjBa4NHfSR8o4A+MtfUtwIH2mMsaytWQX7OFhb3c3awQpzmsuEwMxtuACHGHqbM6kW/lKA3bjDrexUA5WrWctgPEcUY1BI+azbpd/la6MeuFt6y6IIlGMw0dRAFqkYSplfyd8QRb4g7SEJIzGtC7xMl+fMO5c8ploS1CqMvO1fD7R61GVcDSXgqVHgxkSPoEha7h5c7QPbj4lRayyWvDTN3+VL1H8WKHex1bmF89t8UMS46vsHPzxWgpQYrUDLejE0GBMhPqsmZRcSmnycLGMhC+biqv/PgPdU6vXx54e7t1ubG8ADxGj0Tm+o1zcPoUhZB6anKnF+EBat6ixDghtDcuDmLa7AATAagt5VrJYY6iIT9JtmFIigY7tIXVQsUGo0wvACEy16qpJRznnV3QT/tZI4O4/SA3wUHHYjSYMTL0g/3X6dC1Wy/IY7gzfMD5CSc5bL0qTVPi52ngX/x+0r4c0jDreYVO4ocRbII153uRhZnFL2MABtCXkJSnk+Rx3o7FXxBH4uaBrAgPFtu9iqNKUDXijb1ZZNeC3AhVFgv/7vV8lfkeoeXI6lSXK+sVb7MYnvSvYsRo82uhDMEI86pSkMVXGs52z02tVBDBdasfJFJwxOemUIzthTnxk3uhO0YwNQx5ZViZdbTAO7TQ3xr++s7fo4IoEKh5idlNWHj3gsGIqEbt5oUJ+SVzouFU7wSVNd3e2kulqbh5QcnNvK3QoVODKtwHnGbYu9CpIXaOkzoxFNXy8zY4UF3ed106HpHoWsK7oshXYDC740jsWMHviOZWRPm0eFFhtSMkvJH7iu6eThzFbiulDSHhBmjH9PW1XHXhMVaC3j3ROgah5oTFJVUpfFnwU1H6XBCtNKkRVNTXdI5g+qum7c5bPFRFJU8gsh8IbJnPQwmwDnqJolkZVLx0nxs5TIxlc0ieDXNcjm2tTXbRzDuaRnLkkfGveNRw5nZm76vdOzr0eOEy13sE+zp/tZvlJ4iDwQ5mO818jbZRclOjf3tKtgaDSk9CZlAfLcdN5HgC8KLIUpwZkwxZLgJjIQKog31DeOcVvVcaQTFXJpHCHVLL1gUUXuGjWZT/usfeBEgmunyZKuUoZQkssP4+wMVK+TrJtOmtS2bIh1HNCyhUBPPQH4Pxk3dmdDUEqSukPkDKO6ENW2qGeq4KqxUk6lh1BAP/BkSk7Wz2kkaei2xEMOcrgG6drdp6+oxgimcagdiMLiNIr4xWtNDrEFFaKiqvBPVNg1vheZg8zME2l8FVNJkF8cHKCctJJ0XPmu94fxat127HBeYvVfZffThRRNCT49WFG/caI5D6qaRk0mrI1J/0OfwHkwhj7euEChIoeiRnuIBHwH6gX/giN7RglUTfWTMWu2i5nZGkeiGUjJ7OFpSrLwWbUHj7pl/fY0K5n6s4U6+07CzcJFxuCygVfKwFJeiTqk3zpxRgyJm8Sz1hhSSs1CcySZNvV7qLC41LM4JekAt0nNQmlg4OK5sKr7bLzFr3r+O6CLllFPIbPLNL0R0V97ZT+g/Yjw5SDWgrX7cyE03RWTRzdfE1KQPXbrJId+mtIy9eFjXdGp2nQzEaerO9v+WlO8hQ6sYluiuVhXtcRPW/znQgweDx3AKvpIppI7QYdYGxeUUiTZ3L0fHfmY2VfXEoke6g/eOchrCY4qUrJlNp2jfNnRJwrnmguBFttLdv0Za3qeXT0YKeihdYCdBWXEyeqcjUIslsgmAZG9lsvEuDbiKKInvnzI/GNLtIBg1/YWq8T8nweJ29pLWSD4ZK0fEstkqzLgLlusnOsaRdfKdDsfxLnVcY5AwiSacCCfvTpFH7Zrs/ss5F+ZNXlSLtbuuDwxQaexy+nXVDkf1TOCvQQaGRqGTj7YgepEDY+01Xl5fd5mRe2ElFkxpyH5ejJ6Tv95HGmM0/LFOqjHDcHzrQzBSfy3qXvqque+UNqRkFFYRjLrcwezkzJKf8gGfNilijGqmo+44nmWLNE+muojFLe+kRDvN5lfhqy+Uh5CSlncwlQfNZugTb9NyTo9bkUerVuF87jT1kdIQ/ps1plOOtVUNMNiuTMvtH0MnIdt8Do3C6ZZwt9/AtYIhq/aWQXw1JgZkqNKuWEN+ZuyQJQY6sCZfyrEwDsN/49EE5OKGSjdQCx2nB0VAjUaMfobFsB23BOWkJNZHEsoNsNzfWJly4/7zhjIHWJj7cAgEilfmf9do4HQ50Z+slK/QIZaPvRaiGulTi1/VmihWMZ+TQVEKfgnlpVjI82bOzh5CtOsWLRmsIs6SMfzGL2aqM5ubtU/V83+avay/vFQwLxDsqJF5CpDOE4fVfju2NmXndFcfKq5SBHXQQ2xlg6JpW7ZmuHPEjz1ljQikEAhoILeG2m64Z5l5tzdQZ+/pTyW34Uo980A6TkR0NeJ2EcWrnujY7ZSd0pKOVQ05xpLvp4H4DzoEf7vLhaOiMO/xS5f+oOHbK7rZ7+aRz6Wyp/GtocoYIF77U5hOUGwqKM4oI9xpKkDzVMc2dko1hsX04WeJQWu9XhHxpkxOStwDMdGO+JUbgz1j/3ZfyPk42LRkxkOs44vgV8bjGaH4lmLjiHIeK7ZuWZaFaANjR9rStzV135N1T3DxaiFq/S3jyW0RzKcRTwdmhKaEserxnamnS632rgMC9TeuD80LhicuEfV08pHCDVFf9uKYSdInZFiHG5CMdsCD0g/xz/WHawRQnpBjNjgqHJgkQOWK/NzkBbIeUs4x0g9MG4XEZDFz/M9cozjeOWmiMCPo/67grhZ/wYnyn5ad7Ck0bWk1i+cmZO0vXahskfSxDi9b3+DVQrPZ4eXlPImHeF3ZgFnTNQ18YVlMRBUlZ9jfTf7BGZm+uq0WNpVDzTzXYTim4geC3uuhkffGPRZK92O9JaCMrisLLrVH1km/s1CP6gpojHdR8y2mtgpj0WVer1oqFvcO1jFQSag7ACMev9TDbAr7x/O1dOqphM2/t7CmSBxB3e5HhoY0RxVFLUoEpgfruHHzHWuXEFLM7ku4+CDQjoytX/2MiQ70iG0QOxerFgpgA3bAbv8Wfr44D7MF15E8TvXwR+zl0Icqw6AYz71xM4XeI+SPL7PZCu2pdqZ92nHDPC6XmDLBahjLlmGwxPB7zp3OBPVlPQD4Wfi05CGmui8zYwgvkZP3JMIyE7hNoJ2SetbhIdk8aCh7ecxRPAPLciTRMEVSt6lOmiqD9VuObg0QkPtpCNvVoKqkIfPxLLaYrpwbZZ5RgWGcIDB9zlQ8St0zPAlAHV7BF2Fcmeh0YI8GJ6O2dVvV8+KvWOR/7jrJfJfUdPbaolVsTcg4IzduM5hrHgDNMobpz4ZsvuYWQvACip/WgZO/AJBXnuIzFu4QWLLn+Fk1JK8cbGqUPQr1Q+CCu6q4X0P4VVIRbsmabauCKEEsEOQ+fRcbApYid6ZZpmIdfWTbVbpxw6Gc0O7kVBypwmfOiEPBWbWKYlsxUV7MOl+7XSWQtDsU0SV4WT1Qxi7xHt6vHC5mqG7quHsSBg/AQEvLLAxDNwqMsdhfNq+EYFYwh55tB6TL2eWgfXPIjDplemVX8mEoOkJswLYCG8MGQ4HX/u5RO24/kLKnsw5l0cgSRvL2rPmd3tcLqSYgUSnE/o+7M+VedCd6aMR4ULIkNjaGBJFQYhQAjQigpK0QlitVfByVIVlJBpMXfU13TfHJCmgC3dvLr4OEdxre+CIntfjoNUiPGnafjynXdIcAy8OBEV8WBIoSt84vcKqwyv2i8kSWNZaMbgj0hHo8IRJuoD0rKcNx9y5cS1shQ9uXcxI2kFYBt9lbhm+hX3DCeLD/f9glJEkeSWuv5slbnU/KU+QVJj1vpim1zPaZgD9HRFZcO7pxfc/s92nYIqjiwUoKxyGTOZAd+s2VMCyCXzX4e7fUr+h8TwcEKwtMqcw/2ahFfHw+DgFWy3sPDrL8TZUN7DeGterjFMDSFAlmjdG00usYMS9ugCuCYtgJWCp1eTGgwPWWAOmTSqjQHPqeHG7V2CtX+7uZGeOUQPKcvIPR+h2hGBl+Uw3lNIFYt1kcqNP8/nY7ZMdq7LrEz2iZN8UzCpz99iSqMoW+FXuqJ6zTcSNDrMvnKZWetfuIQGSX0qTrdQajsGDoqeCetYcH83lRbbc9rBxRXOSmFRCYBWu7uOflm5QWNRzH0v8ztJLFYBoPyl/6pV//qcKA26kN3jdwR6nDiIcS0lIKJFuY0fdLvXiVBkiS6KwY6sKuNWFdX36F2kh24fQNOe2r+xVMkcBdUxweSeCRkfJVcyzDTpNDPe66mXvdqh7XPCrpBpyWWRAKBITtARgI/Sz8kCjYV1/7/RNgqSvg5wsEyequfmEdCUNqwjYJDIxpADuJx9Oo67uzbe5WXsRbC86BUbhUNbnNCLAFRrKEAud8q7FHUAKo3dViHHItgsoLmgAThoB0DaQsJq6vyLtO7Th7LFac9CY3ba9H+z9Bo1D1xT3ZMaYFxJSKhUdJJK0kPA7tPWKfBNYj72A6gsur5/hpbSeWNKb6M3QOaVb3CUwJnnATgPLeFoMC9m5WnQY6dL7ol/JlQ32XC2lzQuq99ubsbM8sE0QLjVpSCKHEXgwbT+ExvMmGEucSLTl/uefDOLBZtFYhULfTJjz4bse+q8nrvMH3wfuVfMRLORQfaUWYak0RLyo2b4JFYljKx1rZWNHTFpGQgd5RdOV8gzypAKPNNOkUGkcCLNWvMpVnsz/fcf+mADGevKeFrmXJhC9Ki4/dQG8oKIjD5giCS3Fug9fBwIScMpWRpsRoywTTPlqGwSjzlHwLZsHsfJMd3Xcg5yV5d0hvXKsz9LU39yNLH8aUieZbxCla07YdtBcIYWQuoKuAccijV3KhgVsditoYurhqU4VuQAWrfPJtvDIQQHFqZK38LCY3Cpp2jRjEOtLYApyqFlRcusqTt4hpMhZtETysKNONnprqNg3hm9+d6lXQZWHnB1ShStObTsbDABf0s2FIIDaY8jPuGBOTX5iIZl8HJDrfqLwtS+Mp6oAo20iBtKdJ+1uiv8QZKHh6abp86RvgSn8Kp9HbbynlpZws72W4ACGu3mIqBR6I7P1GpW4AEUnoy0UDQVY2vxte92I+scDroF92o7aKZKKn4wU2+AUwpgJf3bQ6I72AySOPfAAl2x+ZoyW7VZMaP6Ik2kqJjsM+5VvWwgudkyURv2rVmJWGfQWXLAJR1BByvAvQK05yk1Ouu7qHChxDLTRzmm65dXevRpwoj5okSL9LR50O0nhXmJiNkUPslQha8I1KezYx3U4wVfetdqFKcLhJFYtEPUuFc8ab6N0rQRunDueWTsp4dRh2M4gPCOJKCUm4nGbkpN7lz5a0kKwmluJBRTLrlp7gOwL8i87VNcgDexb25KQ3CKR4agE13HSw/Xv9LDfB5NuMXYopdC4IFThHaOTBpORK1yzuOY5gNa2nqioGl+vIKS/VbKh9b4QaZ9lP7XtwpLqCn+oSpJRwWD4XodrXg82W6os19BZB2NJOug3E/8rk3B8rVL7fLIKK3QjzB4vwDOWb4z/EI33hQIzafcCpya0ovDRgbAJtQfylZ50vkU7LQI8qb0STtMuzz9sfdu9b3WJd9L6T43e0WnBXW7k09BHZ70ygtnGPMQuuWuRpyIHTjlUIQ7tLDBK8imOuYOpq1PADA8tjhixs1DSp+RcSSrNvvADjXfS0N7wAH4rv+9rW4OO8zKe+MLxuAvaKAPhbTTfokT2lPnfpucrOV/OFQpEpc+vmtkVIyJvDJJWOQPVridX/m/mUDueiCl0FmEaLtA4LlLOR0EP8vsbCFwndgnZYHWQ1x0iKhgO7y0SrzKjHlqEqwl0/x53hLGEkQswTtzHf63ThCm18cXOVdkYmie6FGEv1rmuixSK+sdVovqUWGUHjUIRnzkcBWIxHY5WniQ7D1OTgH1KtuuvgEYyzUMPHbpa0WRnENUDYuiiXDifvpFpIV58jxyUCRMAXszr93POZbYqG/cTkJIdJsQfLXk2EPeQUELEzVv14ZSch8gdb8HUgX7DcRyknPJt9f8x5d5ePWHyh9BwGPpaBNoODwOlQSrLXJHVki1GkDlGp3F+TxLaRjyjbluFzZgoU0PQWjV86OszQB0dg7CUST/sroMZvPIfc26NYS0dRh3kDkALh9O2i8g4Oc6dpx8Ud0ttXnANtcp2strJ5vse5yj3sarzuMolmBMn1wXhZ5tYcDAhboZ9/pe1TFrSGP58clbiLB0S4jD8iFkJVQRUbeDZew7M10Jo7mRWS6y4YqR3qUauyc4zOr/M2vVmzTn192QYhjD+SkYxI7ipwXmTQwusrJYxjHUKp1BIwucFKBqLbpij++8Nzha+qM6EhJymy/yTgZ75Pt5L28r88XwOv1vzFbaQHjVWmiZ5RQLJTwJmRLSOjq9ICpFx3dtXtD0QVtnG5e9O7w9swv6EIWHvcsRuIz5J01wsn63DGs1KU8zXvC2ipFnzuSMf8BbLFYpu5413FdurMClC+FrrZOnvd5x/6N0fFJ6i6HkHZdjDMt2fY8Z1AAkexmM0UGqugUZSu8Z+D/m3UiFS2Hv0U/iEYLKkgOmnFNSlaw323CRU+ilBHpnUUD8p9SYqtGIPb6ZZy3CEJZd03wRdegdRnnkKQvCDuaz5jPJoQxIMwfOECA9sDSeUHNeUpY3nz4fuIg4yydRNUEUaWCwGo6DjjBQ0kMkdgWRWOHJ1tkwE2TDginCP/bllVb84HeJhI+pC0+XXbtjmG4Di2ZDNvTetPZN4sTE71ESogJffYa5nSbEwPHE13xlZzm1m3qp6EyGOuCyOSpjgm3RXqtnuB1lKvRf6Sa+gfsKBp6ah9+eSEO7p/z0CqNzxQxGeKIBjfJAX9b8TbbBrnIZOgwwm43xWfCKzExWMaQWOJqWs/Xksf19rHr4ghzJSkn0QctNaA8MLEtYvvKp13P6AuVSm/kx+/ljsymJsTvHx28KfxnuzqOkFkgdd+eI2ye+C9F6e1UgW6ZPghJqjkPBu75YVR7o//ASqB4oHtiNDaDiXyv1KfNwLyxBR0/j//hRY2aZ5iGYn48mliOxREl40B9YXy3AngqPqiuIRn4kGngAyWn1e1iwi9pCa1SInb2CdxLdpMQa4X6YnM2sMfQqk/M4YpuQsqDBBeF+PsIzah1h15uQGjAEqwvGGqmEQ9sB/Z6Zm7pTBVRDRgfxNn3lcjegW0RLhw2wSnpEy2lI6GlDHtE2q28+oRYuMoKnI455rWqk+5LTg9iniOKgcGp9Bk7HThf4D/djVYsGM4yNtpAno1m4b39sJEr3YCSvPA1vKUnLvTO316BrFPGmDJygIhZQnfvJNosrjSZ4W+LncQ46KhNgZUlPkO8l09MDF6LGbg3JSsup0IUYYJqDh9mAC7zKv5mikfbAYg4vvS+HGpw9u4a9Sjd/722Fk+8Wne+bEOZNIvqvc5ukb71sJPDAHWB/06DeSNQ2ZcTF2VStu65q9tl+d4sdcdh5VjKysAYcELUect1T5aDjHVuEBYGf5TD8UIkkOnNzzUFcoocEvfcvrfu8d5arG4BjxfhKfp8uVa96opMRVOSanuwJ3v4/YQ5lEqKSnxd5zO07T2G3HQoUsP9gO7qpsws4lAQ/cS8WGznft7ZBmC8rhQUA4EDEblBjl4m6aszK1GN4BBNRasjOM+ooxLTVseZvJPn6M4Jmg09bzJ+zKo3/cq96nhOem/7iv1FqU1079lLbA4NHWbkQyd2d9fgCI9+wPupK428kqK1McYdz1hdwrIUtKvQMK21zWEdwY1w6BzxW8XT33b5ZYzMw0Wzp7XAmHz+eKPw8X9kTuWwKy66t7VU9b5qmOQdHNQEJ6R4QobsSqPM+jl1X2yF55Z/Lycvlcnl+1ALfPJdR3XIBPH/OgcbAJaCcJIT7RhKJV7mI6WtchdizKlo90hHeEX58TW0Mcy+jMwUNF5cJiyE9XcDqt0tDNC2KBXmo53H9R6JdzadDzmeB1u1RGCF8hDN2kNOPe5aVpDN00Ea2H5j7hJdwdsEpszA01TAze8GmMZCDmn6K+JQsPGUrUq5d2Awvv49crFIgwkT3VYuvCy1hOfDezVLyFhoQa9vQFTtBOdxgC0B02PdYBRSmaKZxCuNbJJ5nOo1ExNXYcQWQEEjfNEcCo/Ssx9ElYlq6DZntIHiRRHF4f3XFL/MUAn9jeivpm7X7z5n8RiO7maWj1lWQCBqbO0W1+RNXfGbVzocWE9ZDJksp6N3BrR14zzdN7D3C+Bb4qVlCHxWBQTvSQII9v4NZG2YujnH42wN/tIXeHM0kJbbQaFNl7zwk6P7QNKkIkqBkdbqTHpXEplvb18kKfZYbwbsiwkzaWBqO6DNMoePqOj5VgSjF74u5cn9kFsJjD5P8Ymywh82Ulhcd+EBhcRccjUgp3boEDSVc/nm586u+BkugXiOU/il3pDBGADsOqW0qj4G5N1iM3RHlxdZUDb1X9s+bRu24rnt6heHC/5eeNpxxhHzVnJMl5OxSBb5jQoUZiAw/P0m3JfpKnD5xbFGg9P3fGiSXjFTg+F02QkUP1OrTwmAPG+ofKpasUNI/uhmTvlhnd7GXw2HAmqzB6tV8PhNsGCTavZvMwil73BSOxte5MWpPZXFd0e2EK6pXiJ2x0TbuRCgDnc1rSBzcxxrUB/xjv19ve6yZJdDJ76/GhkH9Hf4659gK7aKT7PZ62TE8hRziO94+OtBB9m2lKYyaT2S/A9SjM0Kdoj1GOXG+XtcKs+JySY9tPTzMJbpL7e3N7MKcyb31dStynyzSjLLeYPmEmpw4rRPxeNxgQ+ZbSWJbKtxy9jkjffM8QTCJ/LBoOC1oqsqczP3ifEqh/88AUHOfz+lsTrHUP0eDw3886nP9K43qpz+doDz/iHS/rv4CPI0MuChYC4eQDV6a97W3C1bNZ4nawJ6SQYO+PQ457paji70zFidQrYHqa9bS/hq9VF2aCqrIhyzKrOhhiHX7BSrZvNS1wgGL3I7rKXK8I/uj/k2cxol6BUMvbSIh1v2vITb0VZFzrAPfXdOdt9TZM9FJVFRkgiEVdBZlxoUA0HeJoRX5GhUtsGBS8fRi79XgOh+FJQFfWHiBb4T2VBDJr3hp76OjwQ2IuyKUtKrRUgz9V+LAZzur5mJGDHyggaR49e6ESm0cAyEbaRRYIaQQ4+SOxoFcwQfMvUz7JrGaV7v+0jecUdr44qRlEvX4ombYiYn3BgyZEZFon3+wbB2JmRk1Yo5nAMC4PVt2nvARjhS7vgoj3TicWsQsb2QjwXyaDwJrUb0cs7MBe1BLjfGWVj4JmLA9hwvb2BSOi6BSgF/jt1ZZ8S2cC6kL+qJFfbsyW8szoG/m6uQmFTKXV1RBL+icmKsV1NRLD3VOIX25D3LsD65GZGTahOKCsV2LNHHW9Zy7vuAK5vvQV9EVO3tB/FB7wuW1maHNOqKL21RfOwDN6DaprIsWn3t04TqMeqIvwHQvJ086KDefNQBmCwngBF2Jsr+9kuWlx4CDyvV6PV8tUf2ywsNV13yGG1H5qOSqcYhqemfOvUIPRh1IMBsoTcuJyBcDpH1/b0Xc/KaWp9mBrK8hAI8MlsyrPX1P2mQHM+OgnhA4xXJp7kD3WbAyBHBUkOL4eqTAKlyOp8EH2bV/8ec7+At2aORy/xUKwsz0LHxXnehkCrVCOnGTRo+Y2WY1Ep3uIErOQsMraA6kGZItxWMLHZzs3EJHryZtUbhRUNsB96WdCD6yj/HYytv5EeEhUn5hZXaQbotKy8/4izQJ4pWoFhcpvZgAV5pvxU6uA0bD0dZaLqwzWStNPK1W5qPhkiknA0E+Tqa0USn15aWwseqg76rjw5c3/VuiLa8xYtHOuTVjOEfWk6hcogStERykcLTR/rCxLxInlo3STwBXXu1CxqfBIZy4lGDhNMwUUkcObnF5maDSYIfThveYsFky+TzmziFTpVqFcz+VRor0LGhTGCHSjLWtZ01viFI7X63o5kbK6Vy2cDC349F6PIUCr+aMmFRduxzRaEgJZyMYn8DltX64nLbyjBWWmxfuXqmrfy6X0SBiA2/0zngtpBN8G8elfVEOz2T4KCL5FbBt9eWurPKK5jtzUy/nFtWCvYbuVGEfjLpIjeCNDQAs9wXvLkxLuVCeM/3G3WaHVJWcxiPAEj2ekqK8awoNlRcfbtuOH8EXJCoQGYmxV4b7ApjLjI3r0e+W61fZHozZoyeImOcH2T2JjK0NypvfPzxbjKZwq262apJsi1no7AWaMdsDeLgV26c+uKwPOrxs9T7DnlbEFCzjVhwGMnsCxcDtVk9gbJdQqz5GAno+YOuDiZbA5RmOtQHY5qRlOqNnYbz/puSzu3otKT9f9YttNQH0bQPzAF3iCnBG8iH8AGgbML57mrWEKMu4PUzG1cwn1te2OWm1F7Uw8QJEjSlF1L4aeDqC6tl5L1tXKN02CiV02QT9O5NaEKZGI/NZK2tORlLTLSNZBYIodr5as43ag5HevTzd89QLg+Mdt2AWRNiX4weA7jqz+64PQX2PNgl1STMvT3ApihsrCrpqC8OrTVQel1IJhl42pYcRHiCuR41Lh4JQNFHnu6m4DLW1DelFA2du1TuU043kvem0LGd8sjKwOl8S1OsgPeV5UaQT9UfQdiH1P3d+gsWe9/hR3r9+tt8RFOcT9MAgefaJ3msb9hYQc/LU8yeVDunbZNf4KTq3cncBPtwtENesixqx6b0GPpQDa8WJYvupUJW+dG5MgOGPPcKxQryPk0ySTgnXXNgXbw63NC8J6ZHVcUgkCJnZ2zsZSxl/GuDfetY+CoGKyj9K7O78ESTuXQPzBhvq4RKfThFEm5verfMZOvU+l+4mQVEwdfdm0kFnHty+vnbfih7NSbwJAdKxwHODIMqykt8b7tvqGsf/q8a3YiJ1eOC3Hl+nzz1a5L4oDsanUiR+lf+dGsICfvp/GAAsws2h/vKZ7BkNxBEv0OcD6VcvKQnQg6Nhkl9caamh9JHoLKSgOrEpDGiwJVP7kJAUQA41eCd37rmRD7/KUwIf5cdyCLn6lheVyOPGGItlgBOAxhIsoHJm3J3rae4wlYvn2jkxrQxtD9CE3XqOU6+OfzplicWMxzPWz7JDF2AICfcEZ9UqpNOFcYx2/LpPQc4KTBTx3vdxUTmvsZYCx+rm+jCrJ32b3SfhKQXRCFXqoYiHoCxO2pVEjzZAQ/RoDENyuPuD2GJ4SSn+fJXpjq/vIlYWO2VrmjxHeqQei864YsRItRYsupG1InH8Y7pkBUfggOrzTJbkq/igyylecTvAWd6CmStw9YX90fXbLuM/c1K6ZY+SIUnzfugmErK6wXHgbiHxBicsSey4dpj2uY0vIHNLwFC3Lj9F2+EKD9fYb4HGDWY8R4oaL8kOmExDZLHjz5nxsQ6SAN+ZeZ6qdzLPKmL4EjJvVRRYFgpjxZFbO3jhfBBuBIFyD7TBF+bX3REG7H9zZIv/nJ0JOqKmTLUn2sbLAuqFJym+VfyqtDlAHtlphFynPJ9Knv+enYcRO54QPhWQP4+oUXd6GoUN5ydkIbF0msXxQ6gyrHhOG23rzt9QuZoZA/MQyBEpxdrR8/suVG+DPq2vXctbiVU0kgFyfM+2DkMki1xBb3AWQV/RxDz/a3WOZOrHChI9bJcxx/n08KfekCcqz8xpR+aDYq7PgBw6G3J/1xXVGoN2rfrZMQSf34hJcLiay0+CUpyhxHjD7X/1z4o9droHm2oGCkP4j2FZVRPTKeutJaN43It6CUZu60OUGSFZ9ZXH61P6qO3YsV3+c/V3azd7SOx6tQes+IIVaEf8HTXSWK2G0G5iupPfZ9/odTHF/yNjfVgJPE/Ex007Sr6qe02HDLFOkiCu+k4ZXEIuxsHBfvraB5JOCD6kg0Fic6KDtTKWaKA/6VuskfRE/6Dcr7Ed4PE5cxIgv9tTl9CDhqtitheEkc1Hfb9KmQqSIXrDFBVSAs2X5gnt809aWLh8CtHoZ7e3hLQGOykOLSbNK+HqQzIvMk+kvcyJlpWnwqzGDL2ios09eKGTeRzwIqKj869650o/XU9GpURbwMA+MzZAFPbBF1soTIhUK1UDSFher0ZoEqTeBzNfDZdIPT1I+TSun5aB2GAk5ovrhs4hsNTsyk+kWK/Yz2c/r1xygk2yyhslywAzl/NRMtQohpkXYwY+RizGiJUvNOyc+N5D9LpnSV0Zlhr9LxsrKmhBiTiFo1prxMn5ZDQGdLRpEC/mBd861sqokZlYNZxheU/5nXGnhcUdudTdRL9wqA0FOJ3Vs24RY0/0aCQMFLq9kbua+iEThQrxOwqNcZ9ZUXQq1qYWu3KLzceLD9dztSOd1+mL6XCr8InP7j07RvrZzwpyvH60hpWLu3M3B3wJoq3lPirfXXhHi+1h9699Z9/UEFejCzzGPuqd9RVacuJZmZM7nRFW8nil0Yy9qA52nmKz3q6m6wL6NQRrPa3Gnq3xG5iWvSRpm2sgMA/FMdrojKQpFOYBbaF3o4lb1IuWnjCXpSAxzcjh989qnyxQ3QQNVubD93l4JrUGqmKRH2cq3JRg1JUe2Szx7bkWkIouIZZmsJkRwSTQUbzSp7NLcmK6gAlY5NEqd2FCeacyhUDnCtpSIWF9G7xgFavrjHKim06mzVJqVVUFQDhw/7kD1nPp62pe/CLJdz+1MCfyeuNJIG4jOYjC/O5Hxj4q1Foh5uPInDsHaPQYOOgedTwChJdhQT8N/xI/bQLkz4CFFEottaJk+D0rnCsYvGK8I5sKtgmWVN9FceHOO7Tbti+OEbW/skVeEJpjPgw7UQS/zJuJxtPiV2Rk6VQ9i0akA63UE2VW6Sma9oGy+zD0TpQudrAybJWUw+uTZXykcrEhxCffUc7rXZ9md84/w7jKZVqDLLRqzdjzeZbtPNMnXFEzcddqGfzHx1inLVxktj95i5K+I4SarY8nYDhtgrTcBiz4fEuTmAQscqrdCMxvKC2Vf/OTr7M/dZQtGLHGdajvwrqZSd/kugQZhrPU7DrspTo/Bwi/6LV2OM6OXXq1VFnDbaEEKA9SZtd5EFtzySHmVD0JB6jChBAOO68Zn2JXkm2IRtTGdtazZqOG1aCxMaR2sRaXazG2jZoMteeeJY5x0CKbKS9cmEjDpkyDi1lDRrT8DOism7agktDqf0GNRbUtiD2TymwJJW4FEpRiv0xeT1ui1fJR3xI0peHu68Kz9YMthmkTAslEx1mWekGBPKpBudh+04H/vSFkvA5dm5QiYoLNDbKaX7ZWW5u/FsXAl9HbqaIwNdPWS5mOjkCL798Lja+F2oArhqxlPX59w6MHJMpmlgFLsrnYKDki4OdgqWjgJz20eL3wuLn0VQM25j5PrUMmwBjxV2lVPRH036gzEE/aa1+XA7SnDrUtOLkxV8FX24tnTU5UVtTD8VgCEsu6MuT8Ok6y8LsfeY67Loo7vo/616oyLjJU6Lqt32xNxg250MqfgsF5AXNEywO9Y5c8z+GdOaxYZZgxXWHO1HAXlJ0FInKSzDstoQBxlX/YLzK9XjTM7vE/5zzrVSNNP3hQlajNhN+9gHlNhPHvgn6br6aSCFmoH2joIAzXV7DlqhHDzLC/F3fr6UiIX6CkvznX4vAKX0t8Gmd1diBlJ3cy+7hcSyW+QQOjoOfYWhfrmYFmtbVWL5JfCWRxq5Foy5N9Y6WB9IWMbdPM204j3QgV3mOrvivdG4iTm8byFK9UU3oYcwmHkVj3FNkdUsOms11JEpJwkMMOrgCmWVEdTSn339XYxwT1qavCToZGJSljeFIDfglBJqOp2+eTvnY7QC/iKAWfa4ylA8fLikFQ+5bk1mQ4qAbAu3gL7ciIZKvHimhCEARSUik63/ZMPqME66+BrOlg7QrPqHQu076ls7gxAzKejUaT16y1XWv6zszCtXYSFo3nRnlhxlIlHqHEqzB5ipI+BsMDl6UPlzq7TZArWI4Y6hRLeCwxT5/itfEpIwhTLUauta04pJHOEEXhgWH08ima7Vm8T8CLjLOBujjeeNtanUfKu1XU6jpyZpmWxR4Sze3UYVFSocDCSqlvgauqCG3TWok4Km3MDScG4yXNdRsFKDEMuQ+/Vg7oxX2sVCdzd4h++3ZChgpSqVy6gBCQvTdX8F+/LSYh0IArN+t+x10BHYOIAqYCLRFepq6CMzMyix5dGz6M9AyIDeImPPCITLMuF68qt/FNsYOyzZGd93BjrHi51MSLutrfukF0OVcY3x70cinvlZXsBNIEuZVhJMqG8xtqPxEAQECWcNBQ3N9QIiaZXuXkyCZX5Pn5Z97T5OAIZe+uH3LrjkFF6KUIyZPi6GEN9juz83XV0X9xAfaRXS147pnPLW7tTIfQ6l4IQMFbhKnTuVBF1tii/iqEkKMx8owB04bW2de6KQ5wft9R0a1Q/JRH0oByR3spTWWQLfE1hIyts20vXJb0Ei9GHxiUZqejX9SJ4yNxJJ5axgtDjKIGEmdYjApQnCycggJCb/7jkwk1A4l8KaLslq7CokIUcHR6ymBhGV0LyvAwXNEeaToqGsrMDJhNKaw/Vy7IeUEsdSSS7KsupGwvZQS0lo/ob/mahSd+dFbsGUUGIYp+VxF5Edt0hhjej+9QaJczAL/dYuB7A2y2c7F0Zq9pBw2xkk184XEyC04mAXVzu8dqAF7Kgo4TLpIGVb5k28hm/+9CIjdMqii/4HYXwGOPMvk4jDTicRcYG4N8AT0BRmJgPbuHvygghnHRWorYZp/tc9bZaBACDG6+Q2OvCjD2YWMCaWAX/T9LNyi5MT8nPrir/ATypRc9Y0iybpoaZaRUCu2+QxsdSG9pJX8Kyfe5ZpSKj0iKMDbjXuG5+qwEJt7PsAPO/HlB7PjLOx29L1Y+LJLJBLHEEoJo4jYcwTud1690SX/x6l+O1o5G5TkqzkGMrtbIaI6FclJW916SD29pn4PF+BHrRiiCBtkOLa0zvPHfT+36YCI4QRUk4XP7GYFONMWI8YR/lorHoh6MWend3MeuSytHcZI4pVBWhfjmSzRCnpsMFujPdRc1FmDbeyudhSBtrUfA6MyCIwU9PVGSFIPhr7qNdmeYB5ggTlYwxgsKQPVjS4DrHN55sazZfWqIVwy3YhVrJoMjDyldsa7Rk49z9L4E4rNdhGaNCh/eTiOF+cn8w14xqDZ4j/e7podhDs2446yGq4+SRWcCypLPiQW2ixCxE6Z/nf9BOp+CyunHxBuOLH4vgFa64lBV3g9mEeibuhzhNRqDknuqZVz9AlD/kbk2h61Z0ZxuzRA2EzIbN+o9b18dXGhZ2lQdzFr4udzCjdZoyjkjB4G74fM9xXvR3ExqV95uqNew8INCZnOWjlFmQTWP0iSBTA7QKz/7sUa7H10zNlysCuY1H3/kaBLq2uA32BuCkCOZqfEyPN92UuYiEOr7eGpD8V2OtkkOo9UJK7SxyoZnxaNfOISm6P1gvannXMGC6E+qyNNjCGkgSZ/qcUroxSY/ndjo2zF1LJoKsS9WNLLowTcttBPDxC4m+5HaqKVg8YfDO0OOm1fllywN1ONVwIgvex2tl7gg1irojHNEZ10TTVnYl9wmevuD0g4tdVR/FfMCsN0rRxMzP4IKrumv73YR3ySHD2xEw2DCl3ucuUYSEC6pMIxefj7I1fKtx6+Q8selgzLLM9tKOvg2HqJiROs6oey3EXHP4SIVEtjx9SzD9lm+TqS+NJhAYTo6nXvLn8k8dC+laM1JJ6FNApV0KUylfpkHr/uVHI2yAB6tt97ON70c5lbkeuYdODodUULCZTZMX9hay+2Dg/8knOtPcLnVyM0V1bVAjaVazNvSF1F9FD8TxPr1OzqZTKV1CE03DWeNqf1Ar7T5Vy+ObfCvoVjLEv5ADFkJJI+gp7ndA4gJ5bcj7yiAPQpA7kLB2H3TcjhKZ2xStoI0pbcBpO9I22DfNtZ9eIOTJKj+McNk53IcptOQDqtVFx339buW+Ek8ahwyapE7zPktwNgN1hdVPXUDvanHjz2EDPs5B3npigQfrXMHTxY1rXylkFxznEYeAwO2QMWM+R4xH/rNi3mOR0MgpbZcPPUIA5E+kQFyHt6PAOAhN8v8dgMPEMjtMAg7eebcdBKWuQEbPbPv9TsMfYGIQiSbkPOWzWJ7I2q8Cbw/bPc6c/t1evFCtT3WcaCqTf4WUinuvvRPb5WJLgkqR2AlFDvetvTHptnmXkPUwE3fdZ0o57bdE+d7MW/o9lez92KcyrAqpPIE1wsGoSH3ZiZ7yoiIn/NDssfdjtbrsDr34ZLA3DuoPK7lNFMjmzMKO/KlYROh7tKq5sGwv92l85uHqN8JNzg4/fWFX/XP6JMc0BvXtH1kmRmXO4pTd2Efw1xbdp+jNaiFjRIvM+llpfWrcs18dKUj1ul421afnMBLFKK4eWdks8sKKOU+RpNhLHrNCsNno7ZGWMOL++KQ/JNtUAOfJs2eUEtRe8g35uPJEZvwRNfZPHKQVrA54tWDG43P7SqsKtdFiN0Juth4tMWZBeFPWypV48aU+fGXjH++hB1STz/yQrJB2BeAs/GV9KC+PTNJFLUn4PbkZ7mwYSP0O4dzaj5pIMqCsJIoVUjyW1bIJBEXs1SvQAFK1ddcwD56QYSdkNy95GTSji55hvU7AvWXpzIQ/VY+UwNhcUnTZ5XjeQJWD1aFrYMQwgz2JjEscO4bTLWWOD5mQuWNsWE7emNvcNcBZ5NpdsJNEQadkVPvht6FGzvnmwtK0KuFauZ8KdMb5slKixeTpybaf3AQA3TK4I6t0PVvQS+4pNfF16C9qxD7nRopHWkm7SKYaGvvzb7hsh7NXsDVvQ+vajSI6b7Skzs4in/4sQdQcZ6BmX56eiO+FfZ7DHYHIUSPfLAiHAj627hHsgWKlh8MkX4H6SocCVCHBhzMIKIjA88rgNoI0EFmpy+EoWkQkWJw++iKcuA8/Hx4U0h3IsIgSrQBbK63IzpH2NYVYPUgNdTjPmhiehjshKy26NMbUfjiQm2NHrOTPqwo/4hxyLJ3gs6iCwIlg7FPBJU9IMYU86fzIKzHSVopXkxfaHBV+Ol3GzdeB1N/02qC6JMye898tX2G/Ylild+NiQ7GUjowsI6Y3B/uNcWD5M932/4rf3VB8jTgvqfJ0pqFZvYaticKo18wbli8KacCnM6V7jlp9WGx5MYc0ubruLKIWQqrt8nZ5wleHOVr6GWT9F1hYtQ3XyN61wIDWVJNC6x2X6TVn6xR7ZKqCb4C7wazpY2Nw3uYmCgnlDrluqcyk5y4/eYVO6oop/MvDSbRKGNYg6P8ve/Uzomeb/UWOu4jnKw8e5bA71ir2UOsRiypUga5SaQP9ZObZaF/RUYwY9dXoZ8TorkJxbPzPXK8YDoN7V6EtBGpj3eyoGOM7BF+bHWT/4PASkI2cC6rLK0HwaChYTpHeSvQAqvBQF2jhg8PpeoVE8f8r1hE1hl7xT+vIJcP8XOE+srp49794TjnWrX8JMdf8PQfgFmk/K2QHHUveIfeZkvTJXUHdYlT2hg/2LrXr7igntg2ffspSvXDb4KPiTdxY/H9NxrW235dkh9QXchAGuIiQq7WZn1pgdt/fwRyH4K+V3xzQlcj2QQV2g1QKdJ7bFwVo578qcGJDmntpLncv0OKiL0lBgLCCC+FJWdgZN1nK1gotjrT96xclH5sPad29JEP+aEb6vNNZK7uP7a1tWBnT2N5VejBWpMLanPKQIyxkdYN71oX+7JyuzCvjGGQZj8pelqI8kJCZx2JKqyPYDmi4TDuWol29qVInFT2AVWyA0fBGKAPo3JNaHB6Htd1nQKX7m/p9PuMVDQ83B7enTeL61dQArQJ1OZ7wwga2QwrUN42pJrTW2EqwjvNvR3h9tZIGu/La0cNh4Dfd6TR4hNsrs1+s5nFp1TgpQ2FbO19wnxFqbQsRodDQws0KS7Nf+pZPtg8CGe/zTWG5exJ9tGBDqr5cScEtfg4tFxTnpv8wXDCen08K4MSj98LoP4qaFbURaWvEnfd1fdbuFnBH1zvH4gIY8xRa4YqRdp6Pp9dYHyn5RRgnsKlCQBrWFZP+8lY5RPGc+/vtAYI/G+3MkddHbqgyjO3KO3z/ka7GFXmrS1U9H09CAkm03hAfxJRK+Z5m/GLMLwHgsnog4q+y3miAsDGArrLz5f7KqcHquW8guK6QFexkPpoligfLFd/9q3Z+5fVHv3xdNfGYbEKmmlZngPNFZ7Dr0/jh57BQSh6j7ZO2YBgrJf7HMiOrR7Kxf55NIPJrbKWHuWBWN8ZuVQRXHw/tAsRGyFc/iTu+TGsijHNkS9GIde47ij3AiVK+ZhJMgB0AzeUKur/LPaTtbZv0HhX7nZ8j8ixXYQpgzilU0XT31WADosj9gfb2KeiVTM+nxNV0OlSal+rkwKjmR/eKyVUkCbZrAX4udlMsUWBw9YxtrYcTUmiNUVSv7c0xpKSDE2JaHYK0ZERag5+JBf92N8kqeo+CmXHckTlePpJeCfHRcIOjHqfRusMIn7pIqwN7psYYTzoXMaOz0A7WPWbh7PUK1C+sDtPaC+iHgdCCrrdwWSbGG+FbTm7i/5QwKo6ZLpFiTHRm1VIT2nW6bePRhRZH1DwhE75bnVH5vzDfIqSj+4/XiSJYPlxpVJKYjR4SUmjpmjqK3+fLyxmgl1DvyYu1UewFCzUEVIDme8cDcHkFZBOK2EP7HCDmLMdbW1TS5nuB8ckh6UaisrzMdhrfZpgaPZ6wrG8aZxsFV2/b/aw7rhMqio3ylHpnL7nvWjdyW+ysmIE67stMuI5oDtFr0LUNBE+qvoZEoTgTih+NJlU/9OFCYAAkmysex58KYZXhSyLx+U42zyabYLq/A43Ccbp7xeFcgalPIiq1Qij7UNe1NdP7yECoRjvORx5/oWVS3JxjoIFkiY8yciK+xMj72hhxZ89uijdpa+zf65Paet5x/w2ejXG8HKlARCCsVgP4aQGWIo/RQr3EDToxpXIzHtbYl2004a4s1mkLTXMUb3yHpxXi81AhtqSce3NA7SE5gjx9gsWAyoDHmaEVIcofKnFh4uYSOjjLoHhoLCTjj7FQeddYDUXR9FTSplukb8BfhrcFQ2B3d6QjGI8I0Pv2TBsRAAtqDdyWUGhfwZNkqIfcahDN1EKACX9bePhEsjF/gcjpZlG1bJ0QtPDMKW9nvMMV9nQ708H/ZtFmpxoJ0QfBAbpoPrPqzS70HS7nRgJWIMiodSooUxiJX6bnJWscHdrdKIChUeNp2Je+obZdROKS0g5O6muCM/W4LHQzBCHsecDBiqPCcyCQVNyJWTQLCRFkBj0GLBKXDvt30NV9MP2rWFOjCcW0ZFiV8aLylzKtRQBXZMSZECseNL6zfS4btQfqAyXar0CdGpK9v+ZWKhKfBtAgRNB+3TpqPuWzjskrjtqly1Rp/DIP3jVwMHHXDmaTkmnvre0tgy3B0ytnPUOMEoCo+e5gyw7U+9XUvyeo2lzSYfd64DHyiULrJL08NpjdC3n4igV3N4QDCrELA9YDUfkemYk6vnrJscPqTV6l8aOF4aJANZKDPeXBqz+rN1MOBzuXLdilSLWx6V2zDQsiCUfoVixvq6P7YQEtgbqXHnJkvylci0XWCcOUvHLzhqnn83NrNTBBMSFD4JQt09mxDmsgALQMVgK3J/FIrgD3WMro8ajQda8gK2SClWpIglzCq5+VwmLtInRhFEx40rCS5Ne1dqE5GStAwfNOL23MeV64BcNj4dT33h1+KpPs/0uinqLzVthe0PQX6vdfE+Z9sgj4Oe3aUb68YW5VZ0N4Z2j4ODsvJzqPaBGkBB7AOKbQ0bK0GPVafGiyZRVT/GeMssiylAqMGKwZi8aFUahFXPdWQQWqmoOxPwHO/DTHPMTkGQx8fQjdcRYvc5iAA97ocS/VHzxieM4kcP9NND3v1nRKoozaBpIYyunTDmF6YFPHksFLwGpIMccli9qoTuLsr33X6ML8eS85gUNSsLnkkw/2TR6FeigDSGWC3Vv2iOKJ9Gw0SJmyCcLBV5drIeA/exC/lvbM/eIDo5xtSt2lN1NDxhptoqgDrNNbrpYZYtKBtDaK+fdUbrrkhpEmwHsoN6JuFQXFYNnSbKKSzseQZDbMcTDJdz0CETElQMiwDY5NtFrse7+wn+K8tzWHW2P/kD2toguoy2Vmc4fY8s66/btGZbE6Q3CAfZj/373cQy5LUfqdBsr5LWvcIiqWsTCQymqeVk7y6yE497RsPuj9Ke8yy+k+zrK+q1prxQbOhuVdwU0XFhYWsyMQDh53EcUx6zurWQyjbfqWEfz6U43qpnC4r+AY7RP0ZUUDbvlsUrLRAPZuglhQZN8fF6GPuXJf97zeziKqY3p/fD0mczlcNm8vKJhnZPkKclFaz5c2/7y/NKDRrxjcOQaXcrjaNtWUSMdRQKTnCcxOhPeV7n6zLNTtSUkfkGkrD75DZ57wV7S2IvobJ1Qi4IBwXsmmXpm+QjXpjfnE3y/oglBDfzzS+D1JUyGgC3dLEuUSCY1fwZeb7p+IMSMgA31J8/KOSp9MSg8eNxo52Z1juoldZ/Z74HIuRm/BmoTKnfBFLcJPXOm9amHSJ9ZG7xYHgn66M+C7LTMbWyrWLa6q6HV0jkqLT3vVYhNtkAD3z+3Gv0BuNimcHro5DST5MpnVjSxwjiNbVfRPBEU2DzmpPKuX+QCOGSOJZnDMi0wBNDoF8U+GrvK8TTPkaD+lVuYVfE5rIUi+Ga0oSnv3X2YEZFBtmm4jeUbvMT651u7Uhnj5K7bux4pBdruSQxoHEf6zYHWD2lo8h4FlD2HXLnsqFXbgNdL9UKm7i2UO9Bji61OcZh/MnBFR4k87MXw1N1P3OEFUCzG1GlL4T4a6Zl52AgyJruACfyTkNkEy1ZX6E73kL5fZkNiotiUneCMXcQpFMLYd1j8TnIHiATcm5w/Bc1ZILUHjede229+WbAK4zZjKO+6BCJzk45f9HhsdXqLAinPj2ASOEukNIX8SIzzBan7txgSsA/UAZ70KbqX5uU9VtQmgUPEU9QgU8i/Anbf1kDfvsUkGfqUDfCmIuAHjQuMzGu0tj734MlHeaxvqHSiwxfLbU3MJJsXXb6OmAxamqpKdF36vRCvt1AqiBV3ugup0cxS4/WZPTEr7XXDpUwBB1Hz5uXaf/pDfhjluIctZ6nCZa/mY/Bpt7xNtRXVJBfj5aY7svF6yV79R5PdS62NBDclb6wsdS+v67psaVIGA/NS9+yUpADUbld0TWxxWKTpbz8kI0DtMuwNc/ry2KrRzCj+XWSxlZtduejLgI9lni+vg5/xkNG6ybtJF+Kni4gypLNvFpIgGDpEZDBaYxhsesY5KSbQFAnhAB4TOnDwnxw1+v/URq/HIQD0R5evGZN76+0fo0OwoRTFTCh1aXa4tmsNoVtM2nl+ZyYoYe7q8rcsk3e6GDe5CvuB9GrL4l2Jo48pMWV7vBRj6PFqX6eWA2oQPF5IDef1+DtZ1IComP4NWIrkkblT4Alefr9xmKvM2YbNmxtY/NtmBEzXnbQjNG7BPvGp/SA0gVIEvADrYZ2gt6J3ap0/NtOSV5lBrfrcvpg5LL4/JBTvsnih/R1NOgOzpDJRl/vuaIfGBU1Uat8eRxaMQf/pudfT/90e0Ysa98yBWptHQZFrYkh9Xem1R2Fw5AYKhepwlSD4Y9wyxm2kXCtZz5E9qTTB/EdYtPc3/Jr2/O9JGQlIUbq6eY+bhLPxcEML4TPJsE33McfSQiPvgzDfUk0v7/QqOZu18ajEuFn8sMRl11JZ9eA5mLvsFntcuQ/30BOR5bK2ykL/suPUjHmr3ykN3uHA8WoExrJmRwNrJmoueCQu8S1sY8puNuAyQ5vx0cU1HWkUvUtQH7eGP3S+V4LXJY+BkSZq0KtHcddAEEFoDblKh4hF/VH+QRzIMKKUaLJ45nSqqhzLtqDwl8nNULIxyCcRQPAy0fW3VojA67DChu9fsPziUg14k9QkzLs9PgWz95Vaq3lRAOVWsMNESqB5d2lyhXaIBFCOlmvHK2117+ZB+XKpfE6q2MQGdmGJkPV2nntDzbLzMOBtHo2zswjXrOCuiHHiIjXdw7bxJJqthn/Cn0PgFohO1OCGFRfIsQU1IvcGCqL5Qi8fAluDWk18wUzCjJRUxqigwTZLnnhHdNf3njOkYhXdLkq4wfLIu9Xtoihr4dp5/m5eVB+E7cLeeBqQn7J8yTNerV6H8snnDO9rMl0eWQCF1P7CBpJA9hdSBdV5LG5gwfnOY8DxrLOREjLB9upb5yStmEeWYuNU60NM2g1Ahpn+Nyh1zjNNlRGSBi5LBLfvMEAEU5eNMmDZB9eOST8HlAp0KJArxWoZGCyfTw4cB3n+Uyh3JIobBqViI9CPthsGIoQS9oHLTYjSIXa0sezjEPLKp/3Yle/3JOyLM6qaJsx+FqJg28fmeYsTIMMcyl+YSz/TFFC2qiUsaiSz7X/442HM+4chjH4QQy51vsXHVtX/t+9T6cWKWGypjxTqP5O3OsdfV4WkpUcna2NgBq93JdDvjnS9qC5UO5jqh8P8RxwYue/QY9WrNwEhi/b03FhP2/a0q4aHIHqakgyMdZ1awpGsd5L5GNQMG6SDNO+JzrTAxBNHaFMapbXJmeAUUP5djFnlCnhk8G2hHBM8aV7+9pY340eScYbP7je8w0Rr6sQkyHbav0f6TfjpOF7zvf1V2ShDQncAUNlnKqJPhNJw94slbdNKdWr+5RInAMEXV17tA8harOHK9bsGbRNHeOm9eOmEbAFPK/VswLWAZXMxA0oyAYdPM36m7CIjacqa47IMkswLf88FE6fAlH8JJV7oSOqxHtvPsgw1ASzLSsr4Tvg3vGvQ8iERWv6UqV6oRz1RHnFwiAEToTMd+JFAabgJ+zYnaWHzjSv18pq2WFIGKEBg6/WEpOTXpsAa6MiC6mB1hXlDuJx+kDiWnSpbQi78rk4M3gghWM6GHwZxEwQPl9U9o67pxhHV5EVDKK9dS9Yw+l4pkmJ3eDmfU3mUzje2XzL2W7MHbBmSGrB0LlH+VeHorNThN+9yi6iwluG7rj2GAKzkj5MW1CSgKuf+HBfcFrHDwyIMigH2nUMfrLMuwxtzBbyagl4HYbt9VQ6aQ0zMsH3KgL9NFrPbhcO7qINEPK5dx+6mNWubQeEmT7p8xrTGh3/NXpQlvhMExqiEP0bMsUYtAwEHnr+hWt3KcDFtxZ4MUPjsiPZIGrogz0BJ3G9PEddmb7peMrX7wH1TuwtCJZzGeJSoF6Uq3aa3zK8uF4/Gdg0pvbi3k09du21IN7XS/r83BQ0f8A2d93KGu/tCRmBHdnBRfszJ2VYnF9hdichjmVV1QzRWoIlaTaz+1h/12XIdzXi3UvEUenCCnriDHdsKVCrj6jiPTNxfxEeUvfgkTVgGwxx3Rtsqjc93xKcudqi/vg48Nuwm4iC0yJg/FbeYs2qsnOksz1XHVEMHbc4GXNRKuP1CO/ygLhQ/u4Q8eO1aO4QIHqNSWoauwb47n41ZVUEZanx78m6P5wwccqVl6J+1kObq8V8LpHFObHxI7yQ9Bi2jPfMqaYRxjqGiBQHWpU+nVaX7mZjPsd9zaXsHjUSNO+fzSUFgcb9shWnIDs21dOSU2JU3YE+Y/DZVzk4BhLsf+hbKifTDsRQVGNosQ9DFBSy5NE4kGhRePkA0STeS1O340gZ/vagM4XMkS+qPjeERmCuXSFl7DHFcQ5kkDoA2jFs+d5/++ZaJy9aNdau6VJnpJkI14Jqi4NMOIdku6frJw23GOk8xZwXfE+3olnb6jK+uoY3lmCE1Awa0XPg7hHQ32JXJAkEUcFXZvrX595FAA3QiKDFq46+R585DGU/gctkit/DEjtrR3muweFPrXrn5MPSu279O1z2VvnrIGkZA1abiwIicLHt1XP9TlxZgJe0IwhVNcJIgRxtPjjNGRf2tyX0d33+o90OeL42PhdkB29nF2rNo+FSL0CWO3zufNKjk3vmIZEJ4I/TsHPamJrUK0YfG5Fos415ZgpoUQhBAGILG4P/M0ZEwkLW5Tkok1CIIfo4kE6nrHyFF0+c+bOHjnPD9tFRKTTf+D+HXi2UfLyr0ccgil4nZqJ44J1zk+4zT8SHmpb0TxeZBvmwtj9LMTunj/Skmsb7cBlF8q/cW2Q9VWR+9yFoQ915MIy5mZg1+aF/INvwEXmoJbaWUY2LbPD60CiqSvIdDoIoi/f+syt2yrh3o9b5KsWGilf5OYjJ94YLupcC/catHMAER57oN6EbMewhJcS7xFqmgpMSl+N5u/sEM6Tqwpzbn89Ph4VQwRKsyfChEHhXS2IEc3wcZ6cY6JGCwUfuiut1eQWjBCiGSCYC7FplAXhb+KW9dcAdBeSzoFdJL3ezxXN8dpvJsCJ3LxGHD+cS0EBOMSvGnnkVpeO9DrOrkHOtqLMIwaIBxXiFc5nwymuBkD5G7dYmG9OKi+3QSGy2omcETo1+y3BTCAyKqOsreHMDoyeSqkcnPbVN+azU8iV9dDBYyCiZnFExf8Y5K9xS+d8UrUB+lWoV4DGnPX8CqmwpHZXJ6ukoAOYR1z3JTC3Svu6FidF6E3GmIQWmRCPHVcyfUBITPGRYN8Ymq3WX4pdaAFBEE1qU1zXsUJ8NmqPdZdDrAvEsVcTKjRKfugPhfn8EsRzzhX7LiBU7/7Jc2WM8Xn0fTDp3EdO/q2B0CrLYYN7BmcnXoTkhLSRCf1cIEA8ulX4thyb/xl2kLyNC664WlHN1VZhm1WwkGInIttiSNIXl0q/QpnqcmYKVFmz6LvNaGpcdWWvZfdf2seEC15lDqgDFfcvz5Ah8FSlr1eR5cMcvRU2oPJuAJ3MjmldnwrRxB6mSvjr9Af59Jp4yWyL28PyQSO9Vn/eVSQa0FDZL4cjAxbk0IrAn9CseJOJSk8EliIZikHRYaxDQySslCillnhLbk/eKUUoBJ/asTiGMLC9nT3Uht9HOzPqTu67KUDhZYRdwBnliLXEhXw1Jyup4IshQHJiitY1a0+USP2J9xTXIhxijLmQRKLwnhH65hsBkcWdiUfppXVsocWhhXmQHjWO1ZNWApcj+iVGlFtnHorBA98f1PPF4KZ87boUckx4nl4HIOMj08VIOyznagFO/Whl4XM6VDbOCv7e84xcEAPiTaIB9Z7VAEVKGt1Uy5Q6G1Hsz6SA25Hv57RPnEdwVtnyAmT7xtqwRnhuOj2mIU5iSRLAp8ojWQFoTYTRek23QqF+s1c26SDJrBucbwhQYrgmzG14DOeGeMuXhtpmrkxie5WR6UxKlEXnWXALcIPjqO5HxpStCVEvuPeVoZzY2ZhNKQxOIao8IcEOWoVTmJYC8Bg7RW9MsFEGGJjTUBehScN91qSwRz4O4GHnf/4rSPpQzbsko1dVT8wuHlZCKO1VNhznesEtNSRAe3QRGxEUgyo9zTOTxboPzNiuqkMlwx2dOMxwEq+jdx1uJpVDZ4slCBfmZCR5F7m92AyyWHlcS6WKlKqFcmS/Y3wxlzKBtTsfgHhQeBCCx74JJ2hHTwt9ta/iT2WfSIrpRb2jvCmRrkxhpBzEXsmNujTKPIW5uMjW545YGY3wZMlt/SpkCnbRoYgUZcE8Ah10m89q/Kbm2fArFLhBjp6jlKbx9Kt2CUfHC7tsZZ61snYJ6epbva2tzm3mWF0qifTIKwmX8p3QLgzB0pxTUNRP7LRmPB3RTWtG6pVax0rRNBWH2esv0rE2nrP6vEzs1+bsCQf5D65iqU3b294ZF8uDn9xhFP7eg/DpaTTCroaWjawqp9U04QPxrNKB/eBYTVwzPtxP/YVp21U46GQ4D2+OYl+rGCJ298VuuijrzHWijTaXzqDWPRiSW31ujNZKpjjIbEFsnlFfEHjPlGdgGbiiRIm+KeWDiCQFBe+9qQV6sM8+KXte+KV+y1lFTwwEA5Iv1iBn2T+Fun230JAcwWEFtpYjm6Yx8KVehHtk+tjJ1qp1Wm6n+kaZAqjoE6N1QO6o/RMM/FCYztc77RpLk5Y4ZsC+diNTiYgmmJfZ+wTIwtcWS/wxFH/Mfd7uiCGUf/QZMoEnJb5hnDKhIcc8xR4BotE11Qazt2GFO9mExD+WYLV3k+py1xNkEyA7hV3Gx8ZWOdP68wKwTLe21aZFdFu+l8182tuZRKQ6KYByl/nGqsTBmP5kXkGZ1g6GEd7MIzNORQhUch3FdK6nLVWIbQ58e+MuiE1UYcCnQLE2vGrVVtl8sCC7L88YH+II1Pe9NPD5NnDZWbC2HSpgRCiHrjwyrFhHjA6W/DX9t+rgg8LZaW9jfDg/TB2b3VAU7aKpYJYgLnw6oLWqCzhb/f56bGRj4fy5JxH5H/oHpaET6IencrONhjE93fP54niuhyBfGtDjUu97/Go44nX/BTcbvvQMC0l48Fy3lM+TAYtU9dcsc8FSlnuZdLc0sAS+5zixQc2dywkCIzMu9L8dADZLNQmEQ8qdXW9murlk8CFD18Tgkf5jy/nuz64sZwwoUApmHVPNcyqPqpp8U0Wrh7Pb1jIRRP50uZ+MRIGn82ZCT1BGRWcZCFT33Yk81V4wX8/fHX1+R++P48pbcHHS8ZwGZYGtjdwWeQ4oPo18gOTVY18fqtNwAHqvHpsLlnDOjgCXB3XgbfATyOFXtoojmjCVgjX4R/bJFUMcJRiczSdbb4jtQna3/+5jleon6QhIjU2VKGotvDq3uRw38AD8pvyhGTgtYC/LHNDS62cfhLEDrKy7VY/KiRBs5k00GiOI3LyLbtNryk5YGiWsteh83Qz8Z+HfC2O7DkkQRH8SCa3UQs/BVJL8RfJSpMhNiE3ij03H8vxY3Ps8vLhaPm5Roe4PQv+zE0Dpy5kjIYFzf0+2y0Ivq7duxPemQBWvz39sq9i1/+jQxFrslUuyIEf0yBLGbKBVpiSnRSOPxDwfISEV1Mydl7cmbcWtyOMgZNchkayn4NibVbdWB+aODFUgi6waUZ4zYFBKCQnffCW7vrHNVIsaPi1Iws2J5KjwvE6isar0/hcs4cm4WHjzkVZIKnGazDSB1h9wCTnHBR7oZ6laPuZusLKsGgn3GrXYrhZhoqYz14RWK/mpuwKLw1yHSHGjZ/gtDvQrZXfkQNcsaH5iDwoij/Ybp+s78JRKnEyHgQCV4qyUJngFWq+fBoeveD72/POZFVAdiVHUsZ8LCqQOfrnfuBUpIQS0g8QRKBlx1w7H4L9HWbY1E3eEzw7iZ4CSAlUIGwhnnWeFKNo7a315R6lWiMbgLxqLhG+wt5GyoFvTdSeZYaOb1mPgcZssU+SaPfwlr/N0wWWc3ei+g3ImIROvbiy5NHldS2m28MEckLazXfwegCGwm+IzkJanrY+zHpDeXf9Qbzbs4A2SNgUUCqsXDjjgtmJuzGHZ+xYKMPhLkDra0LuqCmMdNRXbkfKsiWmtH1fEfJP0C6NuXesfZMhBLHjx9ACcsTvjkpcOA/Nos2HyvctOj8BqDJdbHYxLWcQPxdw/+nf7h49N2al1e20HN0Igd5Ed063Uo3wfvAJXyePom+EswIBiScoZpUFQCjiLGLEh/lF1K6qLoQKKaygnoO2Vo+E4Ncct6hTkQnSiZBGKuUTNoNKL3DCt8R4R7Og61XpUGyR7qvDscMWKoaZJzGMu0YK8IvnLZc0s4ts8yi28qvgRZJPpoBY/MYkmBjxYn3e1j/yZecX10CQVc6qj40ZB/GyutFtJ+yYWaa/2JAJXLqShEJlrvxV20D94lK3BVZRQziVkbZPBZLLoVsOw4+nGLwSFdgqiDxcvRbICD2vCsTU/CfyX4KhmYY1e2jAxC/TB9oceGcc/kSJ5E+sKP9lmvKer6Pw7oboH/LHZ7iuijj2XQABafpOB4pyYs81EkPkW4+MzMPsQTTY6vlGiJQutE80/17uZHcaNv2Lx2ek/avz+Pm+OoIRLYoZqRISLpenF2d8yY4m3cJmPhQSLNcJeL4JM6mjt7gj5UcIXL1OzCrrkrcytyHZ31rlSyNWHZMjRKWsNCqEo36bVnGhx8hekI9fOwDIOBVBYkIDd/7GewMG8nZIXIKfD/gaPiK6SwaKD0/1gI5D5NTRiEAdHyEdZF06IeWtNZ+O0YVG2KuVP4l5cT7drXBvmTrILe2gaK19C/IhpZtw5mXnQjT5a1iubV6JUe8oiJgn2SOO4UL32wqW4I/2qFOqVmCvnddL+Dm8+b4TqhowMGfEAAA=";

    
          // Uploaded covers use their actual image dimensions; no crop or distortion.
          const COVER_CROPS = [[0,0,768,1167],[0,0,768,1182],[0,0,768,1161],[0,0,768,700],[0,0,768,1161],[0,0,768,995],[0,0,768,1182],[0,0,530,800],[0,0,768,1156],[0,0,768,1024],[0,0,768,1158]];
          const uploadedCoverImages = UPLOADED_COVER_DATA.map((src) => {
            const image = new Image();
            image.decoding = "async";
            if (TL_ROOT.dataset.crossOrigin) image.crossOrigin = TL_ROOT.dataset.crossOrigin;
            image.src = src;
            return image;
          });
          let coverAtlasReady = false;
          const woodTextureImage = new Image();
          woodTextureImage.decoding = "async";
          woodTextureImage.src = WOOD_TEXTURE_DATA;
          let woodTextureReady = false;

          const experience = document.querySelector("#experience");
          const canvas = document.querySelector("#scene");
          const loading = document.querySelector("#loading");
          const staticFallback = document.querySelector("#static-fallback");
          const fallbackStatus = document.querySelector("#fallback-status");
          const browseUi = document.querySelector("#browse-ui");
          const detailPanel = document.querySelector("#detail-panel");
          const selectionTitle = document.querySelector("#selection-title");
          const selectionNote = document.querySelector("#selection-note");
          const counter = document.querySelector("#counter");
          const paletteLabel = document.querySelector("#palette-label");
          const markers = document.querySelector("#markers");
          const previousButton = document.querySelector("#previous");
          const nextButton = document.querySelector("#next");
          const inspectButton = document.querySelector("#inspect");
          const closeButton = document.querySelector("#close-detail");
          const sheetHandle = document.querySelector("#sheet-handle");
          const resetButton = document.querySelector("#reset-view");
          const toggleBookButton = document.querySelector("#toggle-book");
          const previousPageButton = document.querySelector("#previous-page");
          const nextPageButton = document.querySelector("#next-page");
          const pageLabel = document.querySelector("#page-label");
          const pageCounter = document.querySelector("#page-counter");
          const detailMicrocopy = document.querySelector(".detail-controls .microcopy");
          const detailEyebrow = document.querySelector("#detail-eyebrow");
          const detailTitle = document.querySelector("#detail-title");
          const detailDeck = document.querySelector("#detail-deck");
          const detailBlurb = document.querySelector("#detail-blurb");
          const detailAuthor = document.querySelector("#detail-author");
          const liveRegion = document.querySelector("#live-region");
          const pointerLabel = document.querySelector("#pointer-label");
          const pointerLabelIndex = document.querySelector("#pointer-label-index");
          const pointerLabelTitle = document.querySelector("#pointer-label-title");
          const reducedMotionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");

          const clamp = THREE.MathUtils.clamp;
          const damp = THREE.MathUtils.damp;
          const lerp = THREE.MathUtils.lerp;
          const smoothstep = (value) => value * value * (3 - 2 * value);
          const smootherstep = (value) => (
            value * value * value * (value * (value * 6 - 15) + 10)
          );
          const mod = (value, length) => ((value % length) + length) % length;
          const pad = (value) => String(value).padStart(2, "0");

          let reducedMotion = reducedMotionQuery.matches;
          let renderer;
          let scene;
          let camera;
          let controls;
          let environmentTarget;
          let shelfStage;
          let bookRigs = [];
          let hitTargets = [];
          let rafId = 0;
          let lastTime = performance.now();
          let mode = "hero";
          let transitionTime = 0;
          let position = 0;
          let targetPosition = 0;
          let selectedIndex = 0;
          let hoveredIndex = -1;
          let wheelIdle = 0;
          let focusReturnTarget = inspectButton;
          let activeBook = null;
          let readingOpen = false;
          let detailBookHovered = false;
          let currentSpread = 0;
          let pointerDirty = false;
          let suspended = false;
          let viewWidth = window.innerWidth;
          let viewHeight = window.innerHeight;
          // View offsets shift the rendered frame so the book sits in the free area
          // beside (desktop) or above (mobile bottom sheet) the detail panel.
          const viewOffset = { x: 0, y: 0 };
          const heroViewOffset = { x: 0, y: 0 };
          const detailOffsetClosed = { x: 0, y: 0 };
          const detailOffsetOpen = { x: 0, y: 0 };
          const openingViewOffset = { x: 0, y: 0 };
          const closingViewOffset = { x: 0, y: 0 };
          let detailSafeWidth = viewWidth * 0.6;
          let sheetHeight = 0;
          let isNarrow = viewWidth <= 880;
          let positionVelocity = 0;
          let wheelDirection = 0;
          let suppressShelfClick = false;
          let shelfInView = true;
          const shelfSection = document.querySelector("#books");
          const shelfDrag = {
            active: false,
            pointerId: null,
            pointerType: "mouse",
            startX: 0,
            startY: 0,
            startTarget: 0,
            startScroll: 0,
            lastX: 0,
            lastTime: 0,
            velocity: 0,
            axis: null
          };
          let themeInitialized = false;
          let themeMoving = false;

          const roomMaterials = {
            floor: null,
            wall: null,
            shelf: null,
            shelfDark: null,
            shadow: null
          };
          const roomLights = {
            hemisphere: null,
            key: null,
            softKey: null,
            fill: null,
            rim: null,
            backFill: null,
            spineRake: null,
            pageRake: null
          };
          const themeTargets = {
            floor: new THREE.Color(0xd8c8aa),
            wall: new THREE.Color(0xe9dfcb),
            shelf: new THREE.Color(0x4a2b1d),
            shelfDark: new THREE.Color(0x2a170f),
            shadow: new THREE.Color(0x2f1d13),
            fog: new THREE.Color(0xe9dfcb),
            hemisphere: new THREE.Color(0xfff8e8),
            hemisphereGround: new THREE.Color(0x5b4030),
            key: new THREE.Color(0xffe8c2),
            fill: new THREE.Color(0xd8e3e7),
            rim: new THREE.Color(0xd5a45e)
          };

          const pointer = {
            ndc: new THREE.Vector2(3, 3),
            clientX: 0,
            clientY: 0
          };
          const pageDrag = {
            active: false,
            pointerId: null,
            startX: 0,
            startY: 0,
            progress: 0,
            peakProgress: 0,
            committed: false,
            progressVelocity: 0,
            verticalBias: 0,
            lastProgress: 0,
            lastTime: 0,
            direction: 0,
            kind: null
          };
          const detailPress = {
            active: false,
            pointerId: null,
            startX: 0,
            startY: 0,
            moved: false,
            allowClick: false
          };

          const raycaster = new THREE.Raycaster();
          const shelfCameraPosition = new THREE.Vector3();
          const shelfCameraTarget = new THREE.Vector3();
          const inspectPosition = new THREE.Vector3();
          const inspectCameraPosition = new THREE.Vector3();
          const inspectCameraTarget = new THREE.Vector3();
          const transitionCameraTarget = new THREE.Vector3();
          const openingBookPosition = new THREE.Vector3();
          const openingBookQuaternion = new THREE.Quaternion();
          const openingBookScale = new THREE.Vector3();
          const openingMotionPosition = new THREE.Vector3();
          const openingMotionQuaternion = new THREE.Quaternion();
          const restingMotionPosition = new THREE.Vector3();
          const restingMotionQuaternion = new THREE.Quaternion();
          const openingCameraPosition = new THREE.Vector3();
          const openingCameraTarget = new THREE.Vector3();
          const openingShelfPosition = new THREE.Vector3();
          const inspectShelfPosition = new THREE.Vector3(0, -4.2, -3);
          const inspectBookQuaternion = new THREE.Quaternion().setFromEuler(
            new THREE.Euler(0.055, -0.14, 0)
          );
          const inspectBookScale = new THREE.Vector3();
          const closingBookPosition = new THREE.Vector3();
          const closingBookStartPosition = new THREE.Vector3();
          const closingBookStartQuaternion = new THREE.Quaternion();
          const closingBookStartScale = new THREE.Vector3();
          const closingBookQuaternion = new THREE.Quaternion();
          const closingBookScale = new THREE.Vector3(1.09, 1.09, 1.09);
          const closingMotionPosition = new THREE.Vector3();
          const closingMotionQuaternion = new THREE.Quaternion();
          const closingCameraPosition = new THREE.Vector3();
          const closingCameraTarget = new THREE.Vector3();
          const closingShelfPosition = new THREE.Vector3();
          const shelfRestPosition = new THREE.Vector3();
          const scratchBox = new THREE.Box3();
          const scratchVector = new THREE.Vector3();
          const shelfBoardTop = 0.47;
          let spacing = 1.5;
          const PAGINATED_LEAF_COUNT = 4;
          const SPREAD_COUNT = PAGINATED_LEAF_COUNT + 1;
          const FLEXIBLE_PAGE_SEGMENTS = 18;
          const FLEXIBLE_PAGE_VERTICAL_SEGMENTS = 8;
          const PAGE_TURN_COMMIT_PROGRESS = 0.18;
          const COVER_OPEN_COMMIT_PROGRESS = 0.16;
          const COVER_CLOSE_COMMIT_PROGRESS = 0.2;
          const DETAIL_TRANSITION_DURATION = 0.92;
          const SHELF_TRANSITION_DURATION = 0.92;

          const shared = {
            box: new THREE.BoxGeometry(1, 1, 1),
            plane: new THREE.PlaneGeometry(1, 1),
            page: new THREE.MeshPhysicalMaterial({
              color: 0xe7dfcf,
              roughness: 0.95,
              metalness: 0,
              sheen: 0.025,
              sheenRoughness: 1
            }),
            pageSheet: new THREE.MeshPhysicalMaterial({
              color: 0xeee6d7,
              roughness: 0.955,
              metalness: 0,
              sheen: 0.02,
              sheenRoughness: 1,
              side: THREE.DoubleSide
            }),
            headband: new THREE.MeshPhysicalMaterial({
              color: 0xc6a66d,
              roughness: 0.58,
              metalness: 0.16,
              sheen: 0.14,
              sheenRoughness: 0.76
            }),
            walnut: new THREE.MeshStandardMaterial({
              color: 0x4a2b1d,
              roughness: 0.58,
              metalness: 0
            }),
            walnutDark: new THREE.MeshStandardMaterial({
              color: 0x2a170f,
              roughness: 0.7,
              metalness: 0
            })
          };

          function createFadeMaterial(baseMaterial) {
            const material = baseMaterial.clone();
            material.transparent = true;
            material.opacity = 1;
            return material;
          }

          function hashSeed(value) {
            let hash = 2166136261;
            for (let index = 0; index < value.length; index += 1) {
              hash ^= value.charCodeAt(index);
              hash = Math.imul(hash, 16777619);
            }
            return hash >>> 0;
          }

          function seededRandom(seed) {
            let value = seed >>> 0;
            return () => {
              value += 0x6d2b79f5;
              let result = value;
              result = Math.imul(result ^ (result >>> 15), result | 1);
              result ^= result + Math.imul(result ^ (result >>> 7), result | 61);
              return ((result ^ (result >>> 14)) >>> 0) / 4294967296;
            };
          }

          function drawMotif(ctx, book, width, height) {
            const foil = book.foil;
            ctx.save();
            ctx.strokeStyle = foil;
            ctx.fillStyle = foil;
            ctx.lineWidth = Math.max(3, width * 0.004);
            ctx.globalAlpha = 0.88;
            const centerX = width * 0.5;
            const centerY = height * 0.38;
            const size = Math.min(width, height) * 0.22;

            if (book.motifKey === "brackets") {
              for (let layer = 0; layer < 3; layer += 1) {
                const inset = layer * size * 0.22;
                const left = centerX - size + inset;
                const right = centerX + size - inset;
                const top = centerY - size * 0.72 + inset;
                const bottom = centerY + size * 0.72 - inset;
                ctx.beginPath();
                ctx.moveTo(left + size * 0.25, top);
                ctx.lineTo(left, top);
                ctx.lineTo(left, bottom);
                ctx.lineTo(left + size * 0.25, bottom);
                ctx.moveTo(right - size * 0.25, top);
                ctx.lineTo(right, top);
                ctx.lineTo(right, bottom);
                ctx.lineTo(right - size * 0.25, bottom);
                ctx.stroke();
              }
              ctx.fillRect(centerX - 3, centerY - 3, 6, 6);
            } else if (book.motifKey === "paths") {
              ctx.beginPath();
              ctx.moveTo(centerX - size, centerY + size * 0.35);
              ctx.bezierCurveTo(centerX - size * 0.2, centerY - size, centerX + size * 0.1, centerY + size, centerX + size, centerY - size * 0.25);
              ctx.stroke();
              ctx.globalAlpha = 0.52;
              ctx.beginPath();
              ctx.moveTo(centerX - size, centerY - size * 0.45);
              ctx.bezierCurveTo(centerX - size * 0.25, centerY + size, centerX + size * 0.3, centerY - size, centerX + size, centerY + size * 0.45);
              ctx.stroke();
              for (let point = -1; point <= 1; point += 1) {
                ctx.beginPath();
                ctx.arc(centerX + point * size, centerY - point * size * 0.25, 7, 0, Math.PI * 2);
                ctx.fill();
              }
            } else if (book.motifKey === "caret") {
              ctx.beginPath();
              ctx.moveTo(centerX - size * 0.9, centerY + size * 0.6);
              ctx.lineTo(centerX, centerY - size * 0.65);
              ctx.lineTo(centerX + size * 0.9, centerY + size * 0.6);
              ctx.stroke();
              ctx.globalAlpha = 0.38;
              for (let line = -2; line <= 2; line += 1) {
                ctx.beginPath();
                ctx.moveTo(centerX - size, centerY + line * size * 0.28);
                ctx.lineTo(centerX + size, centerY + line * size * 0.28);
                ctx.stroke();
              }
            } else if (book.motifKey === "orbits") {
              ctx.beginPath();
              ctx.ellipse(centerX, centerY, size, size * 0.42, -0.35, 0, Math.PI * 2);
              ctx.stroke();
              ctx.globalAlpha = 0.58;
              ctx.beginPath();
              ctx.ellipse(centerX, centerY, size * 0.72, size, 0.52, 0, Math.PI * 2);
              ctx.stroke();
              ctx.globalAlpha = 0.9;
              ctx.beginPath();
              ctx.arc(centerX + size * 0.64, centerY - size * 0.34, 8, 0, Math.PI * 2);
              ctx.fill();
              ctx.fillRect(centerX - 6, centerY - 6, 12, 12);
            } else if (book.motifKey === "modules") {
              const moduleSize = size * 0.54;
              const positions = [
                [-0.55, -0.5, "circle"],
                [0.25, -0.5, "rect"],
                [-0.55, 0.3, "rect"],
                [0.25, 0.3, "circle"]
              ];
              positions.forEach(([x, y, shape], index) => {
                ctx.globalAlpha = 0.45 + index * 0.12;
                if (shape === "circle") {
                  ctx.beginPath();
                  ctx.arc(centerX + x * size, centerY + y * size, moduleSize * 0.48, 0, Math.PI * 2);
                  ctx.stroke();
                } else {
                  ctx.strokeRect(
                    centerX + x * size - moduleSize * 0.5,
                    centerY + y * size - moduleSize * 0.5,
                    moduleSize,
                    moduleSize
                  );
                }
              });
            } else if (book.motifKey === "frames") {
              for (let layer = 0; layer < 4; layer += 1) {
                ctx.globalAlpha = 0.9 - layer * 0.17;
                const offset = layer * size * 0.18;
                ctx.strokeRect(
                  centerX - size + offset,
                  centerY - size * 0.7 + offset,
                  size * 2 - offset * 2,
                  size * 1.4 - offset * 2
                );
              }
              ctx.beginPath();
              ctx.moveTo(centerX - size, centerY - size * 0.7);
              ctx.lineTo(centerX + size, centerY + size * 0.7);
              ctx.stroke();
            } else {
              ctx.beginPath();
              ctx.arc(centerX, centerY, size * 0.78, 0.15, Math.PI * 1.82);
              ctx.stroke();
              ctx.beginPath();
              ctx.moveTo(centerX - size * 0.72, centerY + size * 0.88);
              ctx.lineTo(centerX, centerY - size * 0.92);
              ctx.lineTo(centerX + size * 0.72, centerY + size * 0.88);
              ctx.stroke();
              ctx.globalAlpha = 0.48;
              ctx.beginPath();
              ctx.moveTo(centerX - size, centerY);
              ctx.lineTo(centerX + size, centerY);
              ctx.stroke();
            }
            ctx.restore();
          }

          let sharedPaperFaceTexture = null;
          let sharedPageEdgeTextures = null;
          let sharedContactShadowTexture = null;

          function configureCanvasTexture(texture, {
            color = true,
            anisotropy = 16
          } = {}) {
            if (color) texture.colorSpace = THREE.SRGBColorSpace;
            texture.anisotropy = Math.min(
              anisotropy,
              renderer.capabilities.getMaxAnisotropy()
            );
            texture.minFilter = THREE.LinearMipmapLinearFilter;
            texture.magFilter = THREE.LinearFilter;
            texture.generateMipmaps = true;
            texture.needsUpdate = true;
            return texture;
          }

          function makeCoverTexture(book) {
            const canvasTexture = document.createElement("canvas");
            canvasTexture.width = 768;
            canvasTexture.height = Math.round(canvasTexture.width / book.coverAspect);
            const ctx = canvasTexture.getContext("2d");

            if (coverAtlasReady) {
              const [sourceX, sourceY, sourceWidth, sourceHeight] = COVER_CROPS[BOOKS.indexOf(book)];
              ctx.drawImage(
                uploadedCoverImages[BOOKS.indexOf(book)],
                sourceX,
                sourceY,
                sourceWidth,
                sourceHeight,
                0,
                0,
                canvasTexture.width,
                canvasTexture.height
              );

              const edgeShade = ctx.createLinearGradient(0, 0, canvasTexture.width, 0);
              edgeShade.addColorStop(0, "rgba(0,0,0,0.16)");
              edgeShade.addColorStop(0.055, "rgba(255,255,255,0.015)");
              edgeShade.addColorStop(0.93, "rgba(255,255,255,0)");
              edgeShade.addColorStop(1, "rgba(0,0,0,0.1)");
              ctx.fillStyle = edgeShade;
              ctx.fillRect(0, 0, canvasTexture.width, canvasTexture.height);

              return configureCanvasTexture(new THREE.CanvasTexture(canvasTexture));
            }

            const random = seededRandom(hashSeed(book.id) + book.seed);

            ctx.fillStyle = book.color;
            ctx.fillRect(0, 0, canvasTexture.width, canvasTexture.height);

            const edge = ctx.createLinearGradient(0, 0, canvasTexture.width, 0);
            edge.addColorStop(0, "rgba(0,0,0,0.24)");
            edge.addColorStop(0.075, "rgba(255,255,255,0.035)");
            edge.addColorStop(0.5, "rgba(255,255,255,0.01)");
            edge.addColorStop(0.94, "rgba(0,0,0,0.06)");
            edge.addColorStop(1, "rgba(0,0,0,0.19)");
            ctx.fillStyle = edge;
            ctx.fillRect(0, 0, canvasTexture.width, canvasTexture.height);

            for (let line = 0; line < 1250; line += 1) {
              const x = random() * canvasTexture.width;
              const y = random() * canvasTexture.height;
              const length = 4 + random() * 22;
              ctx.strokeStyle = random() > 0.5 ? "rgba(255,255,255,0.024)" : "rgba(0,0,0,0.025)";
              ctx.lineWidth = 0.6 + random() * 0.8;
              ctx.beginPath();
              ctx.moveTo(x, y);
              ctx.lineTo(x + length, y + (random() - 0.5) * 2);
              ctx.stroke();
            }

            ctx.strokeStyle = book.foil;
            ctx.globalAlpha = 0.72;
            ctx.lineWidth = 2;
            ctx.strokeRect(42, 42, canvasTexture.width - 84, canvasTexture.height - 84);
            ctx.strokeRect(55, 55, canvasTexture.width - 110, canvasTexture.height - 110);
            ctx.globalAlpha = 1;

            drawMotif(ctx, book, canvasTexture.width, canvasTexture.height);

            ctx.fillStyle = book.foil;
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.font = '500 18px Inter, "Helvetica Neue", Arial, sans-serif';
            ctx.letterSpacing = "4px";
            ctx.fillText(`THE LIST  /  ${book.roman}`, canvasTexture.width / 2, 92);

            const titleSize = book.title.length > 10 ? 72 : 88;
            ctx.font = `400 ${titleSize}px "Iowan Old Style", Baskerville, Georgia, serif`;
            ctx.fillText(book.title, canvasTexture.width / 2, canvasTexture.height * 0.72);
            ctx.font = '500 16px Inter, "Helvetica Neue", Arial, sans-serif';
            ctx.fillText(book.discipline.toUpperCase(), canvasTexture.width / 2, canvasTexture.height * 0.79);

            return configureCanvasTexture(new THREE.CanvasTexture(canvasTexture));
          }

          function makeFoilTexture(book) {
            const foilCanvas = document.createElement("canvas");
            foilCanvas.width = 768;
            foilCanvas.height = 1152;
            const ctx = foilCanvas.getContext("2d");
            const index = BOOKS.indexOf(book) + 1;

            ctx.clearRect(0, 0, foilCanvas.width, foilCanvas.height);
            ctx.fillStyle = "#ffffff";
            ctx.strokeStyle = "#ffffff";
            ctx.textAlign = "left";
            ctx.textBaseline = "alphabetic";

            ctx.font = '500 15px Inter, "Helvetica Neue", Arial, sans-serif';
            ctx.letterSpacing = "2.8px";
            ctx.fillText(`THE LIST  /  ${pad(index)}`, 58, 70);
            ctx.globalAlpha = 0.7;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(58, 86);
            ctx.lineTo(164, 86);
            ctx.stroke();
            ctx.globalAlpha = 1;

            const titleSize = book.title.length > 10 ? 64 : 78;
            ctx.font = `400 ${titleSize}px "Iowan Old Style", Baskerville, Georgia, serif`;
            ctx.fillText(book.title, 58, 1020);
            ctx.font = '500 14px Inter, "Helvetica Neue", Arial, sans-serif';
            ctx.letterSpacing = "2.4px";
            ctx.fillText(book.discipline.toUpperCase(), 60, 1066);

            return configureCanvasTexture(new THREE.CanvasTexture(foilCanvas));
          }

          function makeClothBumpTexture(book) {
            const bumpCanvas = document.createElement("canvas");
            bumpCanvas.width = 256;
            bumpCanvas.height = 256;
            const ctx = bumpCanvas.getContext("2d");
            const random = seededRandom(hashSeed(`${book.id}-cloth`) + book.seed);

            ctx.fillStyle = "#7f7f7f";
            ctx.fillRect(0, 0, bumpCanvas.width, bumpCanvas.height);

            for (let line = 0; line < 256; line += 2) {
              const value = Math.round(98 + random() * 70);
              ctx.strokeStyle = `rgb(${value},${value},${value})`;
              ctx.globalAlpha = 0.34 + random() * 0.18;
              ctx.lineWidth = 0.65 + random() * 0.45;
              ctx.beginPath();
              ctx.moveTo(0, line + (random() - 0.5));
              ctx.lineTo(256, line + (random() - 0.5));
              ctx.stroke();
            }

            for (let line = 1; line < 256; line += 3) {
              const value = Math.round(105 + random() * 58);
              ctx.strokeStyle = `rgb(${value},${value},${value})`;
              ctx.globalAlpha = 0.25 + random() * 0.14;
              ctx.lineWidth = 0.55 + random() * 0.35;
              ctx.beginPath();
              ctx.moveTo(line + (random() - 0.5), 0);
              ctx.lineTo(line + (random() - 0.5), 256);
              ctx.stroke();
            }

            ctx.globalAlpha = 1;
            const texture = new THREE.CanvasTexture(bumpCanvas);
            texture.wrapS = THREE.RepeatWrapping;
            texture.wrapT = THREE.RepeatWrapping;
            texture.repeat.set(5, 8);
            return configureCanvasTexture(texture, {
              color: false,
              anisotropy: 12
            });
          }

          function makeClothSurfaceMaps(book) {
            const size = 256;
            const heightField = new Float32Array(size * size);
            const normalCanvas = document.createElement("canvas");
            const roughnessCanvas = document.createElement("canvas");
            normalCanvas.width = roughnessCanvas.width = size;
            normalCanvas.height = roughnessCanvas.height = size;
            const normalContext = normalCanvas.getContext("2d");
            const roughnessContext = roughnessCanvas.getContext("2d");
            const normalImage = normalContext.createImageData(size, size);
            const roughnessImage = roughnessContext.createImageData(size, size);
            const phase = (book.seed % 19) * 0.23;

            for (let y = 0; y < size; y += 1) {
              for (let x = 0; x < size; x += 1) {
                const warp = Math.sin((x + phase) * Math.PI * 0.52);
                const weft = Math.sin((y - phase) * Math.PI * 0.41);
                const cross = Math.sin((x + y + phase) * Math.PI * 0.19);
                heightField[y * size + x] = 0.5 + warp * 0.18 + weft * 0.15 + cross * 0.045;
              }
            }

            const sampleHeight = (x, y) => {
              const wrappedX = (x + size) % size;
              const wrappedY = (y + size) % size;
              return heightField[wrappedY * size + wrappedX];
            };

            for (let y = 0; y < size; y += 1) {
              for (let x = 0; x < size; x += 1) {
                const index = y * size + x;
                const pixel = index * 4;
                const dx = (sampleHeight(x + 1, y) - sampleHeight(x - 1, y)) * 1.5;
                const dy = (sampleHeight(x, y + 1) - sampleHeight(x, y - 1)) * 1.5;
                const length = Math.hypot(dx, dy, 1);
                normalImage.data[pixel] = Math.round(((-dx / length) * 0.5 + 0.5) * 255);
                normalImage.data[pixel + 1] = Math.round(((-dy / length) * 0.5 + 0.5) * 255);
                normalImage.data[pixel + 2] = Math.round(((1 / length) * 0.5 + 0.5) * 255);
                normalImage.data[pixel + 3] = 255;

                const roughness = Math.round(188 + heightField[index] * 56);
                roughnessImage.data[pixel] = roughness;
                roughnessImage.data[pixel + 1] = roughness;
                roughnessImage.data[pixel + 2] = roughness;
                roughnessImage.data[pixel + 3] = 255;
              }
            }

            normalContext.putImageData(normalImage, 0, 0);
            roughnessContext.putImageData(roughnessImage, 0, 0);

            const configureWeaveMap = (canvas, suffix) => {
              const texture = new THREE.CanvasTexture(canvas);
              texture.name = `${book.id}-${suffix}`;
              texture.wrapS = THREE.RepeatWrapping;
              texture.wrapT = THREE.RepeatWrapping;
              texture.repeat.set(5, 8);
              return configureCanvasTexture(texture, {
                color: false,
                anisotropy: 12
              });
            };

            return {
              normal: configureWeaveMap(normalCanvas, "cloth-normal"),
              roughness: configureWeaveMap(roughnessCanvas, "cloth-roughness")
            };
          }

          function makeEmbossMap(sourceTexture, name) {
            const texture = new THREE.CanvasTexture(sourceTexture.image);
            texture.name = name;
            texture.wrapS = sourceTexture.wrapS;
            texture.wrapT = sourceTexture.wrapT;
            texture.repeat.copy(sourceTexture.repeat);
            texture.offset.copy(sourceTexture.offset);
            texture.center.copy(sourceTexture.center);
            texture.rotation = sourceTexture.rotation;
            return configureCanvasTexture(texture, {
              color: false,
              anisotropy: 16
            });
          }

          function drawPaperSurface(ctx, width, height, random) {
            ctx.fillStyle = "#e8e1d3";
            ctx.fillRect(0, 0, width, height);

            const paperWash = ctx.createLinearGradient(0, 0, width, height);
            paperWash.addColorStop(0, "rgba(255,255,255,0.22)");
            paperWash.addColorStop(0.42, "rgba(255,255,255,0.035)");
            paperWash.addColorStop(1, "rgba(103,87,64,0.08)");
            ctx.fillStyle = paperWash;
            ctx.fillRect(0, 0, width, height);

            for (let fiber = 0; fiber < 2400; fiber += 1) {
              const x = random() * width;
              const y = random() * height;
              const length = 5 + random() * 34;
              const lightFiber = random() > 0.44;
              ctx.strokeStyle = lightFiber
                ? `rgba(255,255,255,${0.025 + random() * 0.045})`
                : `rgba(92,76,55,${0.018 + random() * 0.035})`;
              ctx.lineWidth = 0.45 + random() * 0.65;
              ctx.beginPath();
              ctx.moveTo(x, y);
              ctx.lineTo(
                Math.min(width, x + length),
                y + (random() - 0.5) * 2.2
              );
              ctx.stroke();
            }

            for (let fleck = 0; fleck < 1200; fleck += 1) {
              const tone = Math.round(112 + random() * 94);
              ctx.fillStyle = `rgba(${tone},${tone - 5},${tone - 13},${0.016 + random() * 0.025})`;
              const size = 0.5 + random() * 1.1;
              ctx.fillRect(random() * width, random() * height, size, size);
            }
          }

          function makePaperFaceTexture(book, printed = false) {
            if (!printed && sharedPaperFaceTexture) return sharedPaperFaceTexture;

            const paperCanvas = document.createElement("canvas");
            paperCanvas.width = 768;
            paperCanvas.height = 1152;
            const ctx = paperCanvas.getContext("2d");
            const random = seededRandom(printed
              ? hashSeed(`${book.id}-printed-page`) + book.seed
              : hashSeed("working-volumes-paper-stock"));

            drawPaperSurface(ctx, paperCanvas.width, paperCanvas.height, random);

            if (printed) {
              const ink = new THREE.Color(book.palette.ink);
              const red = Math.round(ink.r * 255);
              const green = Math.round(ink.g * 255);
              const blue = Math.round(ink.b * 255);
              ctx.fillStyle = `rgba(${red},${green},${blue},0.2)`;
              ctx.textAlign = "left";
              ctx.textBaseline = "alphabetic";
              ctx.font = '500 15px Inter, "Helvetica Neue", Arial, sans-serif';
              ctx.letterSpacing = "2px";
              ctx.fillText(book.title.toUpperCase(), 84, 98);
              ctx.fillRect(84, 121, 190, 2);

              for (let column = 0; column < 2; column += 1) {
                const left = 84 + column * 316;
                for (let line = 0; line < 34; line += 1) {
                  const y = 184 + line * 23;
                  const lastInParagraph = line % 7 === 6;
                  const lineWidth = lastInParagraph
                    ? 108 + random() * 86
                    : 190 + random() * 72;
                  ctx.globalAlpha = 0.22 + random() * 0.11;
                  ctx.fillRect(left, y, lineWidth, 1.45);
                }
              }

              ctx.globalAlpha = 0.32;
              ctx.font = '400 17px "Iowan Old Style", Baskerville, Georgia, serif';
              ctx.fillText(book.roman, paperCanvas.width - 104, paperCanvas.height - 72);
              ctx.globalAlpha = 1;
            }

            const texture = configureCanvasTexture(new THREE.CanvasTexture(paperCanvas));
            if (!printed) sharedPaperFaceTexture = texture;
            return texture;
          }

          function drawWrappedCanvasText(ctx, text, x, y, maxCharacters, lineHeight, maxLines = 6) {
            const words = text.split(/\s+/);
            let line = "";
            let lineIndex = 0;

            words.forEach((word) => {
              if (lineIndex >= maxLines) return;
              const candidate = line ? `${line} ${word}` : word;
              if (candidate.length > maxCharacters && line) {
                ctx.fillText(line, x, y + lineIndex * lineHeight);
                line = word;
                lineIndex += 1;
              } else {
                line = candidate;
              }
            });

            if (line && lineIndex < maxLines) {
              ctx.fillText(line, x, y + lineIndex * lineHeight);
            }
          }

          function makeEndpaperTexture(book) {
            const canvas = document.createElement("canvas");
            canvas.width = 512;
            canvas.height = 768;
            const ctx = canvas.getContext("2d");
            const random = seededRandom(hashSeed(`${book.id}-endpaper`) + book.seed);
            drawPaperSurface(ctx, canvas.width, canvas.height, random);

            ctx.save();
            ctx.fillStyle = book.color;
            ctx.globalAlpha = 0.14;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.globalAlpha = 0.18;
            ctx.strokeStyle = book.foil;
            ctx.lineWidth = 1;
            for (let x = 28; x < canvas.width; x += 48) {
              ctx.beginPath();
              ctx.moveTo(x, 0);
              ctx.lineTo(x, canvas.height);
              ctx.stroke();
            }
            for (let y = 24; y < canvas.height; y += 48) {
              ctx.beginPath();
              ctx.moveTo(0, y);
              ctx.lineTo(canvas.width, y);
              ctx.stroke();
            }
            ctx.globalAlpha = 0.42;
            drawMotif(ctx, { ...book, foil: book.palette.inkSoft }, canvas.width, canvas.height);
            ctx.restore();

            const texture = configureCanvasTexture(new THREE.CanvasTexture(canvas), {
              anisotropy: 16
            });
            texture.name = `${book.id}-patterned-endpaper`;
            return texture;
          }

          function makeInteriorPageTextures(book) {
            const pageCount = 8;
            const inkColor = new THREE.Color(book.color).lerp(new THREE.Color(0x211b16), 0.62);
            const ink = `#${inkColor.getHexString()}`;

            return Array.from({ length: pageCount }, (_, pageIndex) => {
              const canvas = document.createElement("canvas");
              const logicalWidth = 512;
              const logicalHeight = 768;
              canvas.width = 384;
              canvas.height = 576;
              const ctx = canvas.getContext("2d");
              ctx.scale(0.75, 0.75);
              const random = seededRandom(hashSeed(`${book.id}-leaf-${pageIndex}`) + book.seed);
              drawPaperSurface(ctx, logicalWidth, logicalHeight, random);
              ctx.fillStyle = ink;
              ctx.strokeStyle = ink;
              ctx.textAlign = "left";
              ctx.textBaseline = "alphabetic";

              ctx.globalAlpha = 0.58;
              ctx.font = '500 10px Inter, "Helvetica Neue", Arial, sans-serif';
              ctx.letterSpacing = "1.8px";
              ctx.fillText(`THE LIST  /  ${book.roman}`, 48, 48);
              ctx.textAlign = "right";
              ctx.fillText(pad(pageIndex + 1), logicalWidth - 48, 48);
              ctx.textAlign = "left";
              ctx.fillRect(48, 64, logicalWidth - 96, 1);
              ctx.globalAlpha = 1;

              if (pageIndex === 0) {
                ctx.font = '500 12px Inter, "Helvetica Neue", Arial, sans-serif';
                ctx.letterSpacing = "2.3px";
                ctx.fillText(book.discipline.toUpperCase(), 54, 174);
                ctx.font = `400 ${book.title.length > 10 ? 48 : 58}px "Iowan Old Style", Baskerville, Georgia, serif`;
                ctx.letterSpacing = "0px";
                drawWrappedCanvasText(ctx, book.title, 52, 246, 18, 58, 2);
                ctx.globalAlpha = 0.55;
                ctx.font = '400 22px "Iowan Old Style", Baskerville, Georgia, serif';
                drawWrappedCanvasText(ctx, book.note, 54, 462, 36, 30, 4);
              } else if (pageIndex === 1 || pageIndex === 3) {
                const chapterIndex = pageIndex === 1 ? 0 : 1;
                ctx.font = '500 11px Inter, "Helvetica Neue", Arial, sans-serif';
                ctx.letterSpacing = "2px";
                ctx.fillText(`CHAPTER ${pad(chapterIndex + 1)}`, 54, 166);
                ctx.font = '400 49px "Iowan Old Style", Baskerville, Georgia, serif';
                ctx.letterSpacing = "0px";
                drawWrappedCanvasText(ctx, book.chapters[chapterIndex], 52, 244, 18, 54, 3);
                ctx.globalAlpha = 0.52;
                ctx.font = '400 20px "Iowan Old Style", Baskerville, Georgia, serif';
                drawWrappedCanvasText(
                  ctx,
                  chapterIndex === 0 ? book.note : book.deck,
                  54,
                  438,
                  42,
                  28,
                  6
                );
              } else if (pageIndex === 2) {
                ctx.font = '500 11px Inter, "Helvetica Neue", Arial, sans-serif';
                ctx.letterSpacing = "2px";
                ctx.fillText("PLATE 01  /  SYSTEM MOTIF", 54, 146);
                ctx.save();
                ctx.globalAlpha = 0.58;
                drawMotif(ctx, { ...book, foil: ink }, logicalWidth, logicalHeight * 0.92);
                ctx.restore();
                ctx.globalAlpha = 0.48;
                ctx.font = '400 17px "Iowan Old Style", Baskerville, Georgia, serif';
                drawWrappedCanvasText(ctx, book.theme, 54, 650, 44, 24, 3);
              } else if (pageIndex === 4) {
                ctx.font = '500 11px Inter, "Helvetica Neue", Arial, sans-serif';
                ctx.letterSpacing = "2px";
                ctx.fillText(`NOTES  /  ${book.chapters[1].toUpperCase()}`, 54, 138);
                ctx.globalAlpha = 0.44;
                for (let column = 0; column < 2; column += 1) {
                  const left = 54 + column * 214;
                  for (let line = 0; line < 24; line += 1) {
                    const width = line % 7 === 6 ? 72 + random() * 54 : 138 + random() * 44;
                    ctx.fillRect(left, 190 + line * 18, width, 1.25);
                  }
                }
                ctx.globalAlpha = 0.78;
                ctx.strokeRect(54, 654, 404, 54);
                ctx.font = '500 10px Inter, "Helvetica Neue", Arial, sans-serif';
                ctx.letterSpacing = "1.4px";
                ctx.fillText(book.motif.toUpperCase(), 70, 686);
              } else if (pageIndex === 5) {
                ctx.font = '500 11px Inter, "Helvetica Neue", Arial, sans-serif';
                ctx.letterSpacing = "2px";
                ctx.fillText("CHAPTER 03", 54, 166);
                ctx.font = '400 49px "Iowan Old Style", Baskerville, Georgia, serif';
                ctx.letterSpacing = "0px";
                drawWrappedCanvasText(ctx, book.chapters[2], 52, 244, 18, 54, 3);
                ctx.globalAlpha = 0.52;
                ctx.font = '400 20px "Iowan Old Style", Baskerville, Georgia, serif';
                drawWrappedCanvasText(ctx, book.deck, 54, 438, 42, 28, 6);
              } else if (pageIndex === 6) {
                ctx.font = '500 11px Inter, "Helvetica Neue", Arial, sans-serif';
                ctx.letterSpacing = "2px";
                ctx.fillText("PLATE 02  /  TECHNICAL SYSTEM", 54, 146);
                ctx.save();
                ctx.translate(logicalWidth * 0.5, 380);
                ctx.globalAlpha = 0.55;
                for (let ring = 0; ring < 5; ring += 1) {
                  const radius = 38 + ring * 34;
                  ctx.beginPath();
                  ctx.arc(0, 0, radius, 0, Math.PI * 2);
                  ctx.stroke();
                }
                for (let spoke = 0; spoke < 8; spoke += 1) {
                  const angle = spoke * Math.PI * 0.25;
                  ctx.beginPath();
                  ctx.moveTo(Math.cos(angle) * 36, Math.sin(angle) * 36);
                  ctx.lineTo(Math.cos(angle) * 176, Math.sin(angle) * 176);
                  ctx.stroke();
                }
                ctx.restore();
                ctx.globalAlpha = 0.48;
                ctx.font = '400 17px "Iowan Old Style", Baskerville, Georgia, serif';
                drawWrappedCanvasText(ctx, book.theme, 54, 650, 44, 24, 3);
              } else {
                ctx.font = '500 11px Inter, "Helvetica Neue", Arial, sans-serif';
                ctx.letterSpacing = "2px";
                ctx.fillText("COLOPHON", 54, 164);
                ctx.font = '400 32px "Iowan Old Style", Baskerville, Georgia, serif';
                ctx.letterSpacing = "0px";
                ctx.fillText(book.title, 54, 230);
                ctx.globalAlpha = 0.58;
                ctx.font = '400 18px "Iowan Old Style", Baskerville, Georgia, serif';
                drawWrappedCanvasText(
                  ctx,
                  `By ${book.author}. Presented on The List shelf.`,
                  54,
                  306,
                  44,
                  28,
                  7
                );
                ctx.globalAlpha = 0.74;
                ctx.font = '500 10px Inter, "Helvetica Neue", Arial, sans-serif';
                ctx.letterSpacing = "1.8px";
                ctx.fillText(`SPECIMEN ${book.roman} / ${book.seed}  ·  IMAGINED EDITION`, 54, 676);
              }

              ctx.globalAlpha = 0.62;
              ctx.fillRect(48, logicalHeight - 48, logicalWidth - 96, 1);
              ctx.globalAlpha = 1;
              const texture = configureCanvasTexture(new THREE.CanvasTexture(canvas), {
                anisotropy: 16
              });
              texture.name = `${book.id}-interior-page-${pageIndex + 1}`;
              return texture;
            });
          }

          function makeContactShadowTexture() {
            if (sharedContactShadowTexture) return sharedContactShadowTexture;
            const canvas = document.createElement("canvas");
            canvas.width = 512;
            canvas.height = 128;
            const ctx = canvas.getContext("2d");
            const gradient = ctx.createRadialGradient(256, 64, 10, 256, 64, 254);
            gradient.addColorStop(0, "rgba(255,255,255,0.95)");
            gradient.addColorStop(0.38, "rgba(255,255,255,0.62)");
            gradient.addColorStop(0.72, "rgba(255,255,255,0.18)");
            gradient.addColorStop(1, "rgba(255,255,255,0)");
            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            sharedContactShadowTexture = configureCanvasTexture(
              new THREE.CanvasTexture(canvas),
              { color: false, anisotropy: 8 }
            );
            sharedContactShadowTexture.name = "soft-contact-shadow";
            return sharedContactShadowTexture;
          }

          function makePageEdgeTextures(book) {
            if (sharedPageEdgeTextures) return sharedPageEdgeTextures;

            const makeEdgeTexture = (width, height, suffix) => {
              const edgeCanvas = document.createElement("canvas");
              edgeCanvas.width = width;
              edgeCanvas.height = height;
              const ctx = edgeCanvas.getContext("2d");
              const random = seededRandom(
                hashSeed(`${book.id}-${suffix}`) + book.seed
              );

              ctx.fillStyle = "#dcd5c7";
              ctx.fillRect(0, 0, width, height);

              const pageStep = suffix === "fore-edge" ? 2 : 1.35;
              for (let y = 0; y < height; y += pageStep) {
                const shade = Math.round(106 + random() * 74);
                const signature = random() > 0.965;
                ctx.strokeStyle = `rgba(${shade},${shade - 3},${shade - 9},${signature ? 0.34 : 0.13 + random() * 0.13})`;
                ctx.lineWidth = signature ? 1.05 : 0.42 + random() * 0.42;
                ctx.beginPath();
                ctx.moveTo(0, y + (random() - 0.5) * 0.5);
                ctx.bezierCurveTo(
                  width * 0.3,
                  y + (random() - 0.5) * 0.9,
                  width * 0.72,
                  y + (random() - 0.5) * 0.9,
                  width,
                  y + (random() - 0.5) * 0.5
                );
                ctx.stroke();
              }

              const edgeShade = ctx.createLinearGradient(0, 0, width, 0);
              edgeShade.addColorStop(0, "rgba(58,48,35,0.18)");
              edgeShade.addColorStop(0.035, "rgba(255,255,255,0.04)");
              edgeShade.addColorStop(0.86, "rgba(255,255,255,0)");
              edgeShade.addColorStop(1, "rgba(58,48,35,0.12)");
              ctx.fillStyle = edgeShade;
              ctx.fillRect(0, 0, width, height);

              return configureCanvasTexture(new THREE.CanvasTexture(edgeCanvas));
            };

            sharedPageEdgeTextures = {
              fore: makeEdgeTexture(512, 2048, "fore-edge"),
              headTail: makeEdgeTexture(2048, 384, "head-tail-edge")
            };
            return sharedPageEdgeTextures;
          }

          function createRoundedPlaneGeometry(width, height, radius) {
            const halfWidth = width * 0.5;
            const halfHeight = height * 0.5;
            const corner = Math.min(radius, halfWidth, halfHeight);
            const shape = new THREE.Shape();

            shape.moveTo(-halfWidth + corner, -halfHeight);
            shape.lineTo(halfWidth - corner, -halfHeight);
            shape.quadraticCurveTo(halfWidth, -halfHeight, halfWidth, -halfHeight + corner);
            shape.lineTo(halfWidth, halfHeight - corner);
            shape.quadraticCurveTo(halfWidth, halfHeight, halfWidth - corner, halfHeight);
            shape.lineTo(-halfWidth + corner, halfHeight);
            shape.quadraticCurveTo(-halfWidth, halfHeight, -halfWidth, halfHeight - corner);
            shape.lineTo(-halfWidth, -halfHeight + corner);
            shape.quadraticCurveTo(-halfWidth, -halfHeight, -halfWidth + corner, -halfHeight);

            const geometry = new THREE.ShapeGeometry(shape, 8);
            const position = geometry.getAttribute("position");
            const uv = new Float32Array(position.count * 2);
            for (let index = 0; index < position.count; index += 1) {
              uv[index * 2] = (position.getX(index) + halfWidth) / width;
              uv[index * 2 + 1] = (position.getY(index) + halfHeight) / height;
            }
            geometry.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
            geometry.computeVertexNormals();
            return geometry;
          }

          function createPageBlockGeometry(width, height, depth, radius) {
            const geometry = new RoundedBoxGeometry(width, height, depth, 4, radius);
            const position = geometry.getAttribute("position");
            const halfWidth = width * 0.5;

            for (let index = 0; index < position.count; index += 1) {
              const x = position.getX(index);
              const z = position.getZ(index);
              const normalizedX = clamp((x + halfWidth) / width, 0, 1);
              const gutterProgress = clamp(normalizedX / 0.16, 0, 1);
              const gutterEase = gutterProgress * gutterProgress * (3 - 2 * gutterProgress);
              const gutterCompression = (1 - gutterEase) * 0.012;
              const foreEdgeCharacter = Math.pow(normalizedX, 8) * Math.sin(position.getY(index) * 31) * 0.00055;
              const adjustedZ = Math.sign(z || 1) * Math.max(
                0,
                Math.abs(z) - gutterCompression + foreEdgeCharacter
              );
              position.setZ(index, adjustedZ);
            }

            position.needsUpdate = true;
            geometry.computeVertexNormals();
            geometry.computeBoundingBox();
            geometry.computeBoundingSphere();
            geometry.userData.gutterCompression = 0.012;
            geometry.userData.pageSignatures = 6;
            return geometry;
          }

          function makeSpineTexture(book) {
            const spineCanvas = document.createElement("canvas");
            spineCanvas.width = 384;
            spineCanvas.height = 1536;
            const ctx = spineCanvas.getContext("2d");
            const random = seededRandom(hashSeed(`${book.id}-spine-cloth`) + book.seed);
            ctx.fillStyle = book.color;
            ctx.fillRect(0, 0, spineCanvas.width, spineCanvas.height);

            const shade = ctx.createLinearGradient(0, 0, spineCanvas.width, 0);
            shade.addColorStop(0, "rgba(0,0,0,0.2)");
            shade.addColorStop(0.14, "rgba(255,255,255,0.055)");
            shade.addColorStop(0.62, "rgba(255,255,255,0.012)");
            shade.addColorStop(1, "rgba(0,0,0,0.16)");
            ctx.fillStyle = shade;
            ctx.fillRect(0, 0, spineCanvas.width, spineCanvas.height);

            for (let thread = 0; thread < 1900; thread += 1) {
              const x = random() * spineCanvas.width;
              const y = random() * spineCanvas.height;
              const vertical = random() > 0.42;
              ctx.strokeStyle = random() > 0.5
                ? `rgba(255,255,255,${0.018 + random() * 0.038})`
                : `rgba(0,0,0,${0.018 + random() * 0.032})`;
              ctx.lineWidth = 0.45 + random() * 0.7;
              ctx.beginPath();
              ctx.moveTo(x, y);
              ctx.lineTo(
                vertical ? x + (random() - 0.5) * 1.2 : x + 8 + random() * 28,
                vertical ? y + 8 + random() * 34 : y + (random() - 0.5) * 1.2
              );
              ctx.stroke();
            }

            const bottomShade = ctx.createLinearGradient(
              0,
              spineCanvas.height * 0.82,
              0,
              spineCanvas.height
            );
            bottomShade.addColorStop(0, "rgba(0,0,0,0)");
            bottomShade.addColorStop(1, "rgba(0,0,0,0.12)");
            ctx.fillStyle = bottomShade;
            ctx.fillRect(0, 0, spineCanvas.width, spineCanvas.height);

            return configureCanvasTexture(
              new THREE.CanvasTexture(spineCanvas),
              { anisotropy: 16 }
            );
          }

          function makeSpineFoilTexture(book) {
            const foilCanvas = document.createElement("canvas");
            foilCanvas.width = 384;
            foilCanvas.height = 1536;
            const ctx = foilCanvas.getContext("2d");

            ctx.clearRect(0, 0, foilCanvas.width, foilCanvas.height);
            ctx.fillStyle = "#ffffff";
            ctx.strokeStyle = "#ffffff";
            ctx.lineWidth = 2.4;
            ctx.strokeRect(34, 38, foilCanvas.width - 68, foilCanvas.height - 76);

            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.font = '500 24px Inter, "Helvetica Neue", Arial, sans-serif';
            ctx.letterSpacing = "5px";
            ctx.fillText(book.roman, foilCanvas.width * 0.5, 118);

            ctx.save();
            ctx.translate(foilCanvas.width * 0.5, foilCanvas.height * 0.5);
            ctx.rotate(Math.PI / 2);
            ctx.font = `400 ${book.title.length > 10 ? 58 : 68}px "Iowan Old Style", Baskerville, Georgia, serif`;
            ctx.letterSpacing = "0px";
            ctx.fillText(book.title, 0, 0);
            ctx.restore();

            ctx.beginPath();
            ctx.arc(foilCanvas.width * 0.5, foilCanvas.height - 120, 24, 0, Math.PI * 2);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(foilCanvas.width * 0.5 - 24, foilCanvas.height - 120);
            ctx.lineTo(foilCanvas.width * 0.5 + 24, foilCanvas.height - 120);
            ctx.stroke();

            return configureCanvasTexture(new THREE.CanvasTexture(foilCanvas));
          }

          function makeBackCoverTexture(book) {
            const backCanvas = document.createElement("canvas");
            backCanvas.width = 768;
            backCanvas.height = 1152;
            const ctx = backCanvas.getContext("2d");
            const random = seededRandom(hashSeed(`${book.id}-back-cloth`) + book.seed);

            ctx.fillStyle = book.color;
            ctx.fillRect(0, 0, backCanvas.width, backCanvas.height);

            const edgeShade = ctx.createLinearGradient(0, 0, backCanvas.width, 0);
            edgeShade.addColorStop(0, "rgba(0,0,0,0.15)");
            edgeShade.addColorStop(0.05, "rgba(255,255,255,0.028)");
            edgeShade.addColorStop(0.84, "rgba(255,255,255,0)");
            edgeShade.addColorStop(1, "rgba(0,0,0,0.11)");
            ctx.fillStyle = edgeShade;
            ctx.fillRect(0, 0, backCanvas.width, backCanvas.height);

            for (let thread = 0; thread < 2600; thread += 1) {
              const x = random() * backCanvas.width;
              const y = random() * backCanvas.height;
              const length = 5 + random() * 30;
              ctx.strokeStyle = random() > 0.5
                ? `rgba(255,255,255,${0.018 + random() * 0.03})`
                : `rgba(0,0,0,${0.016 + random() * 0.028})`;
              ctx.lineWidth = 0.45 + random() * 0.65;
              ctx.beginPath();
              ctx.moveTo(x, y);
              ctx.lineTo(x + length, y + (random() - 0.5) * 1.5);
              ctx.stroke();
            }

            const vignette = ctx.createRadialGradient(
              backCanvas.width * 0.62,
              backCanvas.height * 0.38,
              20,
              backCanvas.width * 0.62,
              backCanvas.height * 0.38,
              backCanvas.width * 0.75
            );
            vignette.addColorStop(0, "rgba(255,255,255,0.03)");
            vignette.addColorStop(1, "rgba(0,0,0,0.09)");
            ctx.fillStyle = vignette;
            ctx.fillRect(0, 0, backCanvas.width, backCanvas.height);

            return configureCanvasTexture(new THREE.CanvasTexture(backCanvas));
          }

          function makeBackFoilTexture(book) {
            const foilCanvas = document.createElement("canvas");
            foilCanvas.width = 768;
            foilCanvas.height = 1152;
            const ctx = foilCanvas.getContext("2d");

            ctx.clearRect(0, 0, foilCanvas.width, foilCanvas.height);
            ctx.fillStyle = "#ffffff";
            ctx.strokeStyle = "#ffffff";
            ctx.textAlign = "left";
            ctx.textBaseline = "alphabetic";

            ctx.font = '500 16px Inter, "Helvetica Neue", Arial, sans-serif';
            ctx.letterSpacing = "3px";
            ctx.fillText(`THE LIST  /  ${book.roman}`, 68, 82);
            ctx.globalAlpha = 0.72;
            ctx.fillRect(68, 108, 176, 2);
            ctx.globalAlpha = 1;

            ctx.lineWidth = 1.5;
            for (let ring = 0; ring < 5; ring += 1) {
              ctx.globalAlpha = 0.24 - ring * 0.032;
              ctx.beginPath();
              ctx.arc(548, 374, 74 + ring * 38, 0, Math.PI * 2);
              ctx.stroke();
            }
            ctx.globalAlpha = 1;
            ctx.beginPath();
            ctx.moveTo(348, 374);
            ctx.lineTo(704, 374);
            ctx.moveTo(548, 174);
            ctx.lineTo(548, 574);
            ctx.stroke();

            ctx.font = `400 ${book.title.length > 10 ? 52 : 62}px "Iowan Old Style", Baskerville, Georgia, serif`;
            ctx.letterSpacing = "0px";
            ctx.fillText(book.title, 68, 956);
            ctx.font = '500 15px Inter, "Helvetica Neue", Arial, sans-serif';
            ctx.letterSpacing = "2.6px";
            ctx.fillText(book.discipline.toUpperCase(), 70, 1004);
            ctx.globalAlpha = 0.68;
            ctx.fillRect(68, 1040, 632, 1.5);
            ctx.globalAlpha = 1;
            ctx.textAlign = "right";
            ctx.fillText("AN IMAGINED EDITION", 700, 1080);

            return configureCanvasTexture(new THREE.CanvasTexture(foilCanvas));
          }

          function createMesh(geometry, material, name, cast = true, receive = true) {
            const mesh = new THREE.Mesh(geometry, material);
            mesh.name = name;
            mesh.castShadow = cast;
            mesh.receiveShadow = receive;
            return mesh;
          }

          function addTurnIns(pivot, book, side, width, height, insideZ, material) {
            const stripDepth = 0.002;
            const border = 0.018;
            const longWidth = width - border * 0.7;
            const longHeight = height - border * 2.2;
            const definitions = [
              ["head", width * 0.5, height * 0.5 - border * 0.56, longWidth, border, stripDepth],
              ["tail", width * 0.5, -height * 0.5 + border * 0.56, longWidth, border, stripDepth],
              ["spine", border * 0.56, 0, border, longHeight, stripDepth],
              ["fore", width - border * 0.56, 0, border, longHeight, stripDepth]
            ];

            definitions.forEach(([edge, x, y, stripWidth, stripHeight, depth]) => {
              const strip = createMesh(
                shared.box,
                material,
                `${book.id}-${side}-turn-in-${edge}`,
                false,
                true
              );
              strip.scale.set(stripWidth, stripHeight, depth);
              strip.position.set(x, y, insideZ);
              pivot.add(strip);
            });
          }

          function createBookRig(book, index) {
            const root = new THREE.Group();
            root.name = `book-${book.id}`;
            root.userData.index = index;

            const motion = new THREE.Group();
            motion.name = `${book.id}-motion`;
            root.add(motion);

            const width = book.width;
            const height = book.height;
            const depth = book.depth;
            const board = 0.032;
            const coverRadius = 0.0045;
            const pageRadius = 0.0025;
            const spineRadius = 0.0015;
            const spineBoardThickness = 0.014;
            const spineWidth = 0.082;
            const pageWidth = width - 0.074;
            const pageHeight = height - 0.068;
            const pageDepth = depth - 0.026;

            const coverTexture = makeCoverTexture(book);
            const foilTexture = makeFoilTexture(book);
            const clothBumpTexture = makeClothBumpTexture(book);
            const clothSurfaceMaps = makeClothSurfaceMaps(book);
            const paperFaceTexture = makePaperFaceTexture(book);
            const interiorPageTextures = makeInteriorPageTextures(book);
            const endpaperTexture = makeEndpaperTexture(book);
            const pageEdgeTextures = makePageEdgeTextures(book);
            const spineTexture = makeSpineTexture(book);
            const spineFoilTexture = makeSpineFoilTexture(book);
            const backCoverTexture = makeBackCoverTexture(book);
            const backFoilTexture = makeBackFoilTexture(book);
            const foilEmbossTexture = makeEmbossMap(foilTexture, `${book.id}-front-foil-emboss`);
            const spineEmbossTexture = makeEmbossMap(spineFoilTexture, `${book.id}-spine-foil-emboss`);
            const backEmbossTexture = makeEmbossMap(backFoilTexture, `${book.id}-back-foil-emboss`);
            const cloth = new THREE.MeshPhysicalMaterial({
              color: book.color,
              normalMap: clothSurfaceMaps.normal,
              normalScale: new THREE.Vector2(0.34, 0.34),
              roughnessMap: clothSurfaceMaps.roughness,
              roughness: 0.98,
              metalness: 0.02,
              bumpMap: clothBumpTexture,
              bumpScale: 0.0045,
              sheen: 0.34,
              sheenRoughness: 0.76,
              sheenColor: new THREE.Color(book.foil),
              transparent: true
            });
            const coverArt = new THREE.MeshPhysicalMaterial({
              map: coverTexture,
              normalMap: clothSurfaceMaps.normal,
              normalScale: new THREE.Vector2(0.28, 0.28),
              roughnessMap: clothSurfaceMaps.roughness,
              bumpMap: clothBumpTexture,
              bumpScale: 0.0035,
              roughness: 0.92,
              metalness: 0.035,
              clearcoat: 0.06,
              clearcoatRoughness: 0.72,
              sheen: 0.26,
              sheenRoughness: 0.78,
              transparent: true
            });
            const foilArt = new THREE.MeshPhysicalMaterial({
              color: book.foil,
              map: foilTexture,
              alphaMap: foilTexture,
              bumpMap: foilEmbossTexture,
              bumpScale: 0.016,
              roughness: book.id === "cursor" ? 0.22 : 0.2,
              metalness: book.id === "cursor" ? 0.34 : 0.94,
              clearcoat: 0.18,
              clearcoatRoughness: 0.12,
              transparent: true,
              depthWrite: false,
              polygonOffset: true,
              polygonOffsetFactor: -2
            });
            const spineArt = new THREE.MeshPhysicalMaterial({
              map: spineTexture,
              normalMap: clothSurfaceMaps.normal,
              normalScale: new THREE.Vector2(0.3, 0.3),
              roughnessMap: clothSurfaceMaps.roughness,
              bumpMap: clothBumpTexture,
              bumpScale: 0.004,
              roughness: 0.95,
              metalness: 0.025,
              sheen: 0.27,
              sheenRoughness: 0.78,
              transparent: true,
              side: THREE.DoubleSide
            });
            const spineFoilArt = new THREE.MeshPhysicalMaterial({
              color: book.foil,
              map: spineFoilTexture,
              alphaMap: spineFoilTexture,
              bumpMap: spineEmbossTexture,
              bumpScale: 0.017,
              roughness: 0.19,
              metalness: 0.92,
              clearcoat: 0.16,
              clearcoatRoughness: 0.13,
              transparent: true,
              depthWrite: false,
              polygonOffset: true,
              polygonOffsetFactor: -2,
              side: THREE.DoubleSide
            });
            const backArt = new THREE.MeshPhysicalMaterial({
              map: backCoverTexture,
              normalMap: clothSurfaceMaps.normal,
              normalScale: new THREE.Vector2(0.28, 0.28),
              roughnessMap: clothSurfaceMaps.roughness,
              bumpMap: clothBumpTexture,
              bumpScale: 0.0035,
              roughness: 0.96,
              metalness: 0.025,
              sheen: 0.25,
              sheenRoughness: 0.8,
              transparent: true,
              side: THREE.DoubleSide
            });
            const backFoilArt = new THREE.MeshPhysicalMaterial({
              color: book.foil,
              map: backFoilTexture,
              alphaMap: backFoilTexture,
              bumpMap: backEmbossTexture,
              bumpScale: 0.016,
              roughness: 0.21,
              metalness: 0.9,
              clearcoat: 0.14,
              clearcoatRoughness: 0.14,
              transparent: true,
              depthWrite: false,
              polygonOffset: true,
              polygonOffsetFactor: -2,
              side: THREE.DoubleSide
            });
            const endpaperMaterial = new THREE.MeshPhysicalMaterial({
              color: new THREE.Color(book.palette.paperPale).lerp(new THREE.Color(0xf2ead8), 0.5),
              map: endpaperTexture,
              bumpMap: paperFaceTexture,
              bumpScale: 0.0018,
              roughness: 0.94,
              metalness: 0,
              sheen: 0.025,
              sheenRoughness: 1,
              side: THREE.DoubleSide,
              transparent: true
            });
            const foreEdgeMaterial = new THREE.MeshPhysicalMaterial({
              color: 0xffffff,
              map: pageEdgeTextures.fore,
              bumpMap: pageEdgeTextures.fore,
              bumpScale: 0.0022,
              roughness: 0.93,
              metalness: 0,
              sheen: 0.018,
              sheenRoughness: 1,
              side: THREE.DoubleSide,
              transparent: true
            });
            const headTailEdgeMaterial = new THREE.MeshPhysicalMaterial({
              color: 0xffffff,
              map: pageEdgeTextures.headTail,
              bumpMap: pageEdgeTextures.headTail,
              bumpScale: 0.0015,
              roughness: 0.94,
              metalness: 0,
              sheen: 0.014,
              sheenRoughness: 1,
              side: THREE.DoubleSide,
              transparent: true
            });
            const grooveMaterial = new THREE.MeshPhysicalMaterial({
              color: new THREE.Color(book.color).multiplyScalar(0.42),
              roughness: 0.9,
              metalness: 0,
              bumpMap: clothBumpTexture,
              bumpScale: 0.006,
              side: THREE.DoubleSide,
              transparent: true
            });
            const pageMaterial = createFadeMaterial(shared.page);
            const headbandMaterial = createFadeMaterial(shared.headband);
            const interiorPageMaterials = interiorPageTextures.map((texture) => {
              const material = createFadeMaterial(shared.pageSheet);
              material.map = texture;
              material.bumpMap = paperFaceTexture;
              material.bumpScale = 0.0012;
              material.roughness = 0.96;
              material.side = THREE.FrontSide;
              material.needsUpdate = true;
              return material;
            });
            const blankPageMaterial = createFadeMaterial(shared.pageSheet);
            blankPageMaterial.map = paperFaceTexture;
            blankPageMaterial.bumpMap = paperFaceTexture;
            blankPageMaterial.bumpScale = 0.0012;
            blankPageMaterial.roughness = 0.96;
            blankPageMaterial.side = THREE.FrontSide;
            blankPageMaterial.needsUpdate = true;
            const signatureMaterial = new THREE.MeshPhysicalMaterial({
              color: new THREE.Color(0x8d816f).lerp(new THREE.Color(book.palette.paperPale), 0.34),
              roughness: 0.98,
              metalness: 0,
              transparent: true
            });
            const ribbonMaterial = new THREE.MeshPhysicalMaterial({
              color: new THREE.Color(book.foil).lerp(new THREE.Color(book.color), 0.28),
              roughness: 0.62,
              metalness: 0.08,
              sheen: 0.36,
              sheenRoughness: 0.68,
              side: THREE.DoubleSide,
              transparent: true
            });

            pageMaterial.map = paperFaceTexture;
            pageMaterial.bumpMap = paperFaceTexture;
            pageMaterial.bumpScale = 0.0014;
            pageMaterial.roughness = 0.95;
            pageMaterial.needsUpdate = true;

            const coverGeometry = new RoundedBoxGeometry(
              width,
              height,
              board,
              2,
              coverRadius
            );
            const pageGeometry = createPageBlockGeometry(
              pageWidth,
              pageHeight,
              pageDepth,
              pageRadius
            );
            const coverSurfaceGeometry = createRoundedPlaneGeometry(
              width - 0.007,
              height - 0.007,
              0.0035
            );
            const endpaperGeometry = createRoundedPlaneGeometry(
              width - 0.045,
              height - 0.045,
              0.003
            );

            root.userData.construction = {
              board,
              coverRadius,
              pageRadius,
              spineRadius,
              spineBoardThickness,
              spineProfile: "flat",
              spineFoilLayered: true,
              backSurfaceLayered: true,
              clothPbrMaps: true,
              foilEmbossed: true,
              interiorPageDesigns: interiorPageTextures.length,
              flexiblePageSegments: FLEXIBLE_PAGE_SEGMENTS,
              clothLikePageDeformation: true,
              turnInStrips: 8,
              ribbonBookmark: true,
              pageSignatures: pageGeometry.userData.pageSignatures,
              gutterCompression: pageGeometry.userData.gutterCompression,
              coverArtInset: 0.007,
              coverOverhangX: (width - pageWidth) * 0.5,
              coverOverhangY: (height - pageHeight) * 0.5
            };

            const pageBlock = createMesh(pageGeometry, pageMaterial, `${book.id}-page-block`);
            pageBlock.position.x = 0.018;
            motion.add(pageBlock);

            const backPivot = new THREE.Group();
            backPivot.name = `${book.id}-back-cover-pivot`;
            backPivot.position.set(-width * 0.5, 0, -depth * 0.5 - board * 0.5);
            const backCover = createMesh(coverGeometry, cloth, `${book.id}-back-cover`);
            backCover.position.x = width * 0.5;
            backPivot.add(backCover);

            const backPlane = createMesh(
              coverSurfaceGeometry,
              backArt,
              `${book.id}-back-cover-art`,
              false,
              false
            );
            backPlane.position.set(width * 0.5, 0, -board * 0.55);
            backPlane.rotation.y = Math.PI;
            backPivot.add(backPlane);

            const backFoilPlane = createMesh(
              coverSurfaceGeometry,
              backFoilArt,
              `${book.id}-back-foil-art`,
              false,
              false
            );
            backFoilPlane.position.set(width * 0.5, 0, -board * 0.605);
            backFoilPlane.rotation.y = Math.PI;
            backPivot.add(backFoilPlane);

            const backEndpaper = createMesh(
              endpaperGeometry,
              endpaperMaterial,
              `${book.id}-back-endpaper`,
              false,
              true
            );
            backEndpaper.position.set(width * 0.5, 0, board * 0.515);
            backPivot.add(backEndpaper);
            addTurnIns(
              backPivot,
              book,
              "back",
              width,
              height,
              board * 0.53,
              cloth
            );

            const backGroove = createMesh(
              shared.plane,
              grooveMaterial,
              `${book.id}-back-hinge-groove`,
              false,
              false
            );
            backGroove.scale.set(0.012, height * 0.94, 1);
            backGroove.position.set(0.038, 0, -board * 0.535);
            backGroove.rotation.y = Math.PI;
            backPivot.add(backGroove);
            motion.add(backPivot);

            const frontPivot = new THREE.Group();
            frontPivot.name = `${book.id}-front-cover-pivot`;
            frontPivot.position.set(-width * 0.5, 0, depth * 0.5 + board * 0.5);
            const frontCover = createMesh(coverGeometry, cloth, `${book.id}-front-cover`);
            frontCover.position.x = width * 0.5;
            frontPivot.add(frontCover);

            const coverPlane = createMesh(
              coverSurfaceGeometry,
              coverArt,
              `${book.id}-cover-art`,
              false,
              false
            );
            coverPlane.position.set(width * 0.5, 0, board * 0.55);
            frontPivot.add(coverPlane);

            const foilPlane = createMesh(
              coverSurfaceGeometry,
              foilArt,
              `${book.id}-foil-art`,
              false,
              false
            );
            foilPlane.position.set(width * 0.5, 0, board * 0.605);
            foilPlane.visible = false;
            frontPivot.add(foilPlane);

            const frontEndpaper = createMesh(
              endpaperGeometry,
              endpaperMaterial,
              `${book.id}-front-endpaper`,
              false,
              true
            );
            frontEndpaper.position.set(width * 0.5, 0, -board * 0.515);
            frontEndpaper.rotation.y = Math.PI;
            frontPivot.add(frontEndpaper);
            addTurnIns(
              frontPivot,
              book,
              "front",
              width,
              height,
              -board * 0.53,
              cloth
            );

            const frontGroove = createMesh(
              shared.plane,
              grooveMaterial,
              `${book.id}-front-hinge-groove`,
              false,
              false
            );
            frontGroove.scale.set(0.012, height * 0.94, 1);
            frontGroove.position.set(0.038, 0, board * 0.655);
            frontPivot.add(frontGroove);
            motion.add(frontPivot);

            const pagePivots = [];
            const pageSurfaces = [];
            for (let pageIndex = 0; pageIndex < 6; pageIndex += 1) {
              const leafOrder = 5 - pageIndex;
              const frontPageMaterial = leafOrder < 4
                ? interiorPageMaterials[leafOrder * 2]
                : blankPageMaterial;
              const backPageMaterial = leafOrder < 4
                ? interiorPageMaterials[leafOrder * 2 + 1]
                : blankPageMaterial;
              const pagePivot = new THREE.Group();
              pagePivot.name = `${book.id}-page-${pageIndex}`;
              pagePivot.position.set(
                -width * 0.5 + spineWidth * 0.65,
                0,
                pageDepth * 0.5 + 0.0015 + pageIndex * 0.0015
              );
              pagePivot.userData.restZ = pagePivot.position.z;
              pagePivot.userData.turnedZ = depth * 0.5 + board + 0.004 + leafOrder * 0.0015;
              const frontPageGeometry = new THREE.PlaneGeometry(
                1,
                1,
                FLEXIBLE_PAGE_SEGMENTS,
                FLEXIBLE_PAGE_VERTICAL_SEGMENTS
              );
              const backPageGeometry = new THREE.PlaneGeometry(
                1,
                1,
                FLEXIBLE_PAGE_SEGMENTS,
                FLEXIBLE_PAGE_VERTICAL_SEGMENTS
              );
              const visiblePageWidth = pageWidth - spineWidth * 0.42;
              const frontPage = createMesh(
                frontPageGeometry,
                frontPageMaterial,
                `${book.id}-page-sheet-${pageIndex}-front`,
                false,
                true
              );
              frontPage.scale.set(visiblePageWidth, pageHeight - 0.014, 1);
              frontPage.position.set(visiblePageWidth * 0.5, 0, 0.00022);
              pagePivot.add(frontPage);
              pageSurfaces.push(frontPage);

              const backPage = createMesh(
                backPageGeometry,
                backPageMaterial,
                `${book.id}-page-sheet-${pageIndex}-back`,
                false,
                true
              );
              backPage.scale.set(visiblePageWidth, pageHeight - 0.014, 1);
              backPage.position.set(visiblePageWidth * 0.5, 0, -0.00022);
              backPage.rotation.y = Math.PI;
              pagePivot.add(backPage);
              pageSurfaces.push(backPage);
              pagePivot.userData.flex = {
                curve: 0,
                curveVelocity: 0,
                twist: 0,
                twistVelocity: 0,
                surfaces: [
                  {
                    geometry: frontPageGeometry,
                    position: frontPageGeometry.attributes.position,
                    base: Float32Array.from(frontPageGeometry.attributes.position.array),
                    direction: 1
                  },
                  {
                    geometry: backPageGeometry,
                    position: backPageGeometry.attributes.position,
                    base: Float32Array.from(backPageGeometry.attributes.position.array),
                    direction: -1
                  }
                ]
              };
              motion.add(pagePivot);
              pagePivots.push(pagePivot);
            }

            const spineGeometry = new RoundedBoxGeometry(
              spineBoardThickness,
              height - 0.012,
              depth + board * 1.88,
              1,
              spineRadius
            );
            const spine = createMesh(spineGeometry, spineArt, `${book.id}-flat-spine`);
            spine.position.x = -width * 0.5 - spineBoardThickness * 0.35;
            spine.userData.profile = "flat";
            motion.add(spine);

            const spineFoil = createMesh(
              shared.plane,
              spineFoilArt,
              `${book.id}-spine-foil`,
              false,
              false
            );
            spineFoil.scale.set(depth + board * 1.82, height - 0.018, 1);
            spineFoil.rotation.y = -Math.PI * 0.5;
            spineFoil.position.set(
              spine.position.x - spineBoardThickness * 0.505,
              0,
              0
            );
            motion.add(spineFoil);

            const spineLining = createMesh(
              new RoundedBoxGeometry(
                spineWidth * 0.68,
                height - 0.056,
                Math.max(0.045, pageDepth - 0.008),
                1,
                0.0015
              ),
              endpaperMaterial,
              `${book.id}-spine-lining`
            );
            spineLining.position.set(-width * 0.5 + spineWidth * 0.38, 0, 0);
            motion.add(spineLining);

            [-1, 1].forEach((direction) => {
              const headbandGeometry = new THREE.CylinderGeometry(
                0.012,
                0.012,
                pageDepth * 0.88,
                12,
                1,
                false
              );
              const headband = createMesh(
                headbandGeometry,
                headbandMaterial,
                `${book.id}-headband-${direction}`
              );
              headband.rotation.x = Math.PI * 0.5;
              headband.position.set(
                -pageWidth * 0.5 + 0.046,
                direction * (pageHeight * 0.5 - 0.004),
                0
              );
              motion.add(headband);
            });

            const ribbonGeometry = createRoundedPlaneGeometry(
              0.034,
              pageHeight * 0.76,
              0.002
            );
            const ribbon = createMesh(
              ribbonGeometry,
              ribbonMaterial,
              `${book.id}-ribbon-bookmark`,
              false,
              true
            );
            ribbon.position.set(
              -pageWidth * 0.5 + 0.09 + (book.seed % 3) * 0.018,
              -pageHeight * 0.17,
              pageDepth * 0.5 + 0.003
            );
            ribbon.rotation.z = (book.seed % 2 ? -1 : 1) * 0.014;
            motion.add(ribbon);

            for (let signatureIndex = 0; signatureIndex < 6; signatureIndex += 1) {
              const signature = createMesh(
                shared.box,
                signatureMaterial,
                `${book.id}-page-signature-${signatureIndex + 1}`,
                false,
                true
              );
              signature.scale.set(0.0035, 0.00135, pageDepth * 0.91);
              signature.position.set(
                0.018 + pageWidth * 0.5 + 0.001,
                -pageHeight * 0.5 + ((signatureIndex + 1) / 7) * pageHeight,
                0
              );
              motion.add(signature);
            }

            const foreEdge = createMesh(
              shared.plane,
              foreEdgeMaterial,
              `${book.id}-fore-edge`,
              false,
              true
            );
            foreEdge.scale.set(pageDepth * 0.94, pageHeight - 0.028, 1);
            foreEdge.rotation.y = Math.PI * 0.5;
            foreEdge.position.set(0.018 + pageWidth * 0.5 + 0.002, 0, 0);
            motion.add(foreEdge);

            [-1, 1].forEach((direction) => {
              const edge = createMesh(
                shared.plane,
                headTailEdgeMaterial,
                `${book.id}-${direction > 0 ? "head" : "tail"}-edge`,
                false,
                true
              );
              edge.scale.set(pageWidth - 0.035, pageDepth * 0.94, 1);
              edge.rotation.x = direction > 0 ? -Math.PI * 0.5 : Math.PI * 0.5;
              edge.position.set(
                0.018,
                direction * (pageHeight * 0.5 + 0.002),
                0
              );
              motion.add(edge);
            });

            const hitMaterial = new THREE.MeshBasicMaterial({
              transparent: true,
              opacity: 0,
              depthWrite: false
            });
            const hit = createMesh(shared.box, hitMaterial, `${book.id}-hit-target`, false, false);
            hit.scale.set(width * 1.34, height * 1.2, Math.max(depth * 4, 1));
            hit.position.set(-spineWidth * 0.18, 0, 0.12);
            hit.userData.index = index;
            motion.add(hit);
            hitTargets.push(hit);

            const contactShadowMaterial = new THREE.MeshBasicMaterial({
              color: new THREE.Color(book.palette.shelfDark),
              alphaMap: makeContactShadowTexture(),
              transparent: true,
              opacity: 0.24,
              depthWrite: false,
              side: THREE.DoubleSide
            });
            const contactShadow = createMesh(
              shared.plane,
              contactShadowMaterial,
              `${book.id}-contact-shadow`,
              false,
              false
            );
            contactShadow.scale.set(width * 1.22, depth * 2.05, 1);
            contactShadow.rotation.x = -Math.PI * 0.5;
            contactShadow.position.set(0, -height * 0.5 - 0.022, 0.025);
            root.add(contactShadow);

            return {
              data: book,
              root,
              motion,
              frontPivot,
              frontCover,
              pageBlock,
              pagePivots,
              pageSurfaces,
              pageGestureSurfaces: [...pageSurfaces, pageBlock],
              hit,
              coverTexture,
              foilTexture,
              clothBumpTexture,
              clothSurfaceMaps,
              paperFaceTexture,
              interiorPageTextures,
              endpaperTexture,
              pageEdgeTextures,
              spineTexture,
              spineFoilTexture,
              backCoverTexture,
              backFoilTexture,
              foilEmbossTexture,
              spineEmbossTexture,
              backEmbossTexture,
              contactShadow,
              opacity: 1,
              lastOffset: null,
              fadeMaterials: [
                cloth,
                coverArt,
                foilArt,
                spineArt,
                spineFoilArt,
                backArt,
                backFoilArt,
                endpaperMaterial,
                foreEdgeMaterial,
                headTailEdgeMaterial,
                grooveMaterial,
                pageMaterial,
                ...interiorPageMaterials,
                blankPageMaterial,
                headbandMaterial,
                signatureMaterial,
                ribbonMaterial
              ],
              materials: [
                cloth,
                coverArt,
                foilArt,
                spineArt,
                spineFoilArt,
                backArt,
                backFoilArt,
                endpaperMaterial,
                foreEdgeMaterial,
                headTailEdgeMaterial,
                grooveMaterial,
                pageMaterial,
                ...interiorPageMaterials,
                blankPageMaterial,
                headbandMaterial,
                signatureMaterial,
                ribbonMaterial,
                contactShadowMaterial,
                hitMaterial
              ],
              base: {
                width,
                height,
                depth
              }
            };
          }

          function getHeaderBottom() {
            const header = document.querySelector(".editorial-header");
            return header ? header.getBoundingClientRect().bottom : 0;
          }

          function configureResponsiveTargets() {
            isNarrow = viewWidth <= 880;
            const narrow = isNarrow;
            const aspect = viewWidth / Math.max(viewHeight, 1);
            const halfFovTan = Math.tan(THREE.MathUtils.degToRad(16));

            if (narrow) {
              // Frame roughly one book plus a peek of each neighbour, so a swipe
              // always has something to pull into view.
              spacing = 1.36;
              const visibleWidth = 2.65;
              const distance = clamp(visibleWidth / (2 * halfFovTan * aspect), 7.4, 11.5);
              shelfCameraPosition.set(0, 1.57 + distance * 0.052, distance);
              shelfCameraTarget.set(0, 1.57, 0);
              const browseHeight = browseUi.getBoundingClientRect().height || 150;
              heroViewOffset.x = 0;
              heroViewOffset.y = clamp((browseHeight - getHeaderBottom()) * 0.5, 0, 140);
            } else {
              spacing = 1.5;
              shelfCameraPosition.set(0, 1.92, 8.1);
              shelfCameraTarget.set(0, 1.55, 0);
              heroViewOffset.x = 0;
              heroViewOffset.y = 0;
            }

            inspectPosition.set(narrow ? 0 : -2.25, narrow ? 2.3 : 1.56, narrow ? 0.15 : 0);
            inspectCameraPosition.set(narrow ? 0 : -0.52, narrow ? 2.46 : 1.78, narrow ? 5.7 : 5.25);
            inspectCameraTarget.copy(inspectPosition);
            if (controls) {
              controls.enablePan = !narrow;
              controls.rotateSpeed = narrow ? 0.7 : 1;
            }

            if (narrow) {
              sheetHeight = detailPanel.getBoundingClientRect().height || viewHeight * 0.36;
              detailSafeWidth = viewWidth;
              const shiftUp = clamp((sheetHeight - getHeaderBottom()) * 0.5, 0, viewHeight * 0.4);
              detailOffsetClosed.x = 0;
              detailOffsetClosed.y = shiftUp;
              detailOffsetOpen.x = 0;
              detailOffsetOpen.y = shiftUp;
              return;
            }

            sheetHeight = 0;
            const panelBounds = detailPanel.getBoundingClientRect();
            const panelLeft = panelBounds.left > 0 ? panelBounds.left : viewWidth * 0.64;
            const gutter = clamp(viewWidth * 0.035, 32, 56);
            detailSafeWidth = Math.max(viewWidth * 0.42, panelLeft - gutter);
            const wideLayoutProgress = clamp((viewWidth - 820) / 620, 0, 1);
            const bookCenterRatio = THREE.MathUtils.lerp(0.55, 0.615, wideLayoutProgress);
            detailOffsetClosed.x = Math.max(0, viewWidth * 0.5 - detailSafeWidth * bookCenterRatio);
            detailOffsetClosed.y = 0;
            // An open spread is twice as wide, so centre it in the free column.
            detailOffsetOpen.x = Math.max(0, viewWidth * 0.5 - detailSafeWidth * 0.5);
            detailOffsetOpen.y = 0;
          }

          function getInspectScale(openAmount = 0) {
            if (!activeBook) return 0.82;
            const distance = Math.abs(inspectCameraPosition.z - inspectPosition.z);
            const worldHeight = 2 * distance * Math.tan(THREE.MathUtils.degToRad(camera.fov * 0.5));
            const pixelsPerWorld = viewHeight / Math.max(worldHeight, 0.001);
            const bookWidth = activeBook.base.width * pixelsPerWorld;
            const bookHeight = activeBook.base.height * pixelsPerWorld;
            let closedScale;
            let openScale;

            if (isNarrow) {
              const usableHeight = Math.max(160, viewHeight - sheetHeight - getHeaderBottom() - 20);
              const heightFit = (usableHeight * 0.9) / bookHeight;
              closedScale = Math.min((viewWidth * 0.66) / bookWidth, heightFit);
              openScale = Math.min((viewWidth * 0.92) / (bookWidth * 2.06), heightFit);
              closedScale = clamp(closedScale, 0.3, 1.2);
              openScale = clamp(openScale, 0.26, 1.2);
            } else {
              closedScale = clamp((detailSafeWidth * 0.72) / (bookWidth * 1.16), 0.9, 1.32);
              openScale = clamp(
                Math.min(
                  (detailSafeWidth * 0.9) / (bookWidth * 2.08),
                  (viewHeight * 0.78) / bookHeight
                ),
                0.6,
                1.32
              );
            }
            return lerp(closedScale, openScale, clamp(openAmount, 0, 1));
          }

          function getDetailViewOffset(openAmount, target) {
            const amount = clamp(openAmount, 0, 1);
            target.x = lerp(detailOffsetClosed.x, detailOffsetOpen.x, amount);
            target.y = lerp(detailOffsetClosed.y, detailOffsetOpen.y, amount);
            return target;
          }

          function getVisualOpenAmount(rig) {
            if (!rig) return 0;
            return clamp(rig.frontPivot.rotation.y / (-Math.PI + 0.055), 0, 1);
          }

          function applyViewOffset() {
            if (Math.abs(viewOffset.x) < 0.5 && Math.abs(viewOffset.y) < 0.5) {
              if (camera.view?.enabled) camera.clearViewOffset();
              return;
            }
            camera.setViewOffset(
              viewWidth,
              viewHeight,
              viewOffset.x,
              viewOffset.y,
              viewWidth,
              viewHeight
            );
          }

          function createWoodTexture(repeatX, repeatY, rotation = 0) {
            if (!woodTextureReady) return null;
            const texture = new THREE.Texture(woodTextureImage);
            texture.name = "editorial-walnut";
            texture.colorSpace = THREE.SRGBColorSpace;
            texture.wrapS = THREE.RepeatWrapping;
            texture.wrapT = THREE.RepeatWrapping;
            texture.repeat.set(repeatX, repeatY);
            texture.center.set(0.5, 0.5);
            texture.rotation = rotation;
            texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
            texture.needsUpdate = true;
            return texture;
          }

          function applyWoodTexture() {
            if (!woodTextureReady || !renderer) return;

            const woodMap = createWoodTexture(7, 1.65, Math.PI * 0.5);
            const darkWoodMap = woodMap?.clone() || null;

            if (darkWoodMap) {
              darkWoodMap.name = "editorial-walnut-dark";
              darkWoodMap.needsUpdate = true;
            }

            shared.walnut.map = woodMap;
            shared.walnut.needsUpdate = true;
            shared.walnutDark.map = darkWoodMap;
            shared.walnutDark.needsUpdate = true;
            requestFrame();
          }

          function addRoom() {
            const floor = createMesh(shared.plane, new THREE.MeshStandardMaterial({
              color: 0xd8c8aa,
              roughness: 0.92,
              metalness: 0
            }), "paper-floor", false, true);
            floor.scale.set(30, 20, 1);
            floor.rotation.x = -Math.PI * 0.5;
            floor.position.y = -0.02;
            scene.add(floor);

            const back = createMesh(shared.plane, new THREE.MeshStandardMaterial({
              color: 0xe9dfcb,
              roughness: 1,
              metalness: 0
            }), "paper-backdrop", false, true);
            back.scale.set(28, 14, 1);
            back.position.set(0, 5.5, -3.3);
            scene.add(back);

            const shelf = createMesh(shared.box, shared.walnut, "walnut-shelf");
            shelf.scale.set(17, 0.28, 1.08);
            shelf.position.set(0, 0.33, -0.03);
            shelfStage.add(shelf);

            const shelfLip = createMesh(shared.box, shared.walnutDark, "walnut-shelf-lip");
            shelfLip.scale.set(17.05, 0.075, 1.14);
            shelfLip.position.set(0, 0.205, 0.02);
            shelfStage.add(shelfLip);

            const backRail = createMesh(shared.box, shared.walnut, "walnut-back-rail");
            backRail.scale.set(17, 0.17, 0.2);
            backRail.position.set(0, 0.68, -0.52);
            shelfStage.add(backRail);

            [-7.65, 7.65].forEach((x, index) => {
              const upright = createMesh(shared.box, shared.walnutDark, `shelf-upright-${index}`);
              upright.scale.set(0.2, 3.8, 0.72);
              upright.position.set(x, 2.05, -0.28);
              shelfStage.add(upright);
            });

            const shadowStrip = createMesh(shared.plane, new THREE.MeshBasicMaterial({
              color: 0x2f1d13,
              alphaMap: makeContactShadowTexture(),
              transparent: true,
              opacity: 0.22,
              depthWrite: false
            }), "shelf-contact-shadow", false, false);
            shadowStrip.scale.set(16, 0.85, 1);
            shadowStrip.rotation.x = -Math.PI * 0.5;
            shadowStrip.position.set(0, 0.49, 0.06);
            shelfStage.add(shadowStrip);

            roomMaterials.floor = floor.material;
            roomMaterials.wall = back.material;
            roomMaterials.shelf = shared.walnut;
            roomMaterials.shelfDark = shared.walnutDark;
            roomMaterials.shadow = shadowStrip.material;
          }

          function addLights() {
            roomLights.hemisphere = new THREE.HemisphereLight(0xfff8e8, 0x5b4030, 0.56);
            scene.add(roomLights.hemisphere);

            const key = new THREE.DirectionalLight(0xffe8c2, 1.42);
            key.name = "shadow-key";
            key.position.set(-4.6, 7.4, 5.8);
            key.castShadow = true;
            const shadowSize = viewWidth <= 880 ? 1024 : 2048;
            key.shadow.mapSize.set(shadowSize, shadowSize);
            key.shadow.camera.left = -6;
            key.shadow.camera.right = 6;
            key.shadow.camera.top = 6;
            key.shadow.camera.bottom = -1.5;
            key.shadow.camera.near = 1;
            key.shadow.camera.far = 18;
            key.shadow.bias = -0.00018;
            key.shadow.normalBias = 0.018;
            key.shadow.radius = 3.5;
            scene.add(key);
            roomLights.key = key;

            const softKey = new THREE.RectAreaLight(0xffe8c2, 5.4, 4.8, 5.6);
            softKey.name = "cloth-softbox";
            softKey.position.set(-3.2, 5.5, 4.6);
            softKey.lookAt(0, 1.45, 0);
            scene.add(softKey);
            roomLights.softKey = softKey;

            const fill = new THREE.DirectionalLight(0xd8e3e7, 0.3);
            fill.name = "cool-fill";
            fill.position.set(5.5, 3.6, 4.2);
            scene.add(fill);
            roomLights.fill = fill;

            const rim = new THREE.RectAreaLight(0xd5a45e, 3.45, 1.6, 4.8);
            rim.name = "foil-rake";
            rim.position.set(3.8, 3.6, -2.1);
            rim.lookAt(-0.2, 1.5, 0);
            scene.add(rim);
            roomLights.rim = rim;

            const backFill = new THREE.RectAreaLight(0xd8e3e7, 2.7, 3.8, 4.8);
            backFill.name = "back-cover-softbox";
            backFill.position.set(-1.8, 2.9, -4.5);
            backFill.lookAt(-0.1, 1.45, 0);
            scene.add(backFill);
            roomLights.backFill = backFill;

            const spineRake = new THREE.RectAreaLight(0xffe8c2, 1.9, 0.9, 4.6);
            spineRake.name = "spine-rake";
            spineRake.position.set(-4.6, 3.2, 1.1);
            spineRake.lookAt(-0.55, 1.5, 0);
            scene.add(spineRake);
            roomLights.spineRake = spineRake;

            const pageRake = new THREE.RectAreaLight(0xfff7e7, 2.15, 1.15, 3.8);
            pageRake.name = "page-edge-rake";
            pageRake.position.set(4.2, 4.8, 3.1);
            pageRake.lookAt(0.65, 1.55, 0);
            scene.add(pageRake);
            roomLights.pageRake = pageRake;
          }

          function addDust() {
            const dustCount = 110;
            const positions = new Float32Array(dustCount * 3);
            const random = seededRandom(20260728);
            for (let index = 0; index < dustCount; index += 1) {
              positions[index * 3] = (random() - 0.5) * 14;
              positions[index * 3 + 1] = 0.7 + random() * 4.7;
              positions[index * 3 + 2] = -1.7 + random() * 4;
            }
            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
            const material = new THREE.PointsMaterial({
              color: 0xc3a97b,
              size: 0.014,
              transparent: true,
              opacity: 0.3,
              depthWrite: false
            });
            const dust = new THREE.Points(geometry, material);
            dust.name = "paper-dust";
            dust.userData.isDust = true;
            scene.add(dust);
          }

          function buildMarkers() {
            BOOKS.forEach((book, index) => {
              const button = document.createElement("button");
              button.className = "marker";
              button.type = "button";
              button.role = "tab";
              button.setAttribute("aria-label", `Select volume ${index + 1}: ${book.title}`);
              button.setAttribute("aria-current", index === 0 ? "true" : "false");
              button.setAttribute("aria-selected", index === 0 ? "true" : "false");
              button.addEventListener("click", () => selectMarker(index, button));
              markers.append(button);
            });
          }

          function setThemeColorsImmediately() {
            roomMaterials.floor?.color.copy(themeTargets.floor);
            roomMaterials.wall?.color.copy(themeTargets.wall);
            roomMaterials.shelf?.color.copy(themeTargets.shelf);
            roomMaterials.shelfDark?.color.copy(themeTargets.shelfDark);
            roomMaterials.shadow?.color.copy(themeTargets.shadow);
            scene?.fog?.color.copy(themeTargets.fog);
            roomLights.hemisphere?.color.copy(themeTargets.hemisphere);
            roomLights.hemisphere?.groundColor.copy(themeTargets.hemisphereGround);
            roomLights.key?.color.copy(themeTargets.key);
            roomLights.softKey?.color.copy(themeTargets.key);
            roomLights.fill?.color.copy(themeTargets.fill);
            roomLights.rim?.color.copy(themeTargets.rim);
            roomLights.backFill?.color.copy(themeTargets.fill);
            roomLights.spineRake?.color.copy(themeTargets.key);
            roomLights.pageRake?.color.copy(themeTargets.hemisphere);
            themeMoving = false;
          }

          function applyBookTheme(book) {
            const palette = book.palette;
            const rootStyle = TL_ROOT.style;
            rootStyle.setProperty("--paper", palette.paper);
            rootStyle.setProperty("--paper-deep", palette.paperDeep);
            rootStyle.setProperty("--paper-pale", palette.paperPale);
            rootStyle.setProperty("--ink", palette.ink);
            rootStyle.setProperty("--ink-soft", palette.inkSoft);
            rootStyle.setProperty("--walnut", palette.shelf);
            rootStyle.setProperty("--walnut-deep", palette.shelfDark);
            rootStyle.setProperty("--rule", `color-mix(in srgb, ${palette.ink} 24%, transparent)`);
            rootStyle.setProperty("--accent", book.foil);
            document.querySelector('meta[name="theme-color"]')?.setAttribute("content", palette.paper);

            themeTargets.floor.set(palette.paperDeep);
            themeTargets.wall.set(palette.wall);
            themeTargets.shelf.set(palette.shelf);
            themeTargets.shelfDark.set(palette.shelfDark);
            themeTargets.shadow.set(palette.shelfDark);
            themeTargets.fog.set(palette.wall);
            themeTargets.hemisphere.set(palette.paperPale);
            themeTargets.hemisphereGround.set(palette.shelf);
            themeTargets.key.set(palette.light);
            themeTargets.fill.set(palette.fill);
            themeTargets.rim.set(book.foil);

            if (!themeInitialized || reducedMotion) {
              themeInitialized = true;
              setThemeColorsImmediately();
            } else {
              themeMoving = true;
              requestFrame();
            }
          }

          function updateTheme(delta) {
            if (!themeMoving) return false;
            const amount = 1 - Math.exp(-delta * 5.5);
            let largestGap = 0;
            const easeColor = (current, target) => {
              if (!current) return;
              const redGap = current.r - target.r;
              const greenGap = current.g - target.g;
              const blueGap = current.b - target.b;
              largestGap = Math.max(
                largestGap,
                redGap * redGap + greenGap * greenGap + blueGap * blueGap
              );
              current.lerp(target, amount);
            };

            easeColor(roomMaterials.floor?.color, themeTargets.floor);
            easeColor(roomMaterials.wall?.color, themeTargets.wall);
            easeColor(roomMaterials.shelf?.color, themeTargets.shelf);
            easeColor(roomMaterials.shelfDark?.color, themeTargets.shelfDark);
            easeColor(roomMaterials.shadow?.color, themeTargets.shadow);
            easeColor(scene?.fog?.color, themeTargets.fog);
            easeColor(roomLights.hemisphere?.color, themeTargets.hemisphere);
            easeColor(roomLights.hemisphere?.groundColor, themeTargets.hemisphereGround);
            easeColor(roomLights.key?.color, themeTargets.key);
            easeColor(roomLights.softKey?.color, themeTargets.key);
            easeColor(roomLights.fill?.color, themeTargets.fill);
            easeColor(roomLights.rim?.color, themeTargets.rim);
            easeColor(roomLights.backFill?.color, themeTargets.fill);
            easeColor(roomLights.spineRake?.color, themeTargets.key);
            easeColor(roomLights.pageRake?.color, themeTargets.hemisphere);

            if (largestGap < 0.0000025) {
              setThemeColorsImmediately();
            }
            return themeMoving;
          }

          function updateSelection(index, announce = false) {
            const nextIndex = mod(index, BOOKS.length);
            if (nextIndex === selectedIndex && !announce) return;
            selectedIndex = nextIndex;
            const book = BOOKS[selectedIndex];
            selectionTitle.textContent = book.title;
            selectionNote.textContent = book.note;
            counter.textContent = `${pad(selectedIndex + 1)} / ${pad(BOOKS.length)}`;
            paletteLabel.textContent = book.paletteLabel;
            inspectButton.setAttribute("aria-label", `Open ${book.title}`);
            applyBookTheme(book);

            [...markers.children].forEach((marker, markerIndex) => {
              const current = markerIndex === selectedIndex;
              marker.setAttribute("aria-current", current ? "true" : "false");
              marker.setAttribute("aria-selected", current ? "true" : "false");
              marker.tabIndex = current ? 0 : -1;
            });

            if (announce) {
              liveRegion.textContent = `Selected volume ${selectedIndex + 1} of ${BOOKS.length}: ${book.title}. ${book.note}`;
            }
          }

          function setSheetExpanded(expanded) {
            detailPanel.classList.toggle("is-expanded", expanded);
            sheetHandle.setAttribute("aria-expanded", String(expanded));
            sheetHandle.querySelector(".sheet-handle__label").textContent = expanded
              ? "Hide details"
              : "About this book";
            if (!expanded) detailPanel.scrollTop = 0;
            if (mode === "detail" || mode === "opening") {
              configureResponsiveTargets();
              requestFrame();
            }
          }

          // Descriptions mark titles of works with *asterisks*; show them in italics.
          function setRichText(element, text) {
            element.replaceChildren();
            String(text || "").split(/(\*[^*]+\*)/).forEach((part) => {
              if (!part) return;
              if (part.startsWith("*") && part.endsWith("*")) {
                const em = document.createElement("em");
                em.textContent = part.slice(1, -1);
                element.append(em);
              } else {
                element.append(document.createTextNode(part));
              }
            });
          }

          function populateDetail(book) {
            detailEyebrow.textContent = book.eyebrow || `Volume ${book.roman}`;
            detailTitle.textContent = book.title;
            detailBlurb.textContent = book.blurb || "";
            detailBlurb.hidden = !book.blurb;
            detailAuthor.textContent = `by ${book.author}`;
            window.TheList?.renderPicked(document.querySelector("#detail-picked"), book.pickedBy);
            const mark = document.querySelector("#detail-mark");
            if (mark) {
              mark.dataset.listKind = "books";
              mark.dataset.listId = book.id;
              window.TheList?.syncToggle(mark);
            }
            setRichText(detailDeck, book.description);
            detailDeck.hidden = !book.description;
            sheetHandle.hidden = !book.description;
          }

          function getSpreadLabels(book) {
            return [
              "Title page",
              `${book.chapters[0]} · Plate`,
              `${book.chapters[1]} · Notes`,
              `${book.chapters[2]} · System`,
              "Colophon"
            ];
          }

          function updatePageControls(announce = false) {
            const book = activeBook?.data || BOOKS[selectedIndex];
            const labels = getSpreadLabels(book);
            const interactionLocked = mode !== "detail" || !readingOpen;
            const previousDisabled = interactionLocked || currentSpread === 0;
            const nextDisabled = interactionLocked || currentSpread === SPREAD_COUNT - 1;

            previousPageButton.disabled = previousDisabled;
            nextPageButton.disabled = nextDisabled;
            pageLabel.textContent = readingOpen ? labels[currentSpread] : "Closed";
            pageCounter.textContent = readingOpen
              ? `${pad(currentSpread + 1)} / ${pad(SPREAD_COUNT)}`
              : "Click book to open";
            toggleBookButton.textContent = readingOpen ? "Close book" : "Open book";
            toggleBookButton.setAttribute("aria-pressed", String(readingOpen));
            detailMicrocopy.textContent = readingOpen
              ? "Drag pages · Drag cover to close · Background to orbit"
              : "Drag cover or click once to open · Background to orbit";
            previousPageButton.setAttribute(
              "aria-label",
              previousDisabled
                ? "Previous sample page"
                : `Previous sample page: ${labels[currentSpread - 1]}`
            );
            nextPageButton.setAttribute(
              "aria-label",
              nextDisabled
                ? "Next sample page"
                : `Next sample page: ${labels[currentSpread + 1]}`
            );

            if (announce && activeBook && readingOpen) {
              liveRegion.textContent = `Page ${currentSpread + 1} of ${SPREAD_COUNT}: ${labels[currentSpread]}.`;
            }
          }

          function setReadingOpen(open, announce = true) {
            if (mode !== "detail" || readingOpen === open) return;
            cancelPageDrag();
            readingOpen = open;
            if (!readingOpen) currentSpread = 0;
            canvas.classList.remove("has-page-hover", "has-closed-book-hover");
            updatePageControls(false);
            pointerDirty = true;

            if (announce && activeBook) {
              liveRegion.textContent = readingOpen
                ? `${activeBook.data.title} opened to its title page. Drag a page horizontally or use the arrow controls to read.`
                : `${activeBook.data.title} closed. Drag the cover, click the book, or use Open book to begin reading.`;
            }
            requestFrame();
          }

          function turnPage(direction) {
            if (mode !== "detail" || !readingOpen) return;
            const nextSpread = clamp(
              currentSpread + direction,
              0,
              SPREAD_COUNT - 1
            );
            if (nextSpread === currentSpread) return;
            currentSpread = nextSpread;
            updatePageControls(true);
            requestFrame();
          }

          function updateFlexiblePage(
            pagePivot,
            targetCurve,
            delta,
            immediate = false,
            targetTwist = 0
          ) {
            const flex = pagePivot.userData.flex;
            if (!flex) return;
            const settleImmediately = immediate || reducedMotion;
            const step = Math.min(delta, 0.033);
            let nextCurve = targetCurve;
            let nextTwist = targetTwist;

            if (settleImmediately) {
              flex.curveVelocity = 0;
              flex.twistVelocity = 0;
            } else {
              const curveAcceleration = (
                (targetCurve - flex.curve) * 178
                - flex.curveVelocity * 19
              );
              const twistAcceleration = (
                (targetTwist - flex.twist) * 210
                - flex.twistVelocity * 21
              );
              flex.curveVelocity = clamp(
                flex.curveVelocity + curveAcceleration * step,
                -1.8,
                1.8
              );
              flex.twistVelocity = clamp(
                flex.twistVelocity + twistAcceleration * step,
                -1.6,
                1.6
              );
              nextCurve = clamp(
                flex.curve + flex.curveVelocity * step,
                -0.025,
                0.19
              );
              nextTwist = clamp(
                flex.twist + flex.twistVelocity * step,
                -0.12,
                0.12
              );

              if (
                Math.abs(targetCurve - nextCurve) < 0.00002
                && Math.abs(flex.curveVelocity) < 0.0008
              ) {
                nextCurve = targetCurve;
                flex.curveVelocity = 0;
              }
              if (
                Math.abs(targetTwist - nextTwist) < 0.00002
                && Math.abs(flex.twistVelocity) < 0.0008
              ) {
                nextTwist = targetTwist;
                flex.twistVelocity = 0;
              }
            }

            if (
              !settleImmediately
              && Math.abs(nextCurve - flex.curve) < 0.00001
              && Math.abs(targetCurve - nextCurve) < 0.00001
              && Math.abs(nextTwist - flex.twist) < 0.00001
              && Math.abs(targetTwist - nextTwist) < 0.00001
            ) return;

            flex.curve = nextCurve;
            flex.twist = nextTwist;
            flex.surfaces.forEach((surface) => {
              const { position, base, direction, geometry } = surface;
              for (let vertex = 0; vertex < position.count; vertex += 1) {
                const offset = vertex * 3;
                const x = base[offset];
                const y = base[offset + 1];
                const u = x + 0.5;
                const mappedU = direction > 0 ? u : 1 - u;
                const arch = Math.sin(Math.PI * mappedU);
                const freeEdgeLift = mappedU * mappedU * 0.16;
                const shape = arch * 0.84 + freeEdgeLift;
                const diagonalTwist = (
                  nextTwist
                  * y
                  * Math.pow(mappedU, 1.35)
                );
                const softRipple = (
                  nextTwist
                  * Math.sin(mappedU * Math.PI * 2)
                  * (1 - Math.min(1, Math.abs(y) * 1.65))
                  * 0.09
                );
                const z = (
                  nextCurve * shape * (1 + y * 0.14)
                  + diagonalTwist
                  + softRipple
                ) * direction;
                position.setXYZ(vertex, x, y, z);
              }
              position.needsUpdate = true;
              geometry.computeVertexNormals();
            });
          }

          function updatePaginatedBook(rig, delta, openAmount = 1) {
            const amount = clamp(openAmount, 0, 1);
            const speed = reducedMotion ? 1000 : 10.5;
            const hoverCrack = (
              mode === "detail"
              && !readingOpen
              && detailBookHovered
              && !reducedMotion
            ) ? -0.16 : 0;
            const coverTarget = amount > 0
              ? (-Math.PI + 0.055) * amount
              : hoverCrack;

            rig.frontPivot.rotation.y = damp(
              rig.frontPivot.rotation.y,
              coverTarget,
              speed,
              delta
            );

            rig.pagePivots.forEach((pagePivot, pageIndex) => {
              const leafOrder = rig.pagePivots.length - 1 - pageIndex;
              let pageTarget = 0;
              let positionTarget = pagePivot.userData.restZ;
              let pageTwistTarget = 0;
              let dragCurveBoost = 0;
              let flexTwistTarget = 0;

              if (leafOrder < PAGINATED_LEAF_COUNT) {
                const isTurned = leafOrder < currentSpread;
                const unturnedTarget = -0.038 + leafOrder * 0.008;
                const turnedTarget = -Math.PI + 0.085 + leafOrder * 0.014;
                pageTarget = isTurned ? turnedTarget : unturnedTarget;
                positionTarget = isTurned
                  ? pagePivot.userData.turnedZ
                  : pagePivot.userData.restZ;

                if (pageDrag.active && pageDrag.direction !== 0) {
                  const dragLeafOrder = pageDrag.direction > 0
                    ? currentSpread
                    : currentSpread - 1;
                  if (leafOrder === dragLeafOrder) {
                    const dragProgress = smoothstep(pageDrag.progress);
                    const dragEnvelope = Math.sin(Math.PI * dragProgress);
                    const speedResponse = clamp(
                      Math.abs(pageDrag.progressVelocity) / 5.5,
                      0,
                      1
                    );
                    const signedSpeed = clamp(
                      pageDrag.progressVelocity / 5.5,
                      -1,
                      1
                    );
                    pageTarget = pageDrag.direction > 0
                      ? lerp(unturnedTarget, turnedTarget, dragProgress)
                      : lerp(turnedTarget, unturnedTarget, dragProgress);
                    positionTarget = pageDrag.direction > 0
                      ? lerp(pagePivot.userData.restZ, pagePivot.userData.turnedZ, dragProgress)
                      : lerp(pagePivot.userData.turnedZ, pagePivot.userData.restZ, dragProgress);
                    pageTwistTarget = pageDrag.direction
                      * dragEnvelope
                      * (0.014 + pageDrag.verticalBias * 0.026);
                    dragCurveBoost = dragEnvelope * (
                      0.032
                      + speedResponse * 0.064
                    );
                    flexTwistTarget = dragEnvelope * (
                      pageDrag.verticalBias * 0.08
                      + signedSpeed * pageDrag.direction * 0.03
                    );
                  }
                }

                pagePivot.position.z = damp(
                  pagePivot.position.z,
                  pagePivot.userData.restZ
                    + (positionTarget - pagePivot.userData.restZ) * amount,
                  speed,
                  delta
                );
              } else {
                pageTarget = -0.006 + (leafOrder - PAGINATED_LEAF_COUNT) * 0.003;
                pagePivot.position.z = damp(
                  pagePivot.position.z,
                  pagePivot.userData.restZ,
                  speed,
                  delta
                );
              }

              pagePivot.rotation.y = damp(
                pagePivot.rotation.y,
                pageTarget * amount,
                speed,
                delta
              );
              pagePivot.rotation.z = damp(
                pagePivot.rotation.z,
                pageTwistTarget * amount,
                speed,
                delta
              );
              const turnProgress = clamp(
                Math.abs(pagePivot.rotation.y) / Math.PI,
                0,
                1
              );
              const curveTarget = amount > 0
                ? amount * (
                    0.004
                    + Math.sin(Math.PI * turnProgress) * 0.082
                    + dragCurveBoost
                  )
                : 0;
              updateFlexiblePage(
                pagePivot,
                curveTarget,
                delta,
                false,
                flexTwistTarget * amount
              );
            });
          }

          // ---- Shelf navigation -------------------------------------------------
          // Books move sideways (swipe, drag, arrows, sideways trackpad); vertical
          // scrolling is left to the page so it leads straight on to Experiences.
          function nearestTarget(index) {
            const rounded = Math.round(targetPosition);
            const current = mod(rounded, BOOKS.length);
            let delta = mod(index, BOOKS.length) - current;
            if (delta > BOOKS.length / 2) delta -= BOOKS.length;
            if (delta < -BOOKS.length / 2) delta += BOOKS.length;
            return rounded + delta;
          }

          function goToBook(index, smooth = true) {
            targetPosition = nearestTarget(index);
            if (!smooth || reducedMotion) {
              position = targetPosition;
              positionVelocity = 0;
            }
            requestFrame();
            return mod(index, BOOKS.length);
          }

          function scrollToExperiences() {
            const target = document.querySelector("#experiences");
            if (!target) return;
            window.scrollTo({
              top: target.getBoundingClientRect().top + window.scrollY,
              behavior: reducedMotion ? "auto" : "smooth"
            });
          }

          function selectMarker(index, origin) {
            if (mode !== "hero") return;
            focusReturnTarget = origin;
            goToBook(index);
            updateSelection(index, true);
          }

          function navigate(direction, origin) {
            if (mode !== "hero") return;
            focusReturnTarget = origin;
            targetPosition = Math.round(targetPosition) + direction;
            updateSelection(mod(Math.round(targetPosition), BOOKS.length), true);
            requestFrame();
          }

          function alignShelfToSelection() {
            targetPosition = nearestTarget(selectedIndex);
            position = targetPosition;
            positionVelocity = 0;
            wheelIdle = 0;
          }

          function snapRigToShelfSlot(rig, index) {
            let offset = index - position;
            offset -= Math.round(offset / BOOKS.length) * BOOKS.length;
            const distance = Math.abs(offset);
            const focus = 1 - clamp(distance, 0, 1);
            const fadeProgress = clamp((distance - 2.55) / 0.7, 0, 1);
            const opacity = 1 - smoothstep(fadeProgress);

            rig.root.position.set(
              offset * spacing,
              shelfBoardTop + rig.base.height * 0.5 + focus * 0.15,
              0.13 + focus * 0.24 - Math.min(distance, 2.8) * 0.07
            );
            rig.root.rotation.set(0, -offset * 0.105, -offset * 0.018);
            rig.root.scale.setScalar(1 + focus * 0.09);
            rig.motion.position.set(0, 0, 0);
            rig.motion.rotation.set(0, 0, 0);
            rig.frontPivot.rotation.y = 0;
            rig.pagePivots.forEach((pagePivot) => {
              pagePivot.rotation.y = 0;
              pagePivot.rotation.z = 0;
              pagePivot.position.z = pagePivot.userData.restZ;
              updateFlexiblePage(pagePivot, 0, 0, true);
            });
            rig.opacity = opacity;
            rig.fadeMaterials.forEach((material) => {
              material.opacity = opacity;
            });
            rig.contactShadow.visible = true;
            rig.contactShadow.material.opacity = opacity * 0.24;
            rig.hit.visible = opacity > 0.12;
            rig.lastOffset = offset;
          }

          function setPointerFromEvent(event) {
            const rect = canvas.getBoundingClientRect();
            pointer.clientX = event.clientX;
            pointer.clientY = event.clientY;
            pointer.ndc.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            pointer.ndc.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
            pointerDirty = true;
          }

          function updateHover() {
            pointerDirty = false;
            if (mode === "detail" && activeBook) {
              setHovered(-1);
              if (readingOpen) {
                detailBookHovered = false;
                canvas.classList.remove("has-closed-book-hover");
                canvas.classList.toggle(
                  "has-page-hover",
                  pageDrag.active
                    || Boolean(pageSurfaceAtPointer())
                    || Boolean(coverSurfaceAtPointer())
                );
              } else {
                detailBookHovered = Boolean(coverSurfaceAtPointer());
                canvas.classList.remove("has-page-hover");
                canvas.classList.toggle(
                  "has-closed-book-hover",
                  detailBookHovered
                );
              }
              return;
            }
            detailBookHovered = false;
            canvas.classList.remove("has-page-hover", "has-closed-book-hover");
            if (mode !== "hero") {
              setHovered(-1);
              return;
            }
            setHovered(bookIndexAtPointer());
          }

          function bookIndexAtPointer() {
            raycaster.setFromCamera(pointer.ndc, camera);
            const hits = raycaster.intersectObjects(hitTargets, false);
            return hits.length ? hits[0].object.userData.index : -1;
          }

          function activeBookAtPointer() {
            if (mode !== "detail" || !activeBook) return false;
            activeBook.root.updateWorldMatrix(true, true);
            raycaster.setFromCamera(pointer.ndc, camera);
            return raycaster.intersectObject(activeBook.hit, false).length > 0;
          }

          function pageSurfaceAtPointer() {
            if (mode !== "detail" || !activeBook || !readingOpen) return null;
            activeBook.root.updateWorldMatrix(true, true);
            raycaster.setFromCamera(pointer.ndc, camera);
            const hits = raycaster.intersectObjects(
              activeBook.pageGestureSurfaces,
              false
            );
            return hits.length ? hits[0].object : null;
          }

          function coverSurfaceAtPointer() {
            if (
              mode !== "detail"
              || !activeBook
              || currentSpread !== 0
            ) return null;
            activeBook.root.updateWorldMatrix(true, true);
            raycaster.setFromCamera(pointer.ndc, camera);
            const hits = raycaster.intersectObject(activeBook.frontCover, false);
            return hits.length ? hits[0].object : null;
          }

          function resetPageDrag() {
            const capturedPointerId = pageDrag.pointerId;
            pageDrag.active = false;
            pageDrag.pointerId = null;
            pageDrag.progress = 0;
            pageDrag.peakProgress = 0;
            pageDrag.committed = false;
            pageDrag.progressVelocity = 0;
            pageDrag.verticalBias = 0;
            pageDrag.lastProgress = 0;
            pageDrag.lastTime = 0;
            pageDrag.direction = 0;
            pageDrag.kind = null;
            canvas.classList.remove("is-page-dragging");
            controls.enabled = mode === "detail";
            if (
              capturedPointerId !== null
              && canvas.hasPointerCapture?.(capturedPointerId)
            ) {
              canvas.releasePointerCapture(capturedPointerId);
            }
          }

          function applyPageReleaseImpulse(turnDirection) {
            if (!activeBook || turnDirection === 0) return;
            const leafOrder = turnDirection > 0
              ? currentSpread
              : currentSpread - 1;
            const pageIndex = activeBook.pagePivots.length - 1 - leafOrder;
            const pagePivot = activeBook.pagePivots[pageIndex];
            const flex = pagePivot?.userData.flex;
            if (!flex) return;

            const speedResponse = clamp(
              Math.abs(pageDrag.progressVelocity) / 5.5,
              0.12,
              1
            );
            flex.curveVelocity = clamp(
              flex.curveVelocity + speedResponse * 0.46,
              -1.8,
              1.8
            );
            flex.twistVelocity = clamp(
              flex.twistVelocity
                + pageDrag.verticalBias * 0.38
                + clamp(
                    pageDrag.progressVelocity / 5.5,
                    -1,
                    1
                  ) * turnDirection * 0.14,
              -1.6,
              1.6
            );
          }

          function settlePageDrag(commitLatchedGesture = false) {
            if (!pageDrag.active) return false;
            const turnDirection = pageDrag.direction;
            const shouldCloseCover = commitLatchedGesture
              && pageDrag.kind === "cover-close"
              && pageDrag.committed;
            const shouldOpenCover = commitLatchedGesture
              && pageDrag.kind === "cover-open"
              && pageDrag.committed;
            const shouldTurnPage = commitLatchedGesture
              && pageDrag.kind === "page"
              && pageDrag.committed
              && turnDirection !== 0;
            if (shouldTurnPage) {
              applyPageReleaseImpulse(turnDirection);
            }
            resetPageDrag();
            if (shouldCloseCover) {
              setReadingOpen(false);
            } else if (shouldOpenCover) {
              setReadingOpen(true);
            } else if (shouldTurnPage) {
              turnPage(turnDirection);
            } else {
              requestFrame();
            }
            return shouldCloseCover || shouldOpenCover || shouldTurnPage;
          }

          function cancelPageDrag() {
            settlePageDrag(false);
          }

          function resetDetailPress() {
            detailPress.active = false;
            detailPress.pointerId = null;
            detailPress.moved = false;
            detailPress.allowClick = false;
          }

          function onDetailBookPointerDown(event) {
            if (
              mode !== "detail"
              || readingOpen
              || event.button !== 0
              || event.isPrimary === false
            ) return;

            setPointerFromEvent(event);
            detailPress.allowClick = false;
            if (!activeBookAtPointer()) return;
            detailPress.active = true;
            detailPress.pointerId = event.pointerId;
            detailPress.startX = event.clientX;
            detailPress.startY = event.clientY;
            detailPress.moved = false;
          }

          function onDetailBookPointerMove(event) {
            if (!detailPress.active || event.pointerId !== detailPress.pointerId) return;
            if (
              Math.hypot(
                event.clientX - detailPress.startX,
                event.clientY - detailPress.startY
              ) > 16
            ) {
              detailPress.moved = true;
            }
          }

          function onDetailBookPointerEnd(event) {
            if (!detailPress.active || event.pointerId !== detailPress.pointerId) return;
            detailPress.allowClick = event.type === "pointerup" && !detailPress.moved;
            detailPress.active = false;
            detailPress.pointerId = null;
          }

          function onPagePointerDown(event) {
            if (
              mode !== "detail"
              || !activeBook
              || event.button !== 0
              || event.isPrimary === false
            ) return;

            setPointerFromEvent(event);
            const coverSurface = coverSurfaceAtPointer();
            const pageSurface = readingOpen ? pageSurfaceAtPointer() : null;
            if (!coverSurface && !pageSurface) return;

            event.preventDefault();
            event.stopImmediatePropagation();
            pageDrag.active = true;
            pageDrag.pointerId = event.pointerId;
            pageDrag.startX = event.clientX;
            pageDrag.startY = event.clientY;
            pageDrag.progress = 0;
            pageDrag.peakProgress = 0;
            pageDrag.committed = false;
            pageDrag.progressVelocity = 0;
            pageDrag.verticalBias = 0;
            pageDrag.lastProgress = 0;
            pageDrag.lastTime = event.timeStamp || performance.now();
            pageDrag.direction = 0;
            pageDrag.kind = coverSurface
              ? readingOpen
                ? "cover-close"
                : "cover-open"
              : "page";
            controls.enabled = false;
            canvas.classList.add("has-page-hover", "is-page-dragging");
            canvas.setPointerCapture?.(event.pointerId);
            requestFrame();
          }

          function updatePageDragMotion(event, deltaY) {
            const eventTime = event.timeStamp || performance.now();
            const elapsed = clamp(
              (eventTime - pageDrag.lastTime) / 1000,
              0.008,
              0.08
            );
            const instantVelocity = clamp(
              (pageDrag.progress - pageDrag.lastProgress) / elapsed,
              -8,
              8
            );
            pageDrag.progressVelocity = lerp(
              pageDrag.progressVelocity,
              instantVelocity,
              0.42
            );
            pageDrag.verticalBias = lerp(
              pageDrag.verticalBias,
              clamp(deltaY / 180, -1, 1),
              0.36
            );
            pageDrag.lastProgress = pageDrag.progress;
            pageDrag.lastTime = eventTime;
          }

          function updatePageDragFromEvent(event) {
            setPointerFromEvent(event);

            const deltaX = event.clientX - pageDrag.startX;
            const deltaY = event.clientY - pageDrag.startY;
            const horizontalDistance = Math.abs(deltaX);

            if (
              pageDrag.kind === "cover-open"
              || pageDrag.kind === "cover-close"
            ) {
              const openingCover = pageDrag.kind === "cover-open";
              const signedDistance = openingCover ? -deltaX : deltaX;
              const commitProgress = openingCover
                ? COVER_OPEN_COMMIT_PROGRESS
                : COVER_CLOSE_COMMIT_PROGRESS;
              pageDrag.direction = 0;
              pageDrag.progress = (
                horizontalDistance >= 3
                && horizontalDistance >= Math.abs(deltaY) * 0.72
              )
                ? clamp(Math.max(0, signedDistance) / 140, 0, 1)
                : 0;
              pageDrag.peakProgress = Math.max(
                pageDrag.peakProgress,
                pageDrag.progress
              );
              if (pageDrag.peakProgress >= commitProgress) {
                pageDrag.committed = true;
              }
              updatePageDragMotion(event, deltaY);
              return;
            }

            if (
              horizontalDistance < 3
              || horizontalDistance < Math.abs(deltaY) * 0.72
            ) {
              pageDrag.progress = 0;
            } else {
              if (pageDrag.direction === 0 && horizontalDistance >= 6) {
                const direction = deltaX < 0 ? 1 : -1;
                const directionAvailable = direction > 0
                  ? currentSpread < SPREAD_COUNT - 1
                  : currentSpread > 0;
                pageDrag.direction = directionAvailable ? direction : 0;
              }

              const signedDistance = pageDrag.direction > 0 ? -deltaX : deltaX;
              pageDrag.progress = pageDrag.direction !== 0
                ? clamp(Math.max(0, signedDistance) / 150, 0, 1)
                : 0;
              pageDrag.peakProgress = Math.max(
                pageDrag.peakProgress,
                pageDrag.progress
              );
              if (pageDrag.peakProgress >= PAGE_TURN_COMMIT_PROGRESS) {
                pageDrag.committed = true;
              }
            }
            updatePageDragMotion(event, deltaY);
          }

          function onPagePointerMove(event) {
            if (!pageDrag.active || event.pointerId !== pageDrag.pointerId) return;
            event.preventDefault();
            event.stopImmediatePropagation();
            updatePageDragFromEvent(event);

            requestFrame();
          }

          function onPagePointerEnd(event) {
            if (!pageDrag.active || event.pointerId !== pageDrag.pointerId) return;
            if (event.cancelable) event.preventDefault();
            event.stopImmediatePropagation();
            if (event.type === "pointerup") updatePageDragFromEvent(event);
            const dragKind = pageDrag.kind;
            const releaseDistance = Math.hypot(
              event.clientX - pageDrag.startX,
              event.clientY - pageDrag.startY
            );
            const shouldClickOpen = event.type === "pointerup"
              && dragKind === "cover-open"
              && !pageDrag.committed
              && releaseDistance <= 12;
            if (pageDrag.committed) {
              settlePageDrag(true);
            } else if (shouldClickOpen) {
              resetPageDrag();
              detailPress.allowClick = false;
              setReadingOpen(true);
            } else {
              if (dragKind === "cover-open") {
                detailPress.allowClick = false;
              }
              cancelPageDrag();
            }
          }

          function onWindowPagePointerEnd(event) {
            if (!pageDrag.active || event.pointerId !== pageDrag.pointerId) return;
            if (event.type === "pointerup") updatePageDragFromEvent(event);
            settlePageDrag(true);
          }

          function setHovered(index) {
            if (hoveredIndex === index) return;
            hoveredIndex = index;
            canvas.classList.toggle("has-book-hover", index >= 0);
            if (index >= 0) {
              const book = BOOKS[index];
              pointerLabelIndex.textContent = `Volume ${pad(index + 1)}`;
              pointerLabelTitle.textContent = book.title;
              pointerLabel.setAttribute("aria-hidden", "false");
            } else {
              pointerLabel.setAttribute("aria-hidden", "true");
            }
            requestFrame();
          }

          function positionPointerLabel() {
            pointerLabel.style.left = `${pointer.clientX}px`;
            pointerLabel.style.top = `${pointer.clientY}px`;
          }

          function onPointerMove(event) {
            // Touch has no hover: skip the preview lift so a swipe never cracks a cover.
            if (event.pointerType === "touch" && mode === "hero") return;
            if (shelfDrag.active && shelfDrag.axis === "x") return;
            setPointerFromEvent(event);
            positionPointerLabel();
            requestFrame();
          }

          function shelfPixelsPerBook() {
            const distance = camera.position.distanceTo(shelfCameraTarget);
            const worldWidth = 2 * distance
              * Math.tan(THREE.MathUtils.degToRad(camera.fov * 0.5))
              * camera.aspect;
            return (viewWidth / Math.max(worldWidth, 0.001)) * spacing;
          }

          function onShelfPointerDown(event) {
            if (mode !== "hero" || event.isPrimary === false) return;
            if (event.pointerType === "mouse" && event.button !== 0) return;
            suppressShelfClick = false;
            shelfDrag.active = true;
            shelfDrag.pointerId = event.pointerId;
            shelfDrag.pointerType = event.pointerType;
            shelfDrag.startX = event.clientX;
            shelfDrag.startY = event.clientY;
            shelfDrag.startTarget = targetPosition;
            shelfDrag.lastX = event.clientX;
            shelfDrag.lastTime = event.timeStamp || performance.now();
            shelfDrag.velocity = 0;
            shelfDrag.axis = null;
          }

          function onShelfPointerMove(event) {
            if (!shelfDrag.active || event.pointerId !== shelfDrag.pointerId) return;
            const deltaX = event.clientX - shelfDrag.startX;
            const deltaY = event.clientY - shelfDrag.startY;

            if (!shelfDrag.axis && Math.hypot(deltaX, deltaY) > 6) {
              shelfDrag.axis = Math.abs(deltaX) >= Math.abs(deltaY) * 0.8 ? "x" : "y";
              if (shelfDrag.axis === "x") {
                // Re-anchor so the shelf doesn't jump by the dead-zone distance.
                shelfDrag.startX = event.clientX;
                shelfDrag.startTarget = targetPosition;
                canvas.setPointerCapture?.(event.pointerId);
                canvas.classList.add("is-shelf-dragging");
                setHovered(-1);
                wheelIdle = 0;
              }
            }
            if (shelfDrag.axis !== "x") return;

            const pixelsPerBook = shelfPixelsPerBook();
            const now = event.timeStamp || performance.now();
            const elapsed = clamp((now - shelfDrag.lastTime) / 1000, 0.004, 0.1);
            const instantVelocity = -(event.clientX - shelfDrag.lastX) / pixelsPerBook / elapsed;
            shelfDrag.velocity = lerp(shelfDrag.velocity, instantVelocity, 0.38);
            shelfDrag.lastX = event.clientX;
            shelfDrag.lastTime = now;

            // Light resistance makes the shelf feel weighted under the finger.
            const travelled = -(event.clientX - shelfDrag.startX) / pixelsPerBook;
            targetPosition = shelfDrag.startTarget + travelled * 0.96;
            requestFrame();
          }

          function onShelfPointerEnd(event) {
            if (!shelfDrag.active || event.pointerId !== shelfDrag.pointerId) return;
            const wasDragging = shelfDrag.axis === "x";
            shelfDrag.active = false;
            canvas.classList.remove("is-shelf-dragging");
            if (canvas.hasPointerCapture?.(event.pointerId)) {
              canvas.releasePointerCapture(event.pointerId);
            }

            if (wasDragging) {
              suppressShelfClick = true;
              const now = event.timeStamp || performance.now();
              // A finger that paused before lifting shouldn't fling the shelf.
              const velocity = now - shelfDrag.lastTime > 90 ? 0 : shelfDrag.velocity;
              const fling = event.type === "pointercancel" ? 0 : clamp(velocity * 0.2, -3, 3);
              const now_position = targetPosition;
              const projected = now_position + fling;
              const travelled = now_position - shelfDrag.startTarget;
              // Short, deliberate drags still advance one volume in their direction.
              let snapped = Math.round(projected);
              if (snapped === Math.round(shelfDrag.startTarget) && Math.abs(travelled) > 0.18) {
                snapped += Math.sign(travelled);
              }
              targetPosition = snapped;
              positionVelocity = lerp(positionVelocity, velocity, 0.6);
              updateSelection(mod(snapped, BOOKS.length), true);
              requestFrame();
            }
            shelfDrag.axis = null;
            if (shelfDrag.pointerType === "touch") onPointerLeave();
          }

          function onPointerLeave() {
            pointer.ndc.set(3, 3);
            pointerDirty = false;
            detailBookHovered = false;
            setHovered(-1);
            if (!pageDrag.active) {
              canvas.classList.remove("has-page-hover", "has-closed-book-hover");
            }
          }

          function onCanvasClick(event) {
            if (mode === "detail" && !readingOpen && event.button === 0) {
              if (!detailPress.allowClick) return;
              detailPress.allowClick = false;
              setPointerFromEvent(event);
              if (!activeBookAtPointer()) return;
              event.preventDefault();
              setReadingOpen(true);
              return;
            }
            if (mode !== "hero" || event.button !== 0) return;
            if (suppressShelfClick) {
              suppressShelfClick = false;
              return;
            }
            setPointerFromEvent(event);
            const clickedBookIndex = bookIndexAtPointer();
            if (clickedBookIndex < 0) return;
            event.preventDefault();
            focusReturnTarget = canvas;
            goToBook(clickedBookIndex, false);
            updateSelection(clickedBookIndex, true);
            openDetail(canvas);
          }

          let freeScrollTimer = 0;
          function restoreSnapping() {
            clearTimeout(freeScrollTimer);
            // Wait for the smooth scroll to land before snapping is switched back on.
            freeScrollTimer = setTimeout(() => {
            }, 750);
          }

          let sidewaysWheel = 0;
          let sidewaysLock = 0;
          function onWheel(event) {
            if (mode !== "hero") return;
            const unit = event.deltaMode === 1 ? 18 : event.deltaMode === 2 ? viewHeight : 1;
            const deltaX = event.deltaX * unit;
            const deltaY = event.deltaY * unit;
            // Vertical wheel is ordinary (snapped) page scrolling, which drives the shelf.
            if (Math.abs(deltaX) <= Math.abs(deltaY) || Math.abs(deltaX) < 0.5) return;
            // A sideways trackpad swipe moves one volume per gesture.
            event.preventDefault();
            const now = performance.now();
            if (now < sidewaysLock) return;
            sidewaysWheel += deltaX;
            if (Math.abs(sidewaysWheel) > 50) {
              navigate(Math.sign(sidewaysWheel), document.activeElement);
              sidewaysWheel = 0;
              sidewaysLock = now + 450;
            }
          }

          function snapAfterWheel() {
            const t = targetPosition;
            // Settle in the direction the reader was travelling once they pass ~30%.
            if (wheelDirection > 0) targetPosition = Math.floor(t + 0.7);
            else if (wheelDirection < 0) targetPosition = Math.ceil(t - 0.7);
            else targetPosition = Math.round(t);
            wheelDirection = 0;
          }

          function openDetail(origin = inspectButton) {
            if (mode !== "hero") return;
            mode = "opening";
            transitionTime = 0;
            readingOpen = false;
            detailBookHovered = false;
            currentSpread = 0;
            resetDetailPress();
            focusReturnTarget = origin === canvas
              ? markers.children[selectedIndex] || inspectButton
              : origin instanceof HTMLElement
                ? origin
                : inspectButton;
            activeBook = bookRigs[selectedIndex];
            activeBook.contactShadow.visible = false;
            positionVelocity = 0;
            wheelIdle = 0;
            shelfDrag.active = false;
            shelfDrag.axis = null;
            canvas.classList.remove("is-shelf-dragging");
            populateDetail(activeBook.data);
            setSheetExpanded(false);
            updatePageControls(false);
            // Measure the panel with this book's copy in place before framing.
            configureResponsiveTargets();
            detailPanel.inert = false;
            detailPanel.setAttribute("aria-hidden", "false");
            browseUi.inert = true;
            experience.classList.add("mode-detail", "is-opening");
            TL_ROOT.classList.add("is-reading");
            window.TL_lockPage("reading", true);
            pointerLabel.setAttribute("aria-hidden", "true");
            setHovered(-1);

            activeBook.root.updateWorldMatrix(true, true);
            activeBook.root.matrixWorld.decompose(
              openingBookPosition,
              openingBookQuaternion,
              openingBookScale
            );
            openingCameraPosition.copy(camera.position);
            openingCameraTarget.copy(transitionCameraTarget);
            openingShelfPosition.copy(shelfStage.position);
            openingMotionPosition.copy(activeBook.motion.position);
            openingMotionQuaternion.copy(activeBook.motion.quaternion);
            openingViewOffset.x = viewOffset.x;
            openingViewOffset.y = viewOffset.y;
            scene.add(activeBook.root);
            activeBook.root.position.copy(openingBookPosition);
            activeBook.root.quaternion.copy(openingBookQuaternion);
            activeBook.root.scale.copy(openingBookScale);
            applyViewOffset();
            controls.enabled = false;
            liveRegion.textContent = `Opening a closed copy of ${activeBook.data.title}. Drag the cover, click the book, or use Open book to begin reading.`;

            if (reducedMotion) {
              finishOpening();
            }
            requestFrame();
          }

          function applyOpeningPose(progress) {
            const eased = smootherstep(clamp(progress, 0, 1));
            const shelfClearEased = smootherstep(clamp(progress / 0.68, 0, 1));
            inspectBookScale.setScalar(getInspectScale(0));
            shelfStage.position.lerpVectors(
              openingShelfPosition,
              inspectShelfPosition,
              shelfClearEased
            );
            activeBook.root.position.lerpVectors(
              openingBookPosition,
              inspectPosition,
              eased
            );
            activeBook.root.quaternion.slerpQuaternions(
              openingBookQuaternion,
              inspectBookQuaternion,
              eased
            );
            activeBook.root.scale.lerpVectors(
              openingBookScale,
              inspectBookScale,
              eased
            );
            activeBook.motion.position.lerpVectors(
              openingMotionPosition,
              restingMotionPosition,
              eased
            );
            activeBook.motion.quaternion.slerpQuaternions(
              openingMotionQuaternion,
              restingMotionQuaternion,
              eased
            );
            camera.position.lerpVectors(
              openingCameraPosition,
              inspectCameraPosition,
              eased
            );
            transitionCameraTarget.lerpVectors(
              openingCameraTarget,
              inspectCameraTarget,
              eased
            );
            viewOffset.x = lerp(openingViewOffset.x, detailOffsetClosed.x, eased);
            viewOffset.y = lerp(openingViewOffset.y, detailOffsetClosed.y, eased);
            applyViewOffset();
            camera.lookAt(transitionCameraTarget);
          }

          function finishOpening() {
            if (!activeBook) return;
            applyOpeningPose(1);
            mode = "detail";
            transitionTime = 1;
            controls.target.copy(inspectCameraTarget);
            controls.enabled = true;
            controls.enableDamping = !reducedMotion;
            controls.update();
            updatePageControls(false);
            experience.classList.remove("is-opening");
            closeButton.focus({ preventScroll: true });
          }

          function closeDetail() {
            if (mode !== "detail") return;
            cancelPageDrag();
            resetDetailPress();
            mode = "closing";
            transitionTime = 0;
            readingOpen = false;
            detailBookHovered = false;
            currentSpread = 0;
            canvas.classList.remove("has-page-hover", "has-closed-book-hover");
            updatePageControls(false);
            controls.enabled = false;
            closingBookStartPosition.copy(activeBook.root.position);
            closingBookStartQuaternion.copy(activeBook.root.quaternion);
            closingBookStartScale.copy(activeBook.root.scale);
            closingMotionPosition.copy(activeBook.motion.position);
            closingMotionQuaternion.copy(activeBook.motion.quaternion);
            closingCameraPosition.copy(camera.position);
            closingCameraTarget.copy(controls.target);
            closingShelfPosition.copy(shelfStage.position);
            closingViewOffset.x = viewOffset.x;
            closingViewOffset.y = viewOffset.y;
            transitionCameraTarget.copy(closingCameraTarget);
            experience.classList.remove("is-opening");
            alignShelfToSelection();
            closingBookPosition.set(
              0,
              shelfBoardTop + activeBook.base.height * 0.5 + 0.15,
              0.37
            );
            bookRigs.forEach((rig, index) => {
              if (rig !== activeBook && rig.root.parent === shelfStage) {
                snapRigToShelfSlot(rig, index);
              }
            });
            experience.classList.remove("mode-detail");
            detailPanel.setAttribute("aria-hidden", "true");
            detailPanel.inert = true;
            liveRegion.textContent = `Returning ${activeBook.data.title} to the shelf.`;
            if (reducedMotion) {
              finishClosing();
            }
            requestFrame();
          }

          function applyClosingPose(progress) {
            const eased = smootherstep(clamp(progress, 0, 1));
            const shelfReturnEased = smootherstep(
              clamp((progress - 0.24) / 0.76, 0, 1)
            );
            shelfStage.position.lerpVectors(
              closingShelfPosition,
              shelfRestPosition,
              shelfReturnEased
            );
            activeBook.root.position.lerpVectors(
              closingBookStartPosition,
              closingBookPosition,
              eased
            );
            activeBook.root.quaternion.slerpQuaternions(
              closingBookStartQuaternion,
              closingBookQuaternion,
              eased
            );
            activeBook.root.scale.lerpVectors(
              closingBookStartScale,
              closingBookScale,
              eased
            );
            activeBook.motion.position.lerpVectors(
              closingMotionPosition,
              restingMotionPosition,
              eased
            );
            activeBook.motion.quaternion.slerpQuaternions(
              closingMotionQuaternion,
              restingMotionQuaternion,
              eased
            );
            camera.position.lerpVectors(
              closingCameraPosition,
              shelfCameraPosition,
              eased
            );
            transitionCameraTarget.lerpVectors(
              closingCameraTarget,
              shelfCameraTarget,
              eased
            );
            viewOffset.x = lerp(closingViewOffset.x, heroViewOffset.x, eased);
            viewOffset.y = lerp(closingViewOffset.y, heroViewOffset.y, eased);
            applyViewOffset();
            camera.lookAt(transitionCameraTarget);
          }

          function finishClosing() {
            if (!activeBook) return;
            applyClosingPose(1);
            shelfStage.attach(activeBook.root);
            snapRigToShelfSlot(activeBook, selectedIndex);
            activeBook.contactShadow.visible = true;
            controls.target.copy(shelfCameraTarget);
            browseUi.inert = false;
            TL_ROOT.classList.remove("is-reading");
            window.TL_lockPage("reading", false);
            mode = "hero";
            transitionTime = 0;
            activeBook = null;
            liveRegion.textContent = `${BOOKS[selectedIndex].title} returned to the shelf.`;
            requestAnimationFrame(() => focusReturnTarget?.focus?.({ preventScroll: true }));
          }

          function resetInspectionView() {
            if (mode !== "detail") return;
            camera.position.copy(inspectCameraPosition);
            controls.target.copy(inspectCameraTarget);
            controls.update();
            liveRegion.textContent = `Inspection view reset for ${BOOKS[selectedIndex].title}.`;
            requestFrame();
          }

          function stepShelfSpring(delta) {
            // Critically damped spring: velocity is continuous, so the shelf eases in
            // and out instead of jumping to a new speed on every wheel tick.
            const dragging = shelfDrag.active && shelfDrag.axis === "x";
            const stiffness = dragging ? 620 : 150;
            const damping = 2 * Math.sqrt(stiffness);
            let remaining = delta;
            while (remaining > 0) {
              const step = Math.min(remaining, 1 / 240);
              const acceleration = (targetPosition - position) * stiffness
                - positionVelocity * damping;
              positionVelocity += acceleration * step;
              position += positionVelocity * step;
              remaining -= step;
            }
            if (
              Math.abs(position - targetPosition) < 0.0004
              && Math.abs(positionVelocity) < 0.003
            ) {
              position = targetPosition;
              positionVelocity = 0;
            }
          }

          function updateShelfLayout(delta, elapsed) {
            if (mode === "hero") {
              if (reducedMotion) {
                position = targetPosition;
                positionVelocity = 0;
              } else {
                stepShelfSpring(delta);
              }

              if (wheelIdle > 0) {
                wheelIdle -= delta;
                if (wheelIdle <= 0) {
                  wheelIdle = 0;
                  snapAfterWheel();
                }
              }

              const nearest = mod(Math.round(position), BOOKS.length);
              if (nearest !== selectedIndex) updateSelection(nearest, false);
            }

            // A gentle lean in the direction of travel gives the shelf some weight.
            const lean = reducedMotion ? 0 : clamp(-positionVelocity * 0.03, -0.1, 0.1);

            bookRigs.forEach((rig, index) => {
              if (rig.root.parent !== shelfStage) return;

              let offset = index - position;
              offset -= Math.round(offset / BOOKS.length) * BOOKS.length;
              const distance = Math.abs(offset);
              const focus = 1 - smoothstep(clamp(distance, 0, 1));
              rig.lastOffset = offset;

              // The spring already smooths `position`, so books follow it directly.
              // Damping them a second time made the shelf feel laggy and rubbery.
              rig.root.position.set(
                offset * spacing,
                shelfBoardTop + rig.base.height * 0.5 + focus * 0.15,
                0.13 + focus * 0.24 - Math.min(distance, 2.8) * 0.07
              );
              rig.root.rotation.y = -offset * 0.105 + lean;
              rig.root.rotation.z = -offset * 0.018 + lean * 0.12;
              rig.root.scale.setScalar(1 + focus * 0.09);

              const fadeProgress = clamp((distance - 2.55) / 0.7, 0, 1);
              rig.opacity = 1 - smoothstep(fadeProgress);
              rig.fadeMaterials.forEach((material) => {
                material.opacity = rig.opacity;
              });
              rig.contactShadow.visible = true;
              rig.contactShadow.material.opacity = rig.opacity * 0.24;
              rig.hit.visible = rig.opacity > 0.12;

              const isHovered = hoveredIndex === index && mode === "hero";
              const hoverPreview = isHovered && !reducedMotion;
              const hoverAngle = hoverPreview ? -0.085 : 0;
              rig.frontPivot.rotation.y = damp(
                rig.frontPivot.rotation.y,
                hoverAngle,
                reducedMotion ? 1000 : 13,
                delta
              );
              rig.pagePivots.forEach((pagePivot) => {
                pagePivot.rotation.y = damp(
                  pagePivot.rotation.y,
                  0,
                  reducedMotion ? 1000 : 13,
                  delta
                );
                pagePivot.rotation.z = damp(
                  pagePivot.rotation.z,
                  0,
                  reducedMotion ? 1000 : 13,
                  delta
                );
                updateFlexiblePage(pagePivot, 0, delta);
              });

              const idle = reducedMotion ? 0 : Math.sin(elapsed * 0.72 + index * 0.8) * 0.012 * focus;
              rig.motion.position.y = damp(rig.motion.position.y, idle + (hoverPreview ? 0.035 : 0), 9, delta);
              rig.motion.rotation.x = damp(
                rig.motion.rotation.x,
                hoverPreview ? pointer.ndc.y * 0.035 : 0,
                10,
                delta
              );
              rig.motion.rotation.y = damp(
                rig.motion.rotation.y,
                hoverPreview ? -pointer.ndc.x * 0.035 : 0,
                10,
                delta
              );
            });
          }

          function updateTransition(delta) {
            if (mode === "opening") {
              transitionTime = Math.min(
                1,
                transitionTime + delta / DETAIL_TRANSITION_DURATION
              );
              applyOpeningPose(transitionTime);
              updatePaginatedBook(activeBook, delta, 0);
              if (transitionTime >= 1) finishOpening();
            } else if (mode === "closing") {
              transitionTime = Math.min(
                1,
                transitionTime + delta / SHELF_TRANSITION_DURATION
              );
              applyClosingPose(transitionTime);
              updatePaginatedBook(activeBook, delta, 0);
              if (transitionTime >= 1) finishClosing();
            } else if (mode === "hero") {
              shelfStage.position.y = damp(shelfStage.position.y, 0, 10, delta);
              shelfStage.position.z = damp(shelfStage.position.z, 0, 10, delta);
              camera.position.x = damp(camera.position.x, shelfCameraPosition.x, 8, delta);
              camera.position.y = damp(camera.position.y, shelfCameraPosition.y, 8, delta);
              camera.position.z = damp(camera.position.z, shelfCameraPosition.z, 8, delta);
              transitionCameraTarget.copy(shelfCameraTarget);
              viewOffset.x = damp(viewOffset.x, heroViewOffset.x, 8, delta);
              viewOffset.y = damp(viewOffset.y, heroViewOffset.y, 8, delta);
              applyViewOffset();
              camera.lookAt(shelfCameraTarget);
            }
          }

          const scratchOffset = { x: 0, y: 0 };
          function updateDetailFraming(delta) {
            if (!activeBook) return;
            const openness = getVisualOpenAmount(activeBook);
            // Slide the spine right as the cover swings open so the spread stays centred.
            activeBook.motion.position.x = activeBook.base.width * 0.5 * openness;
            const speed = reducedMotion ? 1000 : 9;
            const nextScale = damp(
              activeBook.root.scale.x,
              getInspectScale(openness),
              speed,
              delta
            );
            activeBook.root.scale.setScalar(nextScale);
            getDetailViewOffset(openness, scratchOffset);
            viewOffset.x = damp(viewOffset.x, scratchOffset.x, speed, delta);
            viewOffset.y = damp(viewOffset.y, scratchOffset.y, speed, delta);
            applyViewOffset();
          }

          function updateDust(elapsed) {
            if (reducedMotion) return;
            const dust = scene.getObjectByName("paper-dust");
            if (dust) {
              dust.rotation.y = elapsed * 0.012;
              dust.position.y = Math.sin(elapsed * 0.17) * 0.025;
            }
          }

          function requestFrame() {
            if (!rafId && !suspended && shelfInView) {
              rafId = requestAnimationFrame(frame);
            }
          }

          function getDetailOpenAmount() {
            if (pageDrag.active && pageDrag.kind === "cover-open") {
              return smoothstep(pageDrag.progress);
            }
            if (!readingOpen) return 0;
            if (pageDrag.active && pageDrag.kind === "cover-close") {
              return 1 - smoothstep(pageDrag.progress);
            }
            return 1;
          }

          function frame(time) {
            rafId = 0;
            const delta = Math.min((time - lastTime) / 1000, 0.05);
            const elapsed = time / 1000;
            lastTime = time;

            if (pointerDirty) updateHover();
            updateShelfLayout(delta, elapsed);
            updateTransition(delta);
            updateDust(elapsed);
            const themeIsMoving = updateTheme(delta);

            if (mode === "detail") {
              if (pageDrag.active) {
                pageDrag.progressVelocity = damp(
                  pageDrag.progressVelocity,
                  0,
                  9,
                  delta
                );
              }
              controls.update();
              updatePaginatedBook(activeBook, delta, getDetailOpenAmount());
              updateDetailFraming(delta);
            }

            renderer.render(scene, camera);

            const shelfMoving = Math.abs(position - targetPosition) > 0.0005
              || Math.abs(positionVelocity) > 0.003
              || wheelIdle > 0
              || shelfDrag.active;
            const shouldContinue = !reducedMotion
              || mode === "opening"
              || mode === "closing"
              || shelfMoving
              || themeIsMoving;
            if (shouldContinue && !suspended && shelfInView) requestFrame();
          }

          let lastResizeWidth = 0;
          function resize() {
            const widthChanged = window.innerWidth !== lastResizeWidth;
            lastResizeWidth = window.innerWidth;
            viewWidth = window.innerWidth;
            // The shelf is a little shorter than the screen so the Experiences
            // banner can peek in below it; size the 3D view to the shelf itself.
            viewHeight = experience.clientHeight || window.innerHeight;
            configureResponsiveTargets();
            renderer.setSize(viewWidth, viewHeight, false);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, viewWidth <= 880 ? 1.75 : 2));
            camera.aspect = viewWidth / viewHeight;
            camera.updateProjectionMatrix();

            if (mode === "hero") {
              camera.position.copy(shelfCameraPosition);
              transitionCameraTarget.copy(shelfCameraTarget);
              viewOffset.x = heroViewOffset.x;
              viewOffset.y = heroViewOffset.y;
              applyViewOffset();
              camera.lookAt(shelfCameraTarget);
              // Re-seat books immediately when spacing changes between layouts.
              bookRigs.forEach((rig, index) => {
                if (rig.root.parent === shelfStage) snapRigToShelfSlot(rig, index);
              });
            } else if (mode === "detail" && activeBook) {
              const openness = getVisualOpenAmount(activeBook);
              activeBook.root.position.copy(inspectPosition);
              activeBook.root.scale.setScalar(getInspectScale(openness));
              transitionCameraTarget.copy(inspectCameraTarget);
              getDetailViewOffset(openness, viewOffset);
              applyViewOffset();
              // Mobile browser chrome resizes the height constantly while reading;
              // only reset the orbit when the width (orientation) actually changes.
              if (widthChanged) resetInspectionView();
            }
            requestFrame();
          }

          function onKeyDown(event) {
            if (event.key === "Escape" && mode === "detail") {
              event.preventDefault();
              closeDetail();
              return;
            }

            if (
              mode === "detail"
              && !event.metaKey
              && !event.ctrlKey
              && !event.altKey
              && (event.key === "ArrowLeft" || event.key === "ArrowRight")
            ) {
              event.preventDefault();
              turnPage(event.key === "ArrowLeft" ? -1 : 1);
              return;
            }

            if (mode === "detail" && event.key === "Tab") {
              const focusables = [
                sheetHandle,
                closeButton,
                toggleBookButton,
                previousPageButton,
                nextPageButton,
                resetButton
              ].filter((element) => !element.disabled && element.getClientRects().length > 0);
              const current = focusables.indexOf(document.activeElement);
              const next = event.shiftKey
                ? (current <= 0 ? focusables.length - 1 : current - 1)
                : (current >= focusables.length - 1 ? 0 : current + 1);
              event.preventDefault();
              focusables[next].focus();
              return;
            }

            if (mode !== "hero" || event.metaKey || event.ctrlKey || event.altKey) return;
            if (event.target instanceof HTMLElement && event.target.closest("input, textarea, select, [contenteditable]")) return;
            if (!shelfInView || shelfSection.getBoundingClientRect().bottom < viewHeight * 0.5) return;
            if (event.target instanceof HTMLElement && event.target.closest("#experiences")) return;
            if (event.key === "ArrowLeft") {
              event.preventDefault();
              navigate(-1, document.activeElement);
            } else if (event.key === "ArrowRight") {
              event.preventDefault();
              navigate(1, document.activeElement);
            } else if ((event.key === "Enter" || event.key === " ") && document.activeElement === inspectButton) {
              event.preventDefault();
              openDetail(inspectButton);
            }
          }

          function onVisibilityChange() {
            suspended = document.hidden;
            if (!suspended) {
              lastTime = performance.now();
              requestFrame();
            } else {
              settlePageDrag(true);
              resetDetailPress();
              if (rafId) {
                cancelAnimationFrame(rafId);
                rafId = 0;
              }
            }
          }

          function onWindowBlur() {
            settlePageDrag(true);
            resetDetailPress();
          }

          function onReducedMotionChange(event) {
            cancelPageDrag();
            resetDetailPress();
            reducedMotion = event.matches;
            controls.enableDamping = !reducedMotion;
            if (reducedMotion) {
              position = targetPosition;
            }
            requestFrame();
          }

          function showFallback(message) {
            loading.hidden = true;
            experience.classList.remove("webgl-ready");
            staticFallback.hidden = false;
            fallbackStatus.textContent = message;
          }

          function handleContextLost(event) {
            event.preventDefault();
            cancelPageDrag();
            resetDetailPress();
            suspended = true;
            if (rafId) cancelAnimationFrame(rafId);
            rafId = 0;
            showFallback("The 3D view paused after losing its graphics context. The complete static catalog remains available; reload to restore inspection.");
          }

          function disposeExperience() {
            suspended = true;
            cancelPageDrag();
            resetDetailPress();
            if (rafId) cancelAnimationFrame(rafId);
            rafId = 0;

            canvas.removeEventListener("pointerdown", onShelfPointerDown);
            canvas.removeEventListener("pointermove", onShelfPointerMove);
            canvas.removeEventListener("pointerup", onShelfPointerEnd);
            canvas.removeEventListener("pointercancel", onShelfPointerEnd);
            canvas.removeEventListener("pointermove", onPointerMove);
            canvas.removeEventListener("pointerleave", onPointerLeave);
            canvas.removeEventListener("click", onCanvasClick);
            canvas.removeEventListener("pointerdown", onDetailBookPointerDown, true);
            canvas.removeEventListener("pointermove", onDetailBookPointerMove, true);
            canvas.removeEventListener("pointerup", onDetailBookPointerEnd, true);
            canvas.removeEventListener("pointercancel", onDetailBookPointerEnd, true);
            canvas.removeEventListener("lostpointercapture", onDetailBookPointerEnd, true);
            canvas.removeEventListener("pointerdown", onPagePointerDown, true);
            canvas.removeEventListener("pointermove", onPagePointerMove, true);
            canvas.removeEventListener("pointerup", onPagePointerEnd, true);
            canvas.removeEventListener("pointercancel", onPagePointerEnd, true);
            canvas.removeEventListener("lostpointercapture", onPagePointerEnd, true);
            window.removeEventListener("pointerup", onWindowPagePointerEnd);
            window.removeEventListener("pointercancel", onWindowPagePointerEnd);
            experience.removeEventListener("wheel", onWheel);
            canvas.removeEventListener("webglcontextlost", handleContextLost);
            window.removeEventListener("resize", resize);
            window.removeEventListener("keydown", onKeyDown);
            window.removeEventListener("blur", onWindowBlur);
            document.removeEventListener("visibilitychange", onVisibilityChange);
            reducedMotionQuery.removeEventListener("change", onReducedMotionChange);

            controls?.dispose();
            scene?.traverse((object) => {
              object.geometry?.dispose();
              const materials = Array.isArray(object.material) ? object.material : [object.material];
              materials.filter(Boolean).forEach((material) => {
                Object.values(material).forEach((value) => {
                  if (value?.isTexture) value.dispose();
                });
                material.dispose();
              });
            });
            environmentTarget?.dispose();
            renderer?.dispose();
          }

          async function initialize() {
            const woodTexturePromise = woodTextureImage.decode().then(
              () => true,
              () => false
            );

            try {
              await document.fonts.load("600 82px Inter");
            } catch (error) {
              // The system sans-serif fallback keeps the interface usable offline.
            }

            try {
              await Promise.all(uploadedCoverImages.map((image) => image.decode()));
              coverAtlasReady = true;
            } catch (error) {
              coverAtlasReady = false;
            }

            try {
              renderer = new THREE.WebGLRenderer({
                canvas,
                antialias: true,
                alpha: true,
                powerPreference: "high-performance"
              });
            } catch (error) {
              showFallback("WebGL is unavailable in this browser. The complete static catalog remains available.");
              return;
            }

            renderer.outputColorSpace = THREE.SRGBColorSpace;
            renderer.toneMapping = THREE.ACESFilmicToneMapping;
            renderer.toneMappingExposure = 0.9;
            renderer.shadowMap.enabled = true;
            renderer.shadowMap.type = THREE.PCFSoftShadowMap;
            renderer.setClearColor(0x000000, 0);

            scene = new THREE.Scene();
            scene.fog = new THREE.FogExp2(0xe9dfcb, 0.027);
            const pmremGenerator = new THREE.PMREMGenerator(renderer);
            environmentTarget = pmremGenerator.fromScene(new RoomEnvironment(), 0.04);
            scene.environment = environmentTarget.texture;
            scene.environmentIntensity = 0.72;
            pmremGenerator.dispose();

            camera = new THREE.PerspectiveCamera(32, 1, 0.1, 60);
            shelfStage = new THREE.Group();
            shelfStage.name = "continuous-shelf-stage";
            scene.add(shelfStage);

            configureResponsiveTargets();
            camera.position.copy(shelfCameraPosition);
            camera.lookAt(shelfCameraTarget);

            controls = new OrbitControls(camera, canvas);
            controls.enabled = false;
            controls.enableDamping = !reducedMotion;
            controls.dampingFactor = 0.075;
            controls.enablePan = true;
            controls.screenSpacePanning = true;
            controls.minDistance = 2.8;
            controls.maxDistance = 7.2;
            controls.minPolarAngle = Math.PI * 0.24;
            controls.maxPolarAngle = Math.PI * 0.76;
            controls.target.copy(shelfCameraTarget);
            controls.addEventListener("change", requestFrame);

            RectAreaLightUniformsLib.init();
            addRoom();
            addLights();
            buildMarkers();

            bookRigs = BOOKS.map((book, index) => {
              const rig = createBookRig(book, index);
              shelfStage.add(rig.root);
              return rig;
            });

            updateSelection(0, true);
            resize();

            new IntersectionObserver(([entry]) => {
              const wasInView = shelfInView;
              shelfInView = entry.isIntersecting;
              if (shelfInView && !wasInView) {
                lastTime = performance.now();
                requestFrame();
              }
            }).observe(shelfSection);
            document.querySelectorAll('a[href="#experiences"]').forEach((link) => {
              link.addEventListener("click", (event) => {
                event.preventDefault();
                scrollToExperiences();
              });
            });

            canvas.addEventListener("pointerdown", onShelfPointerDown);
            canvas.addEventListener("pointermove", onShelfPointerMove);
            canvas.addEventListener("pointerup", onShelfPointerEnd);
            canvas.addEventListener("pointercancel", onShelfPointerEnd);
            canvas.addEventListener("pointermove", onPointerMove);
            canvas.addEventListener("pointerleave", onPointerLeave);
            canvas.addEventListener("click", onCanvasClick);
            canvas.addEventListener("pointerdown", onDetailBookPointerDown, { capture: true });
            canvas.addEventListener("pointermove", onDetailBookPointerMove, { capture: true });
            canvas.addEventListener("pointerup", onDetailBookPointerEnd, { capture: true });
            canvas.addEventListener("pointercancel", onDetailBookPointerEnd, { capture: true });
            canvas.addEventListener("lostpointercapture", onDetailBookPointerEnd, { capture: true });
            canvas.addEventListener("pointerdown", onPagePointerDown, { capture: true });
            canvas.addEventListener("pointermove", onPagePointerMove, { capture: true });
            canvas.addEventListener("pointerup", onPagePointerEnd, { capture: true });
            canvas.addEventListener("pointercancel", onPagePointerEnd, { capture: true });
            canvas.addEventListener("lostpointercapture", onPagePointerEnd, { capture: true });
            window.addEventListener("pointerup", onWindowPagePointerEnd);
            window.addEventListener("pointercancel", onWindowPagePointerEnd);
            experience.addEventListener("wheel", onWheel, { passive: false });
            canvas.addEventListener("webglcontextlost", handleContextLost);
            window.addEventListener("resize", resize);
            window.addEventListener("keydown", onKeyDown);
            window.addEventListener("blur", onWindowBlur);
            document.addEventListener("visibilitychange", onVisibilityChange);
            reducedMotionQuery.addEventListener("change", onReducedMotionChange);

            previousButton.addEventListener("click", () => navigate(-1, previousButton));
            nextButton.addEventListener("click", () => navigate(1, nextButton));
            inspectButton.addEventListener("click", () => openDetail(inspectButton));
            closeButton.addEventListener("click", closeDetail);
            sheetHandle.addEventListener("click", () => {
              setSheetExpanded(!detailPanel.classList.contains("is-expanded"));
            });
            document.querySelector("#detail-readmore")?.addEventListener("click", () => setSheetExpanded(true));
            toggleBookButton.addEventListener("click", () => setReadingOpen(!readingOpen));
            previousPageButton.addEventListener("click", () => turnPage(-1));
            nextPageButton.addEventListener("click", () => turnPage(1));
            resetButton.addEventListener("click", resetInspectionView);

            renderer.render(scene, camera);
            loading.hidden = true;
            experience.classList.add("webgl-ready");
            requestFrame();

            woodTexturePromise.then((ready) => {
              if (!ready || suspended || !renderer) return;
              woodTextureReady = true;
              applyWoodTexture();
            });
          }

          initialize().catch(() => {
            showFallback("The interactive shelf could not be prepared. The complete static catalog remains available.");
          });
          window.addEventListener("beforeunload", disposeExperience, { once: true });
  
    })().catch(function (error) {
      console.error("[The List] The 3D shelf could not load; showing the static catalog.", error);
      var loading = TL_ROOT.querySelector("#loading");
      var fallback = TL_ROOT.querySelector("#static-fallback");
      var status = TL_ROOT.querySelector("#fallback-status");
      if (loading) loading.hidden = true;
      if (fallback) fallback.hidden = false;
      if (status) status.textContent = "The interactive shelf could not load here. The complete catalog remains available.";
    });
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
